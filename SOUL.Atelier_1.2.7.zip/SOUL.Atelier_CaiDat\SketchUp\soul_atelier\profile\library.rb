# encoding: UTF-8
# SOUL Profile – thư viện profile: mẫu có tham số + profile của người dùng (lưu JSON, đơn vị mm).
require 'json'
require 'fileutils'

module SoulAtelier
  module Profile
    module Library
      # [mã, tên, [[tham số, nhãn, mặc định (mm)], ...]]
      PRESETS = [
        ['rect',    'Hộp đặc (gỗ, đá)',     [['w', 'Rộng', 40], ['h', 'Cao', 80]]],
        ['box',     'Thép hộp',             [['w', 'Rộng', 40], ['h', 'Cao', 80], ['t', 'Dày', 1.4]]],
        ['round',   'Thanh tròn đặc',       [['d', 'Đường kính', 20]]],
        ['tube',    'Ống tròn',             [['d', 'Đường kính', 42], ['t', 'Dày', 1.4]]],
        ['angle',   'Thép góc L',           [['w', 'Rộng', 50], ['h', 'Cao', 50], ['t', 'Dày', 5]]],
        ['channel', 'Thép U',               [['w', 'Rộng', 100], ['h', 'Cao', 50], ['t', 'Dày', 5]]],
        ['ibeam',   'Thép I / H',           [['w', 'Cánh rộng', 100], ['h', 'Cao', 200], ['t', 'Bụng dày', 5.5], ['tf', 'Cánh dày', 8]]],
        ['molding', 'Phào bậc',             [['w', 'Rộng', 60], ['h', 'Cao', 80]]],
        ['quarter', 'Nẹp cung 1/4',         [['d', 'Đường kính', 30]]]
      ].freeze

      def self.dir
        File.join(SoulAtelier::DATA_DIR, 'profiles')
      end

      # Danh sách cho giao diện: mẫu + profile người dùng
      def self.catalog
        presets = PRESETS.map do |id, name, params|
          { 'id' => id, 'name' => name, 'kind' => 'preset',
            'params' => params.map { |k, label, v| { 'key' => k, 'label' => label, 'value' => v } } }
        end
        presets + user_profiles.map { |u| u.merge('kind' => 'user') }
      end

      def self.user_profiles
        return [] unless File.directory?(dir)
        Dir.glob(File.join(dir, '*.json')).sort.map do |f|
          begin
            data = JSON.parse(File.read(f, :mode => 'rb').force_encoding('UTF-8').sub(/\A﻿/, ''))
            { 'id' => 'user:' + File.basename(f, '.json'), 'name' => data['name'].to_s, 'loops' => data['loops'] }
          rescue StandardError
            nil
          end
        end.compact
      end

      # Vòng profile (mm) theo trạng thái giao diện
      def self.loops_for(state)
        id = state['profile'].to_s
        if id == 'temp'
          state['loops'] || []                     # profile dùng tạm, không lưu file
        elsif id.start_with?('user:')
          u = user_profiles.find { |p| p['id'] == id }
          u ? u['loops'] : []
        else
          Geo.preset(id, state['params'] || {})
        end
      end

      def self.name_for(state)
        id = state['profile'].to_s
        return (state['temp_name'].to_s.empty? ? 'Profile tạm' : state['temp_name'].to_s) if id == 'temp'
        if id.start_with?('user:')
          u = user_profiles.find { |p| p['id'] == id }
          return u ? u['name'] : id
        end
        preset = PRESETS.find { |p| p[0] == id }
        return id unless preset
        dims = preset[2].map { |k, _, _| fmt(state.dig('params', k)) }.join('x')
        "#{preset[1].sub(/\s*\(.*\)/, "")} #{dims}"
      end

      def self.fmt(v)
        f = v.to_f
        f == f.round ? f.round.to_s : f.round(2).to_s
      end

      def self.safe_name(name)
        safe = name.to_s.strip.gsub(/[\\\/:*?"<>|]/, '_')
        safe.empty? ? 'Profile' : safe
      end

      def self.id_for(name)
        'user:' + safe_name(name)
      end

      def self.exists?(id)
        File.exist?(File.join(dir, id.to_s.sub('user:', '') + '.json'))
      end

      def self.save_user(name, loops)
        FileUtils.mkdir_p(dir)
        safe = safe_name(name)
        path = File.join(dir, safe + '.json')
        File.open(path, 'wb') { |f| f.write(JSON.generate('name' => name.to_s.strip, 'unit' => 'mm', 'loops' => loops)) }
        'user:' + safe
      end

      def self.delete_user(id)
        return false unless id.to_s.start_with?('user:')
        path = File.join(dir, id.sub('user:', '') + '.json')
        File.exist?(path) && File.delete(path) && true
      rescue StandardError
        false
      end

      # Mặt đang chọn → profile 2D (mm), nhìn từ phía mặt trước của face: x sang phải, y lên trên
      def self.from_face(face)
        n = face.normal
        if n.parallel?(Z_AXIS)
          up = Geom::Vector3d.new(0, 1, 0)
        else
          k = n.z                                  # bỏ thành phần theo pháp tuyến khỏi trục Z
          up = Geom::Vector3d.new(-n.x * k, -n.y * k, 1 - n.z * k)
          up.normalize!
        end
        xa = up * n
        xa.normalize!
        origin = face.outer_loop.vertices.first.position
        loops = face.loops.map do |lp|
          lp.vertices.map do |v|
            d = v.position - origin
            [d.dot(xa).to_f * 25.4, d.dot(up).to_f * 25.4]
          end
        end
        x0 = loops.flatten(1).map(&:first).min
        y0 = loops.flatten(1).map(&:last).min
        loops.map { |l| l.map { |x, y| [(x - x0).round(3), (y - y0).round(3)] } }
      end
    end
  end
end
