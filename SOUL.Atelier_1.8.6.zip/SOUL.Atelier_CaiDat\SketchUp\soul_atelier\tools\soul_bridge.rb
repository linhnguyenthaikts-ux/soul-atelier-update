# encoding: UTF-8
# Tool: Cầu nối AI – cho trợ lý Claude trên CÙNG máy (qua chương trình MCP của SOUL.Atelier) đọc model SketchUp,
# chụp khung nhìn, chuyển scene, chọn đối tượng và mở tool SOUL.
# An toàn: chỉ nghe 127.0.0.1, mỗi lần bật có mã khóa mới, chỉ nhận lệnh có tên sẵn, không chạy mã tự do,
# không sửa / xóa model. Thông tin kết nối: %AppData%\SOULatelier\bridge\sketchup.json (xóa khi tắt).
require 'socket'
require 'json'
require 'securerandom'
require 'fileutils'

module SoulAtelier
  module AiBridge
    BRIDGE_DIR = File.join(DATA_DIR, 'bridge')
    INFO_FILE  = File.join(BRIDGE_DIR, 'sketchup.json')
    SHOTS_DIR  = File.join(BRIDGE_DIR, 'shots')
    MM = 25.4
    KNOWN = %w[status list_scenes list_tags list_components list_materials selection
               view_image open_scene select list_tools run_tool].freeze
    BLOCKED_TOOLS = %w[soul_bridge].freeze

    @server = nil
    @timer  = nil
    @token  = nil

    def self.running?
      !@server.nil?
    end

    def self.toggle
      running? ? stop : start
      Prefs['Bridge'] = running? ? 1 : 0
      UI.messagebox(running? ?
        "Cầu nối AI ĐANG BẬT.\nTrợ lý trên máy này đọc được model, scene, tag, component, chụp khung nhìn và mở tool SOUL.\nKhông nhận lệnh từ máy khác, không chạy mã tự do." :
        'Cầu nối AI đã TẮT.')
    end

    def self.start
      return if running?
      @server = TCPServer.new('127.0.0.1', 0)
      @token = SecureRandom.hex(16)
      FileUtils.mkdir_p(BRIDGE_DIR)
      File.write(INFO_FILE, JSON.generate(
        'app' => 'sketchup', 'port' => @server.addr[1], 'token' => @token, 'pid' => Process.pid,
        'sketchup' => Sketchup.version, 'soul' => SoulAtelier::VERSION, 'started' => Time.now.strftime('%Y-%m-%dT%H:%M:%S')
      ))
      @timer = UI.start_timer(0.15, true) { poll }
    rescue StandardError => e
      @server = nil
      puts "SOUL.Atelier – Cầu nối AI không bật được: #{e.message}"
    end

    def self.stop
      UI.stop_timer(@timer) if @timer
      @timer = nil
      begin
        @server.close if @server
      rescue StandardError
        nil
      end
      @server = nil
      begin
        File.delete(INFO_FILE) if File.exist?(INFO_FILE) && File.read(INFO_FILE).include?(@token.to_s)
      rescue StandardError
        nil
      end
    end

    # Gọi trên luồng chính của SketchUp (timer) → dùng API SketchUp an toàn
    def self.poll
      return unless @server
      3.times do
        begin
          c = @server.accept_nonblock
        rescue IO::WaitReadable, Errno::EINTR
          return
        end
        serve(c)
      end
    rescue StandardError => e
      puts "SOUL.Atelier – Cầu nối AI: #{e.message}"
    end

    def self.serve(c)
      reply = nil
      begin
        line = IO.select([c], nil, nil, 5) ? c.gets : nil
        raise 'Yêu cầu trống.' if line.nil? || line.strip.empty?
        req = JSON.parse(line.force_encoding('UTF-8'))
        raise 'Sai mã khóa cầu nối.' unless req['token'] == @token
        cmd = req['cmd'].to_s
        raise "Lệnh không có trong danh sách cho phép: #{cmd}" unless KNOWN.include?(cmd)
        reply = { 'ok' => true, 'result' => run(cmd, req['args'] || {}) }
      rescue StandardError => e
        reply = { 'ok' => false, 'error' => e.message }
      end
      c.write(JSON.generate(reply) + "\n")
    ensure
      begin
        c.close
      rescue StandardError
        nil
      end
    end

    # ───────────── lệnh ─────────────

    def self.run(cmd, a)
      return list_tools if cmd == 'list_tools'
      return run_tool(a['name']) if cmd == 'run_tool'
      model = Sketchup.active_model
      raise 'SketchUp chưa mở model.' unless model
      case cmd
      when 'status'          then status(model)
      when 'list_scenes'     then list_scenes(model)
      when 'list_tags'       then list_tags(model, a['filter'])
      when 'list_components' then list_components(model, a['filter'], (a['limit'] || 300).to_i)
      when 'list_materials'  then list_materials(model, a['filter'])
      when 'selection'       then selection(model)
      when 'view_image'      then view_image(model, a['scene'], (a['size'] || 1400).to_i)
      when 'open_scene'      then open_scene(model, a['scene'])
      when 'select'          then select(model, a['ids'] || [])
      else raise "Lệnh chưa hỗ trợ: #{cmd}"
      end
    end

    def self.match?(text, filter)
      filter.nil? || filter.to_s.empty? || text.to_s.downcase.include?(filter.to_s.downcase)
    end

    def self.mm(len)
      (len.to_f * MM).round(1)
    end

    def self.size_mm(bounds)
      [mm(bounds.width), mm(bounds.height), mm(bounds.depth)]
    end

    def self.status(model)
      page = model.pages.selected_page
      {
        'sketchup' => Sketchup.version, 'soul' => SoulAtelier::VERSION,
        'title' => model.title, 'path' => model.path, 'modified' => model.modified?,
        'scenes' => model.pages.size, 'current_scene' => page ? page.name : nil,
        'tags' => model.layers.size, 'components' => model.definitions.count { |d| !d.group? && !d.image? },
        'materials' => model.materials.size, 'selected' => model.selection.size,
        'entities_top' => model.entities.size
      }
    end

    def self.list_scenes(model)
      cur = model.pages.selected_page
      list = model.pages.map { |p| { 'name' => p.name, 'description' => p.description, 'current' => (p == cur) } }
      { 'count' => list.size, 'scenes' => list }
    end

    def self.list_tags(model, filter)
      list = model.layers.select { |l| match?(l.name, filter) }.map do |l|
        c = l.color
        { 'name' => l.name, 'visible' => l.visible?, 'color' => "#{c.red},#{c.green},#{c.blue}" }
      end
      { 'count' => list.size, 'tags' => list }
    end

    def self.list_components(model, filter, limit)
      defs = model.definitions.reject { |d| d.group? || d.image? }.select { |d| match?(d.name, filter) }
      defs = defs.sort_by { |d| -d.count_used_instances }
      list = defs.first([[limit, 1].max, 2000].min).map do |d|
        { 'name' => d.name, 'used' => d.count_used_instances, 'size_mm' => size_mm(d.bounds),
          'description' => d.description.to_s[0, 120] }
      end
      { 'count' => defs.size, 'shown' => list.size, 'components' => list }
    end

    def self.list_materials(model, filter)
      list = model.materials.select { |m| match?(m.display_name, filter) }.map do |m|
        c = m.color
        h = { 'name' => m.display_name, 'color' => "#{c.red},#{c.green},#{c.blue}", 'alpha' => m.alpha.round(2) }
        if m.texture
          h['texture'] = m.texture.filename
          h['texture_mm'] = [mm(m.texture.width), mm(m.texture.height)]
        end
        h
      end
      { 'count' => list.size, 'materials' => list }
    end

    def self.describe(e)
      h = { 'id' => e.persistent_id.to_s, 'type' => e.typename }
      h['tag'] = e.layer.name if e.respond_to?(:layer) && e.layer
      if e.is_a?(Sketchup::ComponentInstance)
        h['component'] = e.definition.name
        h['name'] = e.name unless e.name.empty?
      elsif e.is_a?(Sketchup::Group)
        h['name'] = e.name unless e.name.empty?
      end
      h['material'] = e.material.display_name if e.respond_to?(:material) && e.material
      h['size_mm'] = size_mm(e.bounds) if e.respond_to?(:bounds)
      h
    end

    def self.selection(model)
      sel = model.selection.to_a
      { 'count' => sel.size, 'entities' => sel.first(300).map { |e| describe(e) } }
    end

    def self.view_image(model, scene, size)
      size = [[size, 400].max, 4000].min
      view = model.active_view
      if scene && !scene.to_s.empty?
        page = model.pages[scene.to_s]
        raise "Không có scene \"#{scene}\"." unless page
        model.pages.selected_page = page
      end
      FileUtils.mkdir_p(SHOTS_DIR)
      Dir.glob(File.join(SHOTS_DIR, '*.png')).each do |f|
        begin
          File.delete(f) if File.mtime(f) < Time.now - 1800
        rescue StandardError
          nil
        end
      end
      path = File.join(SHOTS_DIR, "su_#{Time.now.strftime('%H%M%S%L')}.png")
      h = (size.to_f * view.vpheight / [view.vpwidth, 1].max).round
      ok = view.write_image(filename: path, width: size, height: h, antialias: true, transparent: false)
      raise 'SketchUp không xuất được ảnh khung nhìn.' unless ok && File.exist?(path)
      { 'scene' => (model.pages.selected_page ? model.pages.selected_page.name : nil), 'image' => path }
    end

    def self.open_scene(model, scene)
      page = model.pages[scene.to_s]
      raise "Không có scene \"#{scene}\"." unless page
      model.pages.selected_page = page
      { 'opened' => page.name }
    end

    def self.select(model, ids)
      found = Array(ids).map { |i| model.find_entity_by_persistent_id(i.to_i) }.compact
      model.selection.clear
      model.selection.add(found) unless found.empty?
      { 'selected' => found.size }
    end

    def self.list_tools
      SoulAtelier.tools.reject { |t| BLOCKED_TOOLS.include?(t[:id]) }.map { |t| { 'id' => t[:id], 'name' => t[:name] } }
    end

    def self.run_tool(name)
      raise 'Thiếu tên tool (xem list_tools).' if name.nil? || name.to_s.empty?
      t = SoulAtelier.tools.find { |x| x[:id] == name.to_s } ||
          SoulAtelier.tools.find { |x| x[:name].to_s.casecmp(name.to_s).zero? }
      raise "Không có tool SOUL tên \"#{name}\" (xem list_tools)." unless t
      raise "Tool này không cho trợ lý bấm: #{t[:name]}" if BLOCKED_TOOLS.include?(t[:id])
      blk = t[:block]
      # chạy sau khi trả lời (tool có thể mở hộp thoại)
      UI.start_timer(0.05, false) do
        SoulAtelier::License.allowed? ? blk.call : SoulAtelier::License.require_activation
      end
      { 'posted' => t[:name], 'note' => 'Tool đã được mở như bấm nút. Bảng / thao tác của tool hiện trên màn hình SketchUp – cần người thao tác tiếp.' }
    end
  end

  register_tool('soul_bridge', 'Cầu nối AI',
                tooltip: 'Cầu nối AI – cho trợ lý Claude trên máy này đọc model, chụp khung nhìn, mở tool SOUL',
                status: 'Bật / tắt cầu nối cho trợ lý AI trên máy này (chỉ đọc model, chụp khung nhìn, chuyển scene, chọn, mở tool SOUL).',
                icon: 'bridge') do
    SoulAtelier::AiBridge.toggle
  end

  # Nhớ trạng thái bật từ lần trước
  unless file_loaded?(__FILE__)
    UI.start_timer(2, false) { SoulAtelier::AiBridge.start if Prefs['Bridge'].to_i == 1 }
    file_loaded(__FILE__)
  end
end
