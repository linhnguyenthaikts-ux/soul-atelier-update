# encoding: UTF-8
# Tool: Lưu phiên bản – Save As bản mới, không đè file cũ (giống nút Lưu phiên bản bên Revit)
#  - Cùng thư mục, giữ nguyên phần tên phía trước, tăng đuôi Rxx: NHA_PVD_R06.skp → NHA_PVD_R07.skp
#  - Chưa có đuôi Rxx → thêm _R01. Số kế tiếp đã có file → nhảy tới số trống.
#  - File chưa lưu lần nào → hỏi nơi lưu, tên tự thêm _R01.
#  - Sau khi lưu, đang làm việc trên bản mới; bản cũ giữ nguyên như lần lưu gần nhất.
module SoulAtelier
  module SaveVersion
    REV = /\A(?<head>.*?)(?<sep>[_\-\s\.]?)(?<r>[Rr])(?<num>\d{1,4})\z/

    # "NHA_PVD_R06" → "NHA_PVD_R07"; "Nha PVD R9" → "Nha PVD R10"; "NHA_PVD" → "NHA_PVD_R01"
    def self.next_name(name)
      m = REV.match(name)
      return "#{name}_R01" unless m
      num = m[:num]
      nxt = (num.to_i + 1).to_s.rjust([2, num.length].max, '0')
      "#{m[:head]}#{m[:sep]}#{m[:r]}#{nxt}"
    end

    # Đường dẫn bản mới chưa có file
    def self.next_free(path)
      dir  = File.dirname(path)
      ext  = File.extname(path)
      name = File.basename(path, ext)
      500.times do
        name = next_name(name)
        p = File.join(dir, name + ext)
        return p unless File.exist?(p)
      end
      raise 'Không tìm được tên phiên bản trống.'
    end

    def self.run
      model = Sketchup.active_model
      return unless model
      old = model.path.to_s

      if old.empty?
        title = model.title.to_s.strip
        title = 'Du_an' if title.empty?
        target = UI.savepanel('Lưu phiên bản đầu tiên', '', next_name(title) + '.skp')
        return unless target
        target += '.skp' unless target.downcase.end_with?('.skp')
        target = next_free(target) if File.exist?(target)
      else
        target = next_free(old)
      end

      ok = model.save(target)   # lưu với tên mới = Save As: model chuyển sang file mới
      unless ok
        UI.messagebox("Không lưu được phiên bản mới:\n#{target}")
        return
      end
      msg = "Đã lưu phiên bản #{File.basename(target, '.skp')}\n\n"
      msg << "Bản cũ giữ nguyên: #{File.basename(old)}\n" unless old.empty?
      msg << "Đang làm việc trên: #{File.basename(target)}\nThư mục: #{File.dirname(target)}"
      Sketchup.status_text = "SOUL.Atelier: đã lưu #{File.basename(target)}"
      UI.messagebox(msg)
    rescue StandardError => e
      UI.messagebox("Lưu phiên bản bị lỗi: #{e.message}")
    end
  end
end

SoulAtelier.register_tool('save_version', 'Lưu phiên bản',
  :tooltip => 'Lưu phiên bản – Save As tự tăng R06 → R07',
  :status  => 'Lưu bản mới cùng thư mục, không đè file cũ: ..._R06 → ..._R07 (chưa có đuôi → _R01). Dùng khi làm nhiều phương án.',
  :icon    => 'save_version') { SoulAtelier::SaveVersion.run }
