# encoding: UTF-8
# SOUL.Atelier – SketchUp Bridge
# Xuất góc nhìn hiện tại thành bản vẽ 2D (PDF vector, đã khử nét khuất) + thông tin camera,
# để add-in SOUL.Atelier trong Revit dán vào bằng nút "Dán 2D SketchUp".
require 'sketchup.rb'
require 'json'
require 'fileutils'

module SoulAtelier
  module SuBridge
    PLUGIN_VERSION = '1.0.2'.freeze
    BRIDGE_DIR     = File.join(ENV['APPDATA'] || File.expand_path('~'), 'SOULatelier', 'su_bridge').freeze
    DRAWING_SCALE  = 50.0  # xuất PDF ở tỉ lệ 1:50 (Revit tự quy đổi về kích thước thật)
    MM             = 25.4  # 1 inch = 25.4 mm

    def self.copy_2d
      model = Sketchup.active_model
      return UI.messagebox('Chưa mở mô hình SketchUp.') unless model

      view = model.active_view
      cam  = view.camera
      was_perspective = cam.perspective?
      if was_perspective
        answer = UI.messagebox(
          "Góc nhìn đang ở chế độ phối cảnh (Perspective).\n\n" \
          "Bản vẽ 2D cần chế độ Parallel Projection để đúng tỉ lệ.\n" \
          "Chuyển tạm sang Parallel Projection để xuất?", MB_YESNO)
        return unless answer == IDYES
        cam.perspective = false
      end

      FileUtils.mkdir_p(BRIDGE_DIR)
      pdf_path  = File.join(BRIDGE_DIR, 'clip.pdf')
      json_path = File.join(BRIDGE_DIR, 'clip.json')
      [pdf_path, json_path].each { |f| File.delete(f) if File.exist?(f) }

      selection = model.selection.to_a
      info = nil
      ok = false

      # Mọi thay đổi tạm (ẩn đối tượng không chọn) nằm trong 1 thao tác và được hoàn tác ngay sau khi xuất.
      model.start_operation('SOUL.Atelier – Copy 2D', true)
      begin
        hide_unselected(model, selection) unless selection.empty?
        info = view_info(model, view)
        options = {
          :full_scale              => true,
          :drawing_units           => Length::Millimeter,
          :model_units             => Length::Millimeter,
          :length_in_drawing       => 1.0,
          :length_in_model         => DRAWING_SCALE,
          :output_profile_lines    => true,
          :output_section_lines    => true,
          :match_screen_profiles   => true,
          :match_screen_section    => true,
          :edge_extensions         => false,
          :match_screen_extensions => false,
          :map_fonts               => true
        }
        ok = model.export(pdf_path, options)
      rescue StandardError => e
        UI.messagebox("Không xuất được bản vẽ 2D:\n#{e.message}")
        ok = false
      ensure
        model.abort_operation
        cam.perspective = true if was_perspective
      end

      unless ok && File.exist?(pdf_path)
        UI.messagebox("SketchUp không xuất được bản vẽ 2D.\n" \
                      "Lưu ý: tính năng này cần SketchUp Pro (có xuất PDF 2D).")
        return
      end

      info['selection_only'] = !selection.empty?
      File.open(json_path, 'w:UTF-8') { |f| f.write(JSON.pretty_generate(info)) }

      Sketchup.status_text = 'SOUL.Atelier: đã copy 2D. Sang Revit bấm "Dán 2D SketchUp".'
      notify('Đã copy góc nhìn 2D. Sang Revit bấm "Dán 2D SketchUp".')
    end

    # Ẩn tạm các đối tượng không được chọn (trong ngữ cảnh đang mở)
    def self.hide_unselected(model, selection)
      keep = {}
      selection.each { |e| keep[e.entityID] = true }
      model.active_entities.each do |e|
        next if keep[e.entityID]
        next unless e.respond_to?(:hidden=)
        e.hidden = true unless e.hidden?
      end
    end

    # Thông tin camera để Revit quy đổi tỉ lệ và tọa độ
    def self.view_info(model, view)
      cam = view.camera
      vw = view.vpwidth.to_f
      vh = view.vpheight.to_f
      h_in = cam.height.to_f
      w_in = h_in * vw / vh
      t  = cam.target
      xa = cam.xaxis
      ya = cam.yaxis
      dir = cam.direction
      ll = [
        t.x.to_f - xa.x * w_in / 2 - ya.x * h_in / 2,
        t.y.to_f - xa.y * w_in / 2 - ya.y * h_in / 2,
        t.z.to_f - xa.z * w_in / 2 - ya.z * h_in / 2
      ].map { |v| v * MM }

      section_active =
        begin
          !model.active_entities.active_section_plane.nil? || !model.entities.active_section_plane.nil?
        rescue StandardError
          false
        end

      {
        'format'         => 1,
        'plugin'         => PLUGIN_VERSION,
        'sketchup'       => Sketchup.version.to_s,
        'created'        => Time.now.strftime('%Y-%m-%dT%H:%M:%S'),
        'model'          => model.title.to_s,
        'drawing_scale'  => DRAWING_SCALE,
        'section_active' => section_active,
        'view' => {
          'height_mm'     => h_in * MM,
          'width_mm'      => w_in * MM,
          'vp_width'      => vw,
          'vp_height'     => vh,
          'lower_left_mm' => ll,
          'xaxis'         => [xa.x, xa.y, xa.z].map(&:to_f),
          'yaxis'         => [ya.x, ya.y, ya.z].map(&:to_f),
          'direction'     => [dir.x, dir.y, dir.z].map(&:to_f)
        }
      }
    end

    def self.notify(text)
      if defined?(UI::Notification) && defined?(SOUL_EXTENSION)
        UI::Notification.new(SOUL_EXTENSION, text).show
      end
    rescue StandardError
      nil
    end

    def self.about
      UI.messagebox("SOUL.Atelier – SketchUp Bridge #{PLUGIN_VERSION}\n\n" \
                    "Copy góc nhìn 2D từ SketchUp sang Revit.\n" \
                    "Được tạo ra bởi Nguyễn Thái Linh.")
    end

    unless file_loaded?(__FILE__)
      SOUL_EXTENSION = Sketchup.extensions['SOUL.Atelier'] rescue nil

      icons = File.join(__dir__, 'icons')
      cmd = UI::Command.new('Copy 2D sang Revit') { copy_2d }
      cmd.tooltip         = 'Copy 2D sang Revit'
      cmd.status_bar_text = 'Xuất góc nhìn hiện tại thành bản vẽ 2D để dán vào Revit (SOUL.Atelier).'
      cmd.small_icon      = File.join(icons, 'copy2d_16.png')
      cmd.large_icon      = File.join(icons, 'copy2d_24.png')

      menu = UI.menu('Extensions').add_submenu('SOUL.Atelier')
      menu.add_item(cmd)
      menu.add_separator
      menu.add_item('Giới thiệu') { about }

      toolbar = UI::Toolbar.new('SOUL.Atelier')
      toolbar.add_item(cmd)
      if toolbar.get_last_state == TB_NEVER_SHOWN
        toolbar.show
      else
        toolbar.restore
      end

      file_loaded(__FILE__)
    end
  end
end
