# encoding: UTF-8
# SOUL.Atelier – bộ công cụ SketchUp. Tạo bởi Nguyễn Thái Linh.
# Khởi động: nạp lõi → tự nạp mọi tool trong thư mục tools/ → dựng menu & toolbar → kiểm tra cập nhật.
require 'sketchup.rb'

module SoulAtelier
  dir = File.dirname(__FILE__)
  %w[app_info registry mini_zip updater license dialogs].each do |f|
    Sketchup.require(File.join(dir, 'core', f))
  end

  # Mỗi tool là 1 file trong tools/ (.rb hoặc .rbe đã mã hóa)
  Dir.glob(File.join(dir, 'tools', '*.{rb,rbe}')).map { |f| f.sub(/\.(rb|rbe)\z/, '') }.uniq.sort.each do |f|
    begin
      Sketchup.require(f)
    rescue StandardError, ScriptError => e
      puts "SOUL.Atelier: không nạp được tool #{File.basename(f)} – #{e.message}"
    end
  end

  unless file_loaded?(__FILE__)
    menu = UI.menu('Extensions').add_submenu('SOUL.Atelier')
    toolbar = UI::Toolbar.new('SOUL.Atelier')

    SoulAtelier.tools.each do |t|
      blk = t[:block]
      # Tool chỉ chạy khi máy đã kích hoạt (hoặc bản cài không yêu cầu kích hoạt)
      cmd = UI::Command.new(t[:name]) { SoulAtelier::License.allowed? ? blk.call : SoulAtelier::License.require_activation }
      cmd.tooltip = t[:tooltip]
      cmd.status_bar_text = t[:status]
      if t[:icon]
        cmd.small_icon = SoulAtelier.icon(t[:icon], 16)
        cmd.large_icon = SoulAtelier.icon(t[:icon], 24)
      end
      menu.add_item(cmd)
      toolbar.add_item(cmd) if t[:toolbar]
    end

    menu.add_separator
    toolbar.add_separator

    ver = UI::Command.new('Phiên bản') { SoulAtelier::Dialogs.show_version }
    ver.tooltip = 'Phiên bản & cập nhật'
    ver.status_bar_text = "SOUL.Atelier #{SoulAtelier::VERSION} – xem bản mới và nội dung cập nhật."
    ver.small_icon = SoulAtelier.icon('version', 16)
    ver.large_icon = SoulAtelier.icon('version', 24)
    menu.add_item(ver)
    toolbar.add_item(ver)

    acc = UI::Command.new('Tài khoản') { SoulAtelier::Dialogs.show_account }
    acc.tooltip = 'Tài khoản / kích hoạt'
    acc.status_bar_text = 'Kích hoạt SOUL.Atelier bằng Gmail, xem trạng thái, gỡ kích hoạt máy.'
    acc.small_icon = SoulAtelier.icon('account', 16)
    acc.large_icon = SoulAtelier.icon('account', 24)
    menu.add_item(acc)
    toolbar.add_item(acc)

    about = UI::Command.new('Giới thiệu') { SoulAtelier::Dialogs.show_about }
    about.tooltip = 'Giới thiệu SOUL.Atelier'
    about.status_bar_text = 'Giới thiệu SOUL.Atelier – tạo bởi Nguyễn Thái Linh.'
    about.small_icon = SoulAtelier.icon('about', 16)
    about.large_icon = SoulAtelier.icon('about', 24)
    menu.add_item(about)
    toolbar.add_item(about)

    if toolbar.get_last_state == TB_NEVER_SHOWN
      toolbar.show
    else
      toolbar.restore
    end

    SoulAtelier::Updater.check_on_startup
    SoulAtelier::License.check_on_startup
    file_loaded(__FILE__)
  end
end
