# encoding: UTF-8
# SOUL.Atelier – thông tin chung cho mọi tool SketchUp
module SoulAtelier
  NAME       = 'SOUL.Atelier'.freeze
  AUTHOR     = 'Nguyễn Thái Linh'.freeze
  VERSION    = '1.7.1'.freeze          # được đóng dấu tự động lúc đóng gói
  UPDATE_URL = 'https://raw.githubusercontent.com/linhnguyenthaikts-ux/soul-atelier-update/main/'.freeze               # được đóng dấu tự động lúc đóng gói (thư mục chứa version.json)
  LICENSE_URL = 'https://script.google.com/macros/s/AKfycbztaYW6R-BiWFpsgCRHrACZq6zM9szWSdg9GQUAkRAeG09rJ33x18CSDqPH9lZoDdy8fA/exec'.freeze              # máy chủ bản quyền (Apps Script) – đóng dấu lúc đóng gói
  LICENSE_KEY = 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEArbj5ER0bpBLIfK82/kq7oSBxHUriOX6WkSAF/2hOstMxYT3H6+Zdf8rJi9ef3vD+tVQOJysUmBGuIfVg5gsQ8gWS6jcP5ZNYWKo4vO6iPWp74KQkXNeAGU8VbC5siRMhyagvotnjvdIRxojXep9ajIlqrVOZ7uhrnP3AOKQ9BoTGNaaF8n2vaHyrbbz1Ml9ms7JhkSSpkMOeQPi7BZTFKA06pEZqjg12Ch7a2b8UMW8wVgI98W9yFVTIca+0qQiKtQg8HKcSNJ+vu91i6ORQXb31vm9T0nJwIMkjuf9c8AERAjzpSBnK5EpftVCvHtzg0g2tsmGgJxwhPmmFLUWBlQIDAQAB'.freeze              # khóa công khai xác minh giấy phép – đóng dấu lúc đóng gói

  ROOT_DIR    = File.expand_path('..', File.dirname(__FILE__)).freeze   # .../Plugins/soul_atelier
  PLUGINS_DIR = File.expand_path('..', ROOT_DIR).freeze                 # .../Plugins
  ICONS_DIR   = File.join(ROOT_DIR, 'icons').freeze
  DATA_DIR    = File.join(ENV['APPDATA'] || File.expand_path('~'), 'SOULatelier').freeze

  def self.icon(name, size)
    File.join(ICONS_DIR, "#{name}_#{size}.png")
  end

  # Lưu trạng thái nhỏ trong registry của SketchUp
  module Prefs
    SECTION = 'SOULatelier'.freeze
    def self.[](key)
      Sketchup.read_default(SECTION, key.to_s)
    end

    def self.[]=(key, value)
      Sketchup.write_default(SECTION, key.to_s, value)
    end
  end

  # So sánh phiên bản dạng "1.2.3"
  def self.compare_versions(a, b)
    pa = a.to_s.sub(/\Av/i, '').split('.').map(&:to_i)
    pb = b.to_s.sub(/\Av/i, '').split('.').map(&:to_i)
    n = [pa.size, pb.size, 3].max
    pa.fill(0, pa.size...n) <=> pb.fill(0, pb.size...n)
  end
end
