@echo off
setlocal enabledelayedexpansion
title SOUL.Atelier - Cai dat
cd /d "%~dp0"

echo ==================================================
echo   SOUL.Atelier - Bo cong cu Revit
echo   by Nguyen Thai Linh
echo ==================================================
echo.
echo Hay DONG tat ca Revit truoc khi cai.
pause

rem Go chan "file tai tu Internet" de Revit nap duoc add-in
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath '%~dp0' -Recurse | Unblock-File" >nul 2>nul

set COUNT=0
set FAIL=0
for /d %%V in (20*) do (
  if exist "C:\Program Files\Autodesk\Revit %%V\Revit.exe" (
    set "DEST=%APPDATA%\Autodesk\Revit\Addins\%%V"
    if not exist "!DEST!\SOUL.Atelier" mkdir "!DEST!\SOUL.Atelier"

    rem Go ban thu nghiem cu (SoulCadPaste) neu co
    if exist "!DEST!\SoulCadPaste.addin" del /q "!DEST!\SoulCadPaste.addin"
    if exist "!DEST!\SoulCadPaste" rmdir /s /q "!DEST!\SoulCadPaste"

    rem Xoa ban cap nhat dang cho (neu co) de khong ghi de ban vua cai
    if exist "%APPDATA%\SOULatelier\updates\pending\%%V" rmdir /s /q "%APPDATA%\SOULatelier\updates\pending\%%V"
    if exist "%APPDATA%\SOULatelier\updates\pending\%%V.version" del /q "%APPDATA%\SOULatelier\updates\pending\%%V.version"

    copy /y "%%V\SoulAtelier.dll" "!DEST!\SOUL.Atelier\" >nul
    if errorlevel 1 (
      echo   [LOI] Revit %%V: khong chep duoc file. Revit %%V dang mo?
      set /a FAIL+=1
    ) else (
      copy /y "SOUL.Atelier.addin" "!DEST!\" >nul
      echo   [OK] Da cai cho Revit %%V
      set /a COUNT+=1
    )
  )
)

echo.
if !COUNT!==0 if !FAIL!==0 (
  echo Khong tim thay phien ban Revit phu hop tren may nay.
  echo Bo cai ho tro:
  for /d %%V in (20*) do echo   - Revit %%V
  goto end
)
if !FAIL! gtr 0 echo Co loi: hay dong Revit roi chay lai CAI_DAT.bat.
if !COUNT! gtr 0 (
  echo XONG. Mo Revit, bam "Always Load" khi duoc hoi,
  echo roi vao tab "SOUL.Atelier".
  echo Cac ban sau se TU DONG cap nhat khi tat va mo lai Revit.
)
:end
echo.
pause
