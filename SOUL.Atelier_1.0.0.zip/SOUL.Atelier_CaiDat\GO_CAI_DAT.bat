@echo off
setlocal
title SOUL.Atelier - Go cai dat
echo Hay DONG tat ca Revit truoc khi go.
pause
for /d %%D in ("%APPDATA%\Autodesk\Revit\Addins\20*") do (
  if exist "%%D\SOUL.Atelier.addin" (
    del /q "%%D\SOUL.Atelier.addin"
    rmdir /s /q "%%D\SOUL.Atelier" 2>nul
    echo   Da go khoi Revit %%~nxD
  )
)
rmdir /s /q "%APPDATA%\SOULatelier" 2>nul
echo XONG.
pause
