# encoding: UTF-8
# Nơi các tool tự đăng ký. Mỗi file trong thư mục tools/ gọi SoulAtelier.register_tool(...)
# để có nút trên toolbar SOUL.Atelier và mục trong menu Extensions → SOUL.Atelier.
module SoulAtelier
  @tools = [] unless defined?(@tools)

  # id      : mã tool, ví dụ 'copy_2d'
  # name    : tên hiển thị
  # tooltip : chú thích khi rê chuột
  # icon    : tên icon trong thư mục icons (cần file <icon>_16.png và <icon>_24.png)
  # toolbar : false = chỉ hiện trong menu
  def self.register_tool(id, name, options = {}, &block)
    @tools.reject! { |t| t[:id] == id }
    @tools << {
      :id      => id,
      :name    => name,
      :tooltip => options[:tooltip] || name,
      :status  => options[:status] || '',
      :icon    => options[:icon],
      :toolbar => options.fetch(:toolbar, true),
      :block   => block
    }
  end

  def self.tools
    @tools
  end
end
