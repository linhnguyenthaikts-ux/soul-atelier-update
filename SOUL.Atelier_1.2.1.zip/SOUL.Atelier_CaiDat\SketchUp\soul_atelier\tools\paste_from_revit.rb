# encoding: UTF-8
# Tool: Dán 2D từ Revit
# Đọc bản vẽ 2D do nút "Copy 2D sang SketchUp" trong Revit xuất ra (%AppData%\SOULatelier\rv_bridge),
# dựng thành nét trong SketchUp, gom vào 1 group "Revit - <tên view>".
#  - Family giống nhau → cùng 1 component (sửa 1 cái, các cái khác chạy theo).
#  - Layer của Revit/CAD → Tag "RV_<layer>".
#  - Mặt bằng nằm ngang; mặt đứng / mặt cắt dựng đứng theo đúng hướng nhìn trong Revit.
require 'json'
require 'digest'

module SoulAtelier
  module PasteFromRevit
    BRIDGE_DIR = File.join(SoulAtelier::DATA_DIR, 'rv_bridge').freeze

    ORIENT = ['Tự động theo view Revit', 'Nằm ngang', 'Dựng đứng'].freeze
    PLACE  = ['Click chọn điểm', 'Theo gốc tọa độ'].freeze

    def self.run
      model = Sketchup.active_model
      return UI.messagebox('Chưa mở mô hình SketchUp.') unless model
      json_path = File.join(BRIDGE_DIR, 'clip.json')
      unless File.exist?(json_path)
        return UI.messagebox("Chưa có bản vẽ nào được copy từ Revit.\n\n" \
                             'Trong Revit: chọn đối tượng (hoặc không chọn để lấy cả view) → ' \
                             'tab SOUL.Atelier → "Copy 2D sang SketchUp".')
      end
      info = JSON.parse(File.read(json_path, :mode => 'rb').force_encoding('UTF-8').sub(/\A﻿/, ''))
      dxf_path = File.join(BRIDGE_DIR, info['dxf'].to_s.empty? ? 'clip.dxf' : info['dxf'])
      return UI.messagebox('Không tìm thấy file bản vẽ từ Revit. Hãy copy lại trong Revit.') unless File.exist?(dxf_path)

      opts = ask_options(info)
      return unless opts

      dxf = nil
      begin
        dxf = DxfReader.read(dxf_path)
      rescue StandardError => e
        return UI.messagebox("Không đọc được bản vẽ từ Revit:\n#{e.message}")
      end

      group = nil
      stats = nil
      model.start_operation('SOUL.Atelier – Dán 2D từ Revit', true)
      begin
        group, stats = build(model, dxf, info, opts)
        model.commit_operation
      rescue StandardError => e
        model.abort_operation
        return UI.messagebox("Không dựng được bản vẽ:\n#{e.message}")
      end
      if group.nil? || !group.valid? || group.entities.size.zero?
        group.erase! if group && group.valid?
        return UI.messagebox('Bản vẽ từ Revit không có nét nào đọc được.')
      end

      report(info, dxf, stats)
      rot = orientation(info, opts)
      if opts[:origin]
        model.start_operation('Đặt bản vẽ', true, false, true)
        group.transformation = rot
        model.commit_operation
      else
        bb = group.bounds
        base = Geom::Point3d.new(bb.min.x, bb.min.y, 0)
        model.select_tool(PlaceTool.new(group, rot, base))
      end
    end

    # ------------------------------------------------------------------ tùy chọn

    def self.ask_options(info)
      prompts = ['Hướng đặt', 'Family giống nhau → cùng component', 'Tạo tag theo layer',
                 'Tạo mặt (face) cho vùng kín', 'Điểm chèn']
      defaults = [
        Prefs['rv_orient'] || ORIENT[0],
        Prefs['rv_blocks'] || 'Có',
        Prefs['rv_tags'] || 'Có',
        Prefs['rv_faces'] || 'Không',
        Prefs['rv_place'] || PLACE[0]
      ]
      lists = [ORIENT.join('|'), 'Có|Không', 'Có|Không', 'Không|Có', PLACE.join('|')]
      title = "Dán 2D từ Revit – #{info['view_name']}"
      res = UI.inputbox(prompts, defaults, lists, title)
      return nil unless res
      Prefs['rv_orient'], Prefs['rv_blocks'], Prefs['rv_tags'], Prefs['rv_faces'], Prefs['rv_place'] = res
      {
        :orient => res[0] == ORIENT[1] ? 'flat' : (res[0] == ORIENT[2] ? 'upright' : 'auto'),
        :blocks => res[1] == 'Có',
        :tags   => res[2] == 'Có',
        :faces  => res[3] == 'Có',
        :origin => res[4] == PLACE[1]
      }
    end

    # Mặt bằng: nằm trên mặt phẳng đỏ-xanh lá. Mặt đứng/mặt cắt: dựng đứng, trục ngang theo hướng view Revit.
    def self.orientation(info, opts)
      upright = opts[:orient] == 'upright' || (opts[:orient] == 'auto' && !info['plan_like'])
      return Geom::Transformation.new unless upright
      r = info['right'] || [1, 0, 0]
      ang = Math.atan2(r[1].to_f, r[0].to_f)
      Geom::Transformation.rotation(ORIGIN, Z_AXIS, ang) * Geom::Transformation.rotation(ORIGIN, X_AXIS, 90.degrees)
    end

    # ------------------------------------------------------------------ dựng hình

    def self.build(model, dxf, info, opts)
      group = model.active_entities.add_group
      group.name = "Revit - #{info['view_name']}"
      ctx = { :model => model, :dxf => dxf, :opts => opts, :defs => {}, :sigs => {}, :sig_cache => {},
              :tags => {}, :edges => 0, :instances => 0, :shared => 0 }
      add_items(ctx, group.entities, dxf[:items], DxfReader.identity, nil, 0)
      if opts[:faces]
        targets = [group.entities] + ctx[:defs].values.compact.uniq.map(&:entities)
        targets.each { |ents| ents.grep(Sketchup::Edge).each { |e| e.find_faces if e.valid? } }
      end
      [group, ctx]
    end

    def self.add_items(ctx, ents, items, m, inherited, depth)
      return if depth > 16
      dxf = ctx[:dxf]
      translation_only = (m[0] - 1).abs < 1e-9 && m[1].abs < 1e-9 && m[2].abs < 1e-9 && (m[3] - 1).abs < 1e-9
      items.each do |it|
        ly = it[1] == '0' && inherited ? inherited : it[1]
        tag = tag_for(ctx, ly)
        case it[0]
        when :poly
          pts = it[2].map { |x, y| pt(DxfReader.apply(m, x, y)) }
          pts << pts[0] if it[3]
          pts = dedupe(pts)
          next if pts.size < 2
          set_tag(ctx, safe { ents.add_edges(pts) }, tag)
        when :arc
          cx, cy, r, a0, a1 = it[2..6]
          edges =
            if translation_only
              center = pt(DxfReader.apply(m, cx, cy))
              if a1 - a0 >= DxfReader::TWO_PI - 1e-6
                safe { ents.add_circle(center, Z_AXIS, r.mm, 48) }
              else
                segs = [[(48 * (a1 - a0) / DxfReader::TWO_PI).ceil, 2].max, 48].min
                safe { ents.add_arc(center, X_AXIS, Z_AXIS, r.mm, a0, a1, segs) }
              end
            else
              pts = dedupe(DxfReader.arc_points(cx, cy, r, a0, a1).map { |x, y| pt(DxfReader.apply(m, x, y)) })
              pts.size >= 2 ? safe { ents.add_curve(pts) } : nil
            end
          set_tag(ctx, edges, tag)
        when :insert
          blk = dxf[:blocks][it[2]]
          next unless blk
          im = DxfReader.compose(m, DxfReader.insert_matrix(dxf, it[2], it[3]))
          if ctx[:opts][:blocks]
            definition = definition_for(ctx, it[2], depth)
            next unless definition
            inst = ents.add_instance(definition, to_transformation(im))
            inst.layer = tag if tag
            ctx[:instances] += 1
          else
            add_items(ctx, ents, blk[:items], im, ly, depth + 1)
          end
        end
      end
    end

    # Block → component. Block có hình giống hệt nhau (vd cùng loại cửa) dùng chung 1 component.
    def self.definition_for(ctx, name, depth)
      return ctx[:defs][name] if ctx[:defs].key?(name)
      blk = ctx[:dxf][:blocks][name]
      return (ctx[:defs][name] = nil) unless blk
      sig = signature(ctx, name, 0)
      if ctx[:sigs].key?(sig)
        ctx[:shared] += 1
        return (ctx[:defs][name] = ctx[:sigs][sig])
      end
      d = ctx[:model].definitions.add(clean_name(name))
      ctx[:defs][name] = d
      ctx[:sigs][sig] = d
      add_items(ctx, d.entities, blk[:items], DxfReader.identity, nil, depth + 1)
      if d.entities.size.zero?
        ctx[:defs][name] = nil
        ctx[:sigs][sig] = nil
        return nil
      end
      d
    end

    # Dấu vân tay hình học của block (làm tròn 0,01 mm) – dùng để nhận ra block giống nhau
    def self.signature(ctx, name, depth)
      return ctx[:sig_cache][name] if ctx[:sig_cache].key?(name)
      blk = ctx[:dxf][:blocks][name]
      parts = []
      if blk && depth < 16
        blk[:items].each do |it|
          case it[0]
          when :poly
            parts << "P#{it[1]}|#{it[3]}|" + it[2].map { |x, y| "#{(x - blk[:base][0]).round(2)},#{(y - blk[:base][1]).round(2)}" }.join(';')
          when :arc
            parts << "A#{it[1]}|#{(it[2] - blk[:base][0]).round(2)},#{(it[3] - blk[:base][1]).round(2)},#{it[4].round(2)},#{it[5].round(4)},#{it[6].round(4)}"
          when :insert
            mm = it[3].each_with_index.map { |v, i| i < 4 ? v.round(5) : (v - blk[:base][i - 4]).round(2) }
            parts << "I#{it[1]}|#{signature(ctx, it[2], depth + 1)}|#{mm.join(',')}"
          end
        end
      end
      ctx[:sig_cache][name] = Digest::MD5.hexdigest(parts.sort.join("\n"))
    end

    def self.to_transformation(m)
      Geom::Transformation.new([m[0], m[1], 0, 0, m[2], m[3], 0, 0, 0, 0, 1, 0, m[4].mm.to_f, m[5].mm.to_f, 0, 1])
    end

    def self.pt(xy)
      Geom::Point3d.new(xy[0].mm, xy[1].mm, 0)
    end

    def self.dedupe(pts)
      out = []
      pts.each { |p| out << p if out.empty? || out.last.distance(p) > 0.001 }
      out
    end

    def self.safe
      yield
    rescue StandardError
      nil
    end

    def self.tag_for(ctx, ly)
      return nil unless ctx[:opts][:tags] && ly && ly != '0'
      ctx[:tags][ly] ||= ctx[:model].layers.add("RV_#{ly}")
    end

    def self.set_tag(ctx, edges, tag)
      list = edges.is_a?(Array) ? edges : [edges]
      list.each do |e|
        next unless e && e.valid?
        e.layer = tag if tag
        ctx[:edges] += 1
      end
    end

    # Tên block Revit thường dạng "Họ-Kiểu-123456-View": bỏ phần số định danh phía sau
    def self.clean_name(name)
      n = name.to_s.sub(/-\d{4,}.*\z/, '').strip
      n = name.to_s if n.empty?
      n[0, 80]
    end

    def self.report(info, dxf, stats)
      skipped = dxf[:skipped].reject { |k, _| k.nil? }
      text = "Đã dán #{info['view_name']}"
      text += " – #{stats[:instances]} component (#{stats[:shared]} lần dùng chung)" if stats[:instances] > 0
      unless skipped.empty?
        names = { 'TEXT' => 'chữ', 'MTEXT' => 'chữ', 'HATCH' => 'hatch', 'SOLID' => 'mảng tô' }
        grouped = Hash.new(0)
        skipped.each { |k, v| grouped[names[k] || k.downcase] += v }
        text += '. Bỏ qua: ' + grouped.map { |k, v| "#{v} #{k}" }.join(', ')
      end
      Sketchup.status_text = "SOUL.Atelier: #{text}"
      ext = Sketchup.extensions['SOUL.Atelier'] rescue nil
      UI::Notification.new(ext, text + '.').show if defined?(UI::Notification) && ext
    rescue StandardError
      nil
    end

    # ------------------------------------------------------------------ chọn điểm chèn

    class PlaceTool
      def initialize(group, rot, base)
        @group = group
        @rot = rot
        @base = base
        @ip = Sketchup::InputPoint.new
      end

      def activate
        Sketchup.status_text = 'SOUL.Atelier: click điểm chèn (góc dưới-trái bản vẽ). Esc = đặt tại gốc tọa độ.'
      end

      def onMouseMove(_flags, x, y, view)
        @ip.pick(view, x, y)
        view.tooltip = @ip.tooltip if @ip.valid?
        view.invalidate
      end

      def draw(view)
        @ip.draw(view) if @ip.valid? && @ip.display?
      end

      def onLButtonDown(_flags, x, y, view)
        @ip.pick(view, x, y)
        return unless @ip.valid?
        place(@ip.position)
        Sketchup.active_model.select_tool(nil)
      end

      def onCancel(_reason, _view)
        place(nil)
        Sketchup.active_model.select_tool(nil)
      end

      def deactivate(view)
        place(nil) unless @placed
        view.invalidate
      end

      def place(point)
        return if @placed || !@group.valid?
        @placed = true
        model = Sketchup.active_model
        model.start_operation('Đặt bản vẽ', true, false, true)
        @group.transformation = point ? Geom::Transformation.translation(point - @rot * @base) * @rot : @rot
        model.commit_operation
        model.selection.clear
        model.selection.add(@group)
      end
    end
  end
end

SoulAtelier.register_tool('paste_revit', 'Dán 2D từ Revit',
  :tooltip => 'Dán bản vẽ 2D vừa copy trong Revit',
  :status  => 'Dán view / đối tượng vừa "Copy 2D sang SketchUp" trong Revit; family giống nhau thành cùng component.',
  :icon    => 'rv_paste') { SoulAtelier::PasteFromRevit.run }
