# encoding: UTF-8
# Kích hoạt bằng Gmail – dùng chung giấy phép với add-in Revit (%AppData%\SOULatelier\license.json).
# Quản trị duyệt trên Google Sheet, mỗi Gmail tối đa 2 máy. Giấy phép có chữ ký số, hạn 30 ngày, tự gia hạn.
require 'json'
require 'openssl'
require 'digest'
require 'time'
require 'fileutils'

module SoulAtelier
  module License
    @requests = [] unless defined?(@requests)
    @became_active = false unless defined?(@became_active)

    def self.file_path
      File.join(SoulAtelier::DATA_DIR, 'license.json')
    end

    def self.enabled?
      !SoulAtelier::LICENSE_URL.to_s.empty? && !SoulAtelier::LICENSE_KEY.to_s.empty?
    end

    # ---------------------------------------------------------------- Máy

    # Băm từ MachineGuid của Windows – giống hệt cách tính bên Revit
    def self.machine_id
      @machine_id ||= begin
        guid = nil
        begin
          require 'win32/registry'
          Win32::Registry::HKEY_LOCAL_MACHINE.open('SOFTWARE\Microsoft\Cryptography',
                                                   Win32::Registry::KEY_READ | 0x0100) { |r| guid = r['MachineGuid'] }
        rescue StandardError, LoadError
          guid = nil
        end
        guid = ENV['COMPUTERNAME'].to_s if guid.nil? || guid.to_s.strip.empty?
        Digest::SHA256.hexdigest("SOUL.Atelier:#{guid.to_s.strip.downcase}")[0, 32].upcase
      end
    end

    def self.machine_name
      ENV['COMPUTERNAME'].to_s
    end

    def self.machine_short
      "#{machine_id[0, 4]}-#{machine_id[4, 4]}"
    end

    # ---------------------------------------------------------------- Trạng thái

    def self.allowed?
      !enabled? || !payload.nil?
    end

    def self.payload
      return nil unless enabled?
      verify_token(load['token'])
    end

    def self.state_text
      return ['Bản cài này không yêu cầu kích hoạt.', true] unless enabled?
      p = payload
      if p
        exp = Time.at(p['exp'].to_i).strftime('%d/%m/%Y')
        return ["Đã kích hoạt cho #{p['email']} · hiệu lực đến #{exp} (tự gia hạn khi có mạng).", true]
      end
      f = load
      case f['state']
      when 'pending' then ["Đã xác nhận Gmail #{f['email']}. Đang chờ quản trị SOUL.Atelier duyệt.", false]
      when 'locked'  then ["Tài khoản #{f['email']} đã bị khóa. Liên hệ quản trị.", false]
      when 'removed' then ['Máy này đã bị gỡ kích hoạt. Hãy kích hoạt lại.', false]
      else ['Chưa kích hoạt. Nhập Gmail để nhận mã xác nhận.', false]
      end
    end

    # Gọi khi bấm tool mà chưa kích hoạt
    def self.require_activation
      SoulAtelier::Dialogs.show_account('Tool này cần kích hoạt SOUL.Atelier trước khi dùng.')
    end

    # ---------------------------------------------------------------- Máy chủ

    def self.request_code(email, &done)
      call('request_code', 'email' => email) { |r| done.call(r) }
    end

    def self.verify(email, code, &done)
      call('verify', 'email' => email, 'code' => code) do |r|
        apply(r, email)
        done.call(r)
      end
    end

    def self.refresh(&done)
      f = load
      if f['email'].to_s.empty? || f['device_key'].to_s.empty?
        done.call('ok' => false, 'error' => 'Máy này chưa kích hoạt.')
        return
      end
      call('status', 'email' => f['email'], 'device_key' => f['device_key']) do |r|
        apply(r, f['email'])
        done.call(r)
      end
    end

    def self.deactivate(&done)
      f = load
      call('deactivate', 'email' => f['email'].to_s, 'device_key' => f['device_key'].to_s) do |r|
        save('email' => f['email'], 'state' => 'removed') if r['ok']
        done.call(r)
      end
    end

    # Mở SketchUp → kiểm tra lại ngầm (tối đa 1 lần/ngày, hoặc khi đang chờ duyệt)
    def self.check_on_startup
      return unless enabled?
      f = load
      return if f['device_key'].to_s.empty?
      had_valid = !verify_token(f['token']).nil?
      last = (Time.parse(f['last_check'].to_s) rescue nil)
      due = last.nil? || (Time.now - last) > 86_400 || !had_valid
      return unless due
      UI.start_timer(15, false) do
        refresh do |_r|
          if !had_valid && allowed?
            notify('Tài khoản SOUL.Atelier đã được duyệt. Các công cụ đã sẵn sàng.')
          end
        end
      end
    end

    def self.apply(r, email)
      return unless r.is_a?(Hash) && r['ok']
      f = load
      f = {} unless f['email'].to_s.casecmp(email.to_s).zero?
      f['email'] = email
      f['device_key'] = r['device_key'] unless r['device_key'].to_s.empty?
      f['state'] = r['state']
      f['last_check'] = Time.now.iso8601
      if r['state'] == 'active' && verify_token(r['token'])
        f['token'] = r['token']
      elsif %w[locked removed pending].include?(r['state'])
        f['token'] = nil
      end
      f['device_key'] = nil if r['state'] == 'removed'
      save(f)
    end

    def self.call(action, extra, &blk)
      unless enabled?
        blk.call('ok' => false, 'error' => 'Bản cài này chưa gắn máy chủ bản quyền.')
        return
      end
      body = {
        'action' => action, 'machine_id' => machine_id, 'machine_name' => machine_name,
        'app' => "SketchUp #{Sketchup.version.to_i}"
      }.merge(extra).to_json
      http(SoulAtelier::LICENSE_URL, body, 0, &blk)
    end

    # POST tới Apps Script; Apps Script trả 302 → GET địa chỉ mới để lấy kết quả
    def self.http(url, body, hops, &blk)
      req = Sketchup::Http::Request.new(url, body ? Sketchup::Http::POST : Sketchup::Http::GET)
      if body
        req.body = body
        req.headers = { 'Content-Type' => 'text/plain; charset=utf-8' }
      end
      @requests << req
      req.start do |request, response|
        @requests.delete(request)
        code = response ? response.status_code.to_i : 0
        location = header(response, 'location')
        if [301, 302, 303, 307, 308].include?(code) && location && hops < 5
          http(location, nil, hops + 1, &blk)
        elsif code == 200
          reply =
            begin
              JSON.parse(response.body.to_s.dup.force_encoding('UTF-8').sub(/\A﻿/, ''))
            rescue StandardError
              { 'ok' => false, 'error' => 'Máy chủ bản quyền trả về dữ liệu không hợp lệ.' }
            end
          blk.call(reply)
        else
          blk.call('ok' => false, 'error' => 'Không kết nối được máy chủ bản quyền. Kiểm tra mạng Internet.')
        end
      end
    rescue StandardError
      blk.call('ok' => false, 'error' => 'Không kết nối được máy chủ bản quyền. Kiểm tra mạng Internet.')
    end

    def self.header(response, name)
      return nil unless response && response.respond_to?(:headers) && response.headers
      response.headers.each { |k, v| return v if k.to_s.casecmp(name).zero? }
      nil
    end

    # ---------------------------------------------------------------- Chữ ký số

    def self.public_key
      @public_key ||= OpenSSL::PKey.read(SoulAtelier::LICENSE_KEY.unpack('m')[0])
    end

    def self.verify_token(token)
      return nil if token.nil? || token.to_s.empty? || !enabled?
      part, sig = token.to_s.split('.')
      return nil if part.nil? || sig.nil?
      return nil unless public_key.verify(OpenSSL::Digest::SHA256.new, b64url(sig), part)
      p = JSON.parse(b64url(part).force_encoding('UTF-8'))
      return nil unless p['machine'].to_s.casecmp(machine_id).zero?
      return nil if p['exp'].to_i < Time.now.to_i
      p
    rescue StandardError
      nil
    end

    def self.b64url(s)
      s = s.to_s.tr('-_', '+/')
      s += '=' * ((4 - s.length % 4) % 4)
      s.unpack('m')[0]
    end

    # ---------------------------------------------------------------- File

    def self.load
      return {} unless File.exist?(file_path)
      data = JSON.parse(File.read(file_path, :mode => 'rb').force_encoding('UTF-8').sub(/\A﻿/, ''))
      data.is_a?(Hash) ? data : {}
    rescue StandardError
      {}
    end

    def self.save(hash)
      FileUtils.mkdir_p(SoulAtelier::DATA_DIR)
      File.open(file_path, 'wb') { |f| f.write(JSON.generate(hash)) }
    rescue StandardError
      nil
    end

    def self.notify(text)
      ext = Sketchup.extensions['SOUL.Atelier'] rescue nil
      if defined?(UI::Notification) && ext
        UI::Notification.new(ext, text).show
      else
        UI.messagebox(text)
      end
    rescue StandardError
      nil
    end
  end
end
