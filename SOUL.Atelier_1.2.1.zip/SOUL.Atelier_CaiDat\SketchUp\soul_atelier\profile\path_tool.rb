# encoding: UTF-8
# SOUL Profile – công cụ vẽ đường dẫn: click từng điểm, Enter / double-click để dựng, Backspace xóa điểm cuối,
# click lại điểm đầu để khép kín, Esc để hủy.
module SoulAtelier
  module Profile
    class PathTool
      def initialize(&on_finish)
        @on_finish = on_finish
        @pts = []
        @ip = nil
      end

      def activate
        @ip = Sketchup::InputPoint.new
        @pts = []
        status
      end

      def deactivate(view)
        view.invalidate
      end

      def resume(view)
        status
        view.invalidate
      end

      def status
        Sketchup.status_text = @pts.empty? ?
          'SOUL Profile: click điểm đầu của đường dẫn.' :
          'Click điểm tiếp theo • click lại điểm đầu = khép kín • Enter / double-click = dựng • Backspace = xóa điểm cuối • Esc = hủy'
        Sketchup.vcb_label = 'Dài'
      end

      def onMouseMove(_flags, x, y, view)
        @ip.pick(view, x, y, @pts.empty? ? nil : ip_from(@pts.last))
        view.tooltip = @ip.tooltip
        view.invalidate
      end

      def ip_from(pt)
        Sketchup::InputPoint.new(pt)
      end

      def onLButtonDown(_flags, x, y, view)
        @ip.pick(view, x, y)
        return unless @ip.valid?
        p = @ip.position
        if @pts.size >= 3 && p.distance(@pts.first) < 1e-3
          finish(view, true)
          return
        end
        @pts << p unless @pts.last && @pts.last.distance(p) < 1e-3
        status
        view.invalidate
      end

      def onLButtonDoubleClick(_flags, _x, _y, view)
        finish(view, false)
      end

      # Nhập chiều dài đoạn tiếp theo (mm hoặc đơn vị đang dùng) theo hướng con trỏ
      def onUserText(text, view)
        return if @pts.empty? || !@ip.valid?
        len = text.to_l rescue nil
        return unless len && len > 0
        v = @ip.position - @pts.last
        return if v.length.zero?
        v.length = len
        @pts << @pts.last.offset(v)
        status
        view.invalidate
      end

      def onKeyDown(key, _repeat, _flags, view)
        if key == 8 # Backspace
          @pts.pop
          status
          view.invalidate
        end
      end

      def onReturn(view)
        finish(view, false)
      end

      def onCancel(_reason, view)
        @pts = []
        Sketchup.active_model.select_tool(nil)
        view.invalidate
      end

      def finish(view, closed)
        pts = @pts.dup
        @pts = []
        view.invalidate
        Sketchup.active_model.select_tool(nil)
        return if pts.size < 2
        @on_finish.call([{ :pts => pts.map { |p| p.to_a.map(&:to_f) }, :closed => closed && pts.size >= 3 }])
      end

      def draw(view)
        @ip.draw(view) if @ip && @ip.display?
        return if @pts.empty?
        view.line_width = 2
        view.drawing_color = Sketchup::Color.new(232, 165, 75)
        list = @pts.dup
        list << @ip.position if @ip && @ip.valid?
        view.draw(GL_LINE_STRIP, list) if list.size >= 2
        view.draw_points(@pts, 6, 2, Sketchup::Color.new(28, 47, 65))
      end

      def getExtents
        bb = Geom::BoundingBox.new
        @pts.each { |p| bb.add(p) }
        bb.add(@ip.position) if @ip && @ip.valid?
        bb
      end
    end
  end
end
