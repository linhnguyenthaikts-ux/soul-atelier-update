# encoding: UTF-8
# Cửa sổ "Phiên bản" và "Giới thiệu" cho SketchUp, cùng tông màu logo SOUL.Atelier.
module SoulAtelier
  module Dialogs
    NAVY  = '#1C2F41'.freeze
    CREAM = '#F9F0E5'.freeze
    AMBER = '#E8A54B'.freeze

    def self.h(text)
      text.to_s.gsub('&', '&amp;').gsub('<', '&lt;').gsub('>', '&gt;').gsub('"', '&quot;')
    end

    def self.css
      <<-CSS
        * { box-sizing: border-box; }
        body { margin: 0; font-family: "Segoe UI", Arial, sans-serif; background: #{CREAM}; color: #212932; font-size: 13px; }
        .head { background: #{NAVY}; color: #{CREAM}; padding: 18px 26px 14px; border-bottom: 4px solid #{AMBER}; }
        .head h1 { margin: 0; font-size: 20px; letter-spacing: 1px; }
        .head .sub { color: #{AMBER}; margin-top: 4px; }
        .body { padding: 18px 26px; }
        .row { display: flex; padding: 5px 0; }
        .row .k { width: 120px; color: #70767C; }
        .row .v { font-weight: 600; }
        .ok { color: #2E7D50; } .warn { color: #B9782A; } .err { color: #C0392B; } .muted { color: #70767C; }
        .label { margin-top: 16px; font-size: 11px; font-weight: 700; color: #70767C; letter-spacing: .5px; }
        .log { background: #fff; border: 1px solid #ddd2c4; height: 210px; overflow-y: auto; padding: 10px 12px; margin-top: 6px; }
        .log .ver { font-weight: 700; margin-top: 8px; } .log .ver:first-child { margin-top: 0; }
        .tag { color: #{AMBER}; font-weight: 700; margin-left: 6px; }
        .btns { text-align: right; padding: 4px 26px 18px; }
        button { font-family: inherit; font-size: 13px; padding: 8px 18px; border: 1px solid #{NAVY}; cursor: pointer; margin-left: 8px; }
        .primary { background: #{NAVY}; color: #{CREAM}; font-weight: 700; } .primary:hover { background: #33557A; }
        .secondary { background: #{CREAM}; color: #{NAVY}; }
        button:disabled { opacity: .5; cursor: default; }
      CSS
    end

    # ---------------------------------------------------------------- Phiên bản

    def self.show_version
      @version_dlg.close if @version_dlg && @version_dlg.visible?
      @version_dlg = UI::HtmlDialog.new(
        :dialog_title => 'SOUL.Atelier – Phiên bản', :preferences_key => 'SOULatelier_version',
        :width => 560, :height => 560, :resizable => false, :scrollable => false,
        :style => UI::HtmlDialog::STYLE_DIALOG)
      @version_dlg.add_action_callback('check') do |_ctx|
        @version_dlg.set_html(version_html(true))
        Updater.check { @version_dlg.set_html(version_html(false)) if @version_dlg }
      end
      @version_dlg.add_action_callback('close') { |_ctx| @version_dlg.close }
      @version_dlg.set_html(version_html(false))
      @version_dlg.center
      @version_dlg.show
      if Updater.manifest.nil? && Updater.state != :not_configured && Updater.state != :checking
        Updater.check { @version_dlg.set_html(version_html(false)) if @version_dlg }
      end
    end

    def self.status_html(checking)
      return '<span class="muted">Đang kiểm tra...</span>' if checking || Updater.state == :checking
      case Updater.state
      when :up_to_date     then '<span class="ok">✓ Bạn đang dùng bản mới nhất.</span>'
      when :ready          then "<span class=\"warn\">★ Đã tải bản #{h(Updater.latest)}. Tắt SketchUp và mở lại để cập nhật.</span>"
      when :not_configured then '<span class="muted">Bản cài này chưa gắn máy chủ cập nhật.</span>'
      when :error          then "<span class=\"err\">#{h(Updater.error)}</span>"
      else '<span class="muted">Chưa kiểm tra.</span>'
      end
    end

    def self.changelog_html
      m = Updater.manifest
      return '<span class="muted">Chưa có thông tin cập nhật.</span>' unless m
      list = m['history'].is_a?(Array) && !m['history'].empty? ? m['history'] : [{ 'version' => m['latest'], 'date' => m['date'], 'notes' => m['notes'] }]
      list.map do |e|
        v = e['version'].to_s
        cmp = SoulAtelier.compare_versions(v, SoulAtelier::VERSION)
        tag = cmp > 0 ? '<span class="tag">★ BẢN MỚI</span>' : (cmp == 0 ? '<span class="tag">● đang dùng</span>' : '')
        notes = e['notes'].to_s.split(/\r?\n/).reject { |l| l.strip.empty? }.map { |l| "<div>#{h(l)}</div>" }.join
        "<div class=\"ver\">Phiên bản #{h(v)}#{e['date'] ? ' · ' + h(e['date']) : ''}#{tag}</div>#{notes}"
      end.join
    end

    def self.version_html(checking)
      m = Updater.manifest
      latest = m ? "#{h(m['latest'])}#{m['date'] ? ' (' + h(m['date']) + ')' : ''}" : '—'
      disabled = (checking || Updater.state == :not_configured) ? 'disabled' : ''
      <<-HTML
        <!DOCTYPE html><html><head><meta charset="utf-8"><style>#{css}</style></head><body>
        <div class="head"><h1>PHIÊN BẢN</h1><div class="sub">SOUL.Atelier · SketchUp #{h(Sketchup.version.to_i)}</div></div>
        <div class="body">
          <div class="row"><div class="k">Bản đang dùng</div><div class="v">#{h(SoulAtelier::VERSION)}</div></div>
          <div class="row"><div class="k">Bản mới nhất</div><div class="v">#{latest}</div></div>
          <div class="row"><div class="k">Trạng thái</div><div class="v">#{status_html(checking)}</div></div>
          <div class="label">NỘI DUNG CẬP NHẬT</div>
          <div class="log">#{changelog_html}</div>
        </div>
        <div class="btns">
          <button class="primary" #{disabled} onclick="sketchup.check()">Kiểm tra cập nhật</button>
          <button class="secondary" onclick="sketchup.close()">Đóng</button>
        </div>
        </body></html>
      HTML
    end

    # ---------------------------------------------------------------- Tài khoản

    def self.show_account(note = nil)
      @acc = { :email => (License.load['email'] || ''), :code => '', :msg => note, :err => false, :busy => false, :force_form => false }
      @account_dlg.close if @account_dlg && @account_dlg.visible?
      @account_dlg = UI::HtmlDialog.new(
        :dialog_title => 'SOUL.Atelier – Tài khoản', :preferences_key => 'SOULatelier_account',
        :width => 540, :height => 470, :resizable => false, :scrollable => false,
        :style => UI::HtmlDialog::STYLE_DIALOG)
      dlg = @account_dlg
      handle = lambda do |reply|
        @acc[:busy] = false
        if reply['ok']
          @acc[:err] = false
          @acc[:msg] = reply['state'].to_s.empty? ? reply['message'] : nil
          @acc[:force_form] = false
        else
          @acc[:err] = true
          @acc[:msg] = reply['error']
        end
        dlg.set_html(account_html) if dlg.visible?
      end
      dlg.add_action_callback('send_code') do |_ctx, email|
        @acc[:email] = email.to_s.strip
        if @acc[:email] !~ /@/
          handle.call('ok' => false, 'error' => 'Hãy nhập địa chỉ Gmail.')
        else
          busy(dlg)
          License.request_code(@acc[:email]) { |r| handle.call(r) }
        end
      end
      dlg.add_action_callback('verify') do |_ctx, email, code|
        @acc[:email] = email.to_s.strip
        @acc[:code] = code.to_s.strip
        if @acc[:code] !~ /\A\d{6}\z/
          handle.call('ok' => false, 'error' => 'Mã xác nhận gồm 6 số.')
        else
          busy(dlg)
          License.verify(@acc[:email], @acc[:code]) { |r| handle.call(r) }
        end
      end
      dlg.add_action_callback('refresh') { |_ctx| busy(dlg); License.refresh { |r| handle.call(r) } }
      dlg.add_action_callback('other') { |_ctx| @acc[:force_form] = true; @acc[:msg] = nil; dlg.set_html(account_html) }
      dlg.add_action_callback('deactivate') do |_ctx|
        if UI.messagebox('Gỡ kích hoạt SOUL.Atelier trên máy này (cả Revit và SketchUp)?', MB_YESNO) == IDYES
          busy(dlg)
          License.deactivate { |r| handle.call(r) }
        end
      end
      dlg.add_action_callback('close') { |_ctx| dlg.close }
      dlg.set_html(account_html)
      dlg.center
      dlg.show
    end

    def self.busy(dlg)
      @acc[:busy] = true
      @acc[:msg] = 'Đang xử lý...'
      @acc[:err] = false
      dlg.set_html(account_html)
    end

    def self.account_html
      text, good = License.state_text
      status_cls = good ? 'ok' : ''
      if @acc[:msg]
        text = @acc[:msg]
        status_cls = @acc[:err] ? 'err' : 'ok'
      end
      f = License.load
      active = !License.payload.nil?
      pending = !active && f['state'] == 'pending' && !@acc[:force_form]
      dis = @acc[:busy] ? 'disabled' : ''
      body =
        if !License.enabled?
          ''
        elsif active
          <<-H
            <p class="muted">Muốn chuyển sang máy khác: bấm "Gỡ kích hoạt máy này" để trả lại 1 lượt máy cho Gmail của bạn.</p>
            <button class="secondary" #{dis} onclick="sketchup.deactivate()">Gỡ kích hoạt máy này</button>
          H
        elsif pending
          <<-H
            <p class="muted">Quản trị sẽ nhận được thông báo. Khi được duyệt, bạn sẽ nhận email và phần mềm tự kích hoạt ở lần mở sau, hoặc bấm "Kiểm tra lại".</p>
            <button class="primary" #{dis} onclick="sketchup.refresh()">Kiểm tra lại</button>
            <button class="secondary" #{dis} onclick="sketchup.other()">Dùng Gmail khác</button>
          H
        else
          refresh_btn = f['device_key'].to_s.empty? ? '' : "<button class=\"secondary\" #{dis} onclick=\"sketchup.refresh()\">Kiểm tra lại</button>"
          <<-H
            <div class="label">GMAIL</div>
            <div class="line"><input id="email" type="email" value="#{h(@acc[:email])}" placeholder="ten@gmail.com">
            <button class="primary" #{dis} onclick="sketchup.send_code(document.getElementById('email').value)">Gửi mã</button></div>
            <div class="label">MÃ XÁC NHẬN (6 SỐ, GỬI VÀO GMAIL)</div>
            <div class="line"><input id="code" class="code" maxlength="6" value="#{h(@acc[:code])}">
            <button class="primary" #{dis} onclick="sketchup.verify(document.getElementById('email').value, document.getElementById('code').value)">Xác nhận</button>
            #{refresh_btn}</div>
            <p class="muted">Mỗi Gmail dùng tối đa 2 máy. Sau khi xác nhận Gmail, tài khoản cần được quản trị SOUL.Atelier duyệt. Một lần kích hoạt dùng chung cho Revit và SketchUp trên máy này.</p>
          H
        end
      <<-HTML
        <!DOCTYPE html><html><head><meta charset="utf-8"><style>#{css}
          .status { font-weight: 700; font-size: 14px; min-height: 40px; margin-bottom: 8px; }
          .line { display: flex; gap: 8px; margin: 6px 0 4px; }
          input { flex: 1; font: inherit; font-size: 14px; padding: 7px 9px; border: 1px solid #c9bfb2; }
          input.code { flex: 0 0 120px; font-weight: 700; letter-spacing: 3px; }
          .line button { margin-left: 0; }
        </style></head><body>
        <div class="head"><h1>TÀI KHOẢN</h1><div class="sub">Máy: #{h(License.machine_name)} · Mã máy: #{h(License.machine_short)}</div></div>
        <div class="body">
          <div class="status #{status_cls}">#{h(text)}</div>
          #{body}
        </div>
        <div class="btns"><button class="secondary" onclick="sketchup.close()">Đóng</button></div>
        </body></html>
      HTML
    end

    # ---------------------------------------------------------------- Giới thiệu

    def self.show_about
      @about_dlg.close if @about_dlg && @about_dlg.visible?
      @about_dlg = UI::HtmlDialog.new(
        :dialog_title => 'Giới thiệu SOUL.Atelier', :preferences_key => 'SOULatelier_about',
        :width => 560, :height => 600, :resizable => false, :scrollable => false,
        :style => UI::HtmlDialog::STYLE_DIALOG)
      @about_dlg.add_action_callback('close') { |_ctx| @about_dlg.close }
      @about_dlg.set_html(about_html)
      @about_dlg.center
      @about_dlg.show
    end

    def self.about_html
      logo_path = File.join(SoulAtelier::ICONS_DIR, 'logo.png')
      logo = File.exist?(logo_path) ? "<img src=\"data:image/png;base64,#{[File.binread(logo_path)].pack('m0')}\" style=\"width:100%\">" : '<h1>SOUL.Atelier</h1>'
      tools = SoulAtelier.tools.map { |t| "<div>· #{h(t[:name])}</div>" }.join
      <<-HTML
        <!DOCTYPE html><html><head><meta charset="utf-8"><style>#{css}
          .logo { background: #{NAVY}; padding: 22px 40px 16px; border-bottom: 4px solid #{AMBER}; }
          .t { font-size: 24px; font-weight: 700; color: #{NAVY}; margin: 0; }
          .by { font-size: 19px; font-weight: 700; margin: 2px 0 12px; }
        </style></head><body>
        <div class="logo">#{logo}</div>
        <div class="body">
          <p class="t">SOUL.Atelier</p>
          <div class="muted">Bộ công cụ SketchUp cho Kiến trúc và Nội thất</div>
          <div class="muted" style="margin-top:14px">Được tạo ra bởi</div>
          <div class="by">#{h(SoulAtelier::AUTHOR)}</div>
          <div>SOUL.Atelier là Design Atelier định hướng Kiến trúc, Nội thất và Thiết kế – Thi công, lấy tư duy thiết kế làm nền tảng, đề cao sự tinh tế, tính chân thực và giá trị lâu dài.</div>
          <div class="label">CÔNG CỤ</div>
          #{tools}
          <div class="muted" style="margin-top:14px;font-size:12px">Phiên bản #{h(SoulAtelier::VERSION)} · © #{Time.now.year} #{h(SoulAtelier::AUTHOR)} – SOUL.Atelier. Bảo lưu mọi quyền.</div>
        </div>
        <div class="btns"><button class="primary" onclick="sketchup.close()">Đóng</button></div>
        </body></html>
      HTML
    end
  end
end
