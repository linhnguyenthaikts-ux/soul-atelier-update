# encoding: UTF-8
# Tự cập nhật cho extension SketchUp – dùng chung máy chủ (version.json) với add-in Revit.
# Mở SketchUp → kiểm tra ngầm → có bản mới thì tải, kiểm tra SHA-256, thay file → mở lại SketchUp là dùng bản mới.
require 'json'
require 'fileutils'
require 'digest'

module SoulAtelier
  module Updater
    @state    = :unknown unless defined?(@state)   # :unknown :checking :up_to_date :ready :not_configured :error
    @manifest = nil unless defined?(@manifest)
    @error    = nil unless defined?(@error)
    @requests = [] unless defined?(@requests)      # giữ tham chiếu để request không bị thu hồi giữa chừng
    @busy     = false unless defined?(@busy)

    class << self
      attr_reader :state, :manifest, :error
    end

    def self.latest
      @manifest ? @manifest['latest'].to_s : nil
    end

    def self.update_ready?
      @state == :ready
    end

    # Kiểm tra (và tải nếu có bản mới). Gọi block khi xong.
    def self.check(&done)
      if SoulAtelier::UPDATE_URL.to_s.empty?
        @state = :not_configured
        done.call if done
        return
      end
      if @busy
        done.call if done
        return
      end
      @busy = true
      @state = :checking

      fetch("#{SoulAtelier::UPDATE_URL}version.json?t=#{Time.now.to_i}") do |ok, body|
        begin
          raise 'Không kết nối được máy chủ cập nhật. Kiểm tra mạng Internet.' unless ok
          text = body.dup.force_encoding('UTF-8').sub(/\A﻿/, '')
          @manifest = JSON.parse(text)
          latest = @manifest['latest'].to_s
          raise 'File version.json trên máy chủ không hợp lệ.' if latest.empty?

          if SoulAtelier.compare_versions(latest, SoulAtelier::VERSION) <= 0
            @state = :up_to_date
            finish(done)
          elsif Prefs['applied'].to_s == latest
            @state = :ready
            finish(done)
          else
            download_and_install(latest, done)
          end
        rescue StandardError => e
          fail_with(e.message, done)
        end
      end
    end

    def self.download_and_install(latest, done)
      pkg = @manifest['package'].to_s
      url = pkg =~ /\Ahttps?:/i ? pkg : SoulAtelier::UPDATE_URL + pkg
      fetch(url) do |ok, body|
        begin
          raise 'Không tải được gói cập nhật.' unless ok
          data = body.dup.force_encoding('BINARY')
          sha = @manifest['sha256'].to_s.strip.downcase
          if !sha.empty? && Digest::SHA256.hexdigest(data) != sha
            raise 'File tải về bị lỗi (sai mã kiểm tra). Sẽ thử lại lần sau.'
          end
          install_package(data)
          Prefs['applied'] = latest
          @state = :ready
          finish(done)
        rescue StandardError => e
          fail_with(e.message, done)
        end
      end
    end

    # Lấy thư mục "SketchUp/" trong gói, ghi ra thư mục tạm rồi thay thư mục soul_atelier.
    def self.install_package(data, plugins_dir = SoulAtelier::PLUGINS_DIR)
      files = []
      MiniZip.read(data).each do |name, content|
        parts = name.split('/').reject(&:empty?)
        idx = parts.index('SketchUp')
        next if idx.nil? || idx >= parts.size - 1
        files << [parts[(idx + 1)..-1].join('/'), content]
      end
      unless files.any? { |rel, _| rel == 'soul_atelier.rb' } && files.any? { |rel, _| rel.start_with?('soul_atelier/') }
        raise 'Gói cập nhật không có extension SketchUp.'
      end

      staging = File.join(SoulAtelier::DATA_DIR, 'updates', 'su_staging')
      FileUtils.rm_rf(staging)
      files.each do |rel, content|
        dst = File.join(staging, rel)
        FileUtils.mkdir_p(File.dirname(dst))
        File.open(dst, 'wb') { |f| f.write(content) }
      end

      target = File.join(plugins_dir, 'soul_atelier')
      old = "#{target}_old_#{Time.now.strftime('%Y%m%d%H%M%S')}"
      renamed = false
      begin
        File.rename(target, old) if File.exist?(target)
        renamed = true
        FileUtils.cp_r(File.join(staging, 'soul_atelier'), target)
      rescue StandardError
        # Không đổi tên được thư mục (đang bị giữ) → chép đè từng file
        if renamed && File.exist?(old)
          FileUtils.rm_rf(target)
          File.rename(old, target)
        end
        FileUtils.mkdir_p(target)
        FileUtils.cp_r(File.join(staging, 'soul_atelier', '.'), target)
      end
      FileUtils.cp(File.join(staging, 'soul_atelier.rb'), File.join(plugins_dir, 'soul_atelier.rb'))
      FileUtils.rm_rf(staging)
      true
    end

    # Xóa thư mục bản cũ còn sót từ lần cập nhật trước
    def self.cleanup_old(plugins_dir = SoulAtelier::PLUGINS_DIR)
      Dir.glob(File.join(plugins_dir, 'soul_atelier_old_*')).each do |d|
        FileUtils.rm_rf(d) rescue nil
      end
    end

    # Kiểm tra ngầm sau khi mở SketchUp, báo 1 lần cho mỗi bản mới
    def self.check_on_startup
      cleanup_old
      return if SoulAtelier::UPDATE_URL.to_s.empty?
      UI.start_timer(10, false) do
        check do
          if update_ready? && Prefs['notified'].to_s != latest.to_s
            Prefs['notified'] = latest.to_s
            notify_ready
          end
        end
      end
    end

    def self.notify_ready
      text = "SOUL.Atelier #{latest} đã được tải về. Tắt SketchUp và mở lại để dùng bản mới."
      ext = Sketchup.extensions['SOUL.Atelier'] rescue nil
      if defined?(UI::Notification) && ext
        n = UI::Notification.new(ext, text)
        n.on_accept('Xem chi tiết') { SoulAtelier::Dialogs.show_version }
        n.on_dismiss('Đóng') {}
        n.show
      else
        UI.messagebox(text)
      end
    rescue StandardError
      nil
    end

    # ---------------------------------------------------------------- mạng

    def self.fetch(url, &blk)
      req = Sketchup::Http::Request.new(url, Sketchup::Http::GET)
      req.headers = { 'User-Agent' => 'SOUL.Atelier-SketchUp', 'Cache-Control' => 'no-cache' }
      @requests << req
      req.start do |request, response|
        @requests.delete(request)
        if response && response.status_code.to_i == 200
          blk.call(true, response.body.to_s)
        else
          blk.call(false, nil)
        end
      end
    rescue StandardError
      blk.call(false, nil)
    end

    def self.finish(done)
      @busy = false
      done.call if done
    end

    def self.fail_with(message, done)
      @error = message
      @state = :error
      finish(done)
    end
  end
end
