@echo off
setlocal
title SOUL.Atelier - Go cai dat
echo Hay DONG tat ca Revit truoc khi go.
pause
for /d %%D in ("%APPDATA%\Autodesk\Revit\Addins\20*") do (
  if exist "%%D\SOUL.Atelier.addin" (
    del /q "%%D\SOUL.Atelier.addin"
    rmdir /s /q "%%D\SOUL.Atelier" 2>nul
    echo   Da go khoi Revit %%~nxD
  )
)
for /d %%S in ("%APPDATA%\SketchUp\SketchUp 20*") do (
  if exist "%%S\SketchUp\Plugins\soul_atelier.rb" (
    del /q "%%S\SketchUp\Plugins\soul_atelier.rb"
    rmdir /s /q "%%S\SketchUp\Plugins\soul_atelier" 2>nul
    echo   Da go extension khoi %%~nxS
  )
)
rmdir /s /q "%APPDATA%\SOULatelier" 2>nul
echo XONG.
pause
