# encoding: UTF-8
# SOUL Profile – dựng member (group) trong SketchUp từ đường dẫn + profile; sửa member; thống kê vật tư.
require 'json'

module SoulAtelier
  module Profile
    module Builder
      DICT = 'soul_profile'.freeze
      MM = 25.4

      # ---------------------------------------------------------------- tạo mới

      # chains: [{ :pts => [[x,y,z] (inch)], :closed => bool }]
      def self.build(model, ents, chains, state)
        loops_mm = Library.loops_for(state)
        loops = prepared_loops(loops_mm, state)
        return [] if loops.empty?
        name = Library.name_for(state)
        threshold = (state['corner'] || 30).to_f
        groups = []
        chains.each do |ch|
          Geo.runs(ch, threshold).each do |run|
            g = build_member(ents, run, loops, name, loops_mm, state)
            groups << g if g
          end
        end
        groups
      end

      def self.prepared_loops(loops_mm, state)
        inch = loops_mm.map { |l| l.map { |x, y| [x.to_f / MM, y.to_f / MM] } }
        Geo.prepare(inch,
                    :anchor => (state['anchor'] || 7).to_i,
                    :offset => [state['offx'].to_f / MM, state['offy'].to_f / MM],
                    :rotation_deg => state['rotation'].to_f,
                    :mirror => state['mirror'] ? true : false)
      end

      def self.build_member(ents, run, loops, name, loops_mm, state)
        secs, length, dirs = Geo.sections(run, loops)
        return nil if secs.size < 2 && !run[:closed]
        grp = ents.add_group
        g = grp.entities
        pts = secs.map { |sec| sec.map { |l| l.map { |p| Geom::Point3d.new(p[0], p[1], p[2]) } } }
        closed = run[:closed]
        m = pts.size

        # Mặt bên: [S_k[j], S_k+1[j], S_k+1[j+1], S_k[j+1]] → pháp tuyến hướng ra ngoài
        loops.each_index do |li|
          n = loops[li].size
          (closed ? m : m - 1).times do |k|
            k2 = (k + 1) % m
            n.times do |j|
              j2 = (j + 1) % n
              add_quad(g, pts[k][li][j], pts[k2][li][j], pts[k2][li][j2], pts[k][li][j2])
            end
          end
        end

        # Nắp 2 đầu (có lỗ)
        unless closed
          cap(g, pts[0], Geom::Vector3d.new(*Geo.mul(dirs.first, -1)), false)
          cap(g, pts[m - 1], Geom::Vector3d.new(*dirs.last), true)
        end

        soften(g, pts, loops, closed)

        length_mm = length * MM
        grp.name = "#{name} – L=#{length_mm.round}"
        grp.set_attribute(DICT, 'profile_name', name)
        grp.set_attribute(DICT, 'length_mm', length_mm.round(1))
        grp.set_attribute(DICT, 'loops_mm', JSON.generate(loops_mm))
        grp.set_attribute(DICT, 'settings', JSON.generate(state))
        grp.set_attribute(DICT, 'run', JSON.generate(
          'pts' => run[:pts], 'closed' => run[:closed], 'prev' => run[:prev], 'next' => run[:next], 'frames' => run[:frames]
        ))
        grp
      rescue StandardError => e
        grp.erase! if grp && grp.valid?
        puts "SOUL Profile: lỗi dựng member – #{e.message}"
        nil
      end

      def self.add_quad(g, a, b, c, d)
        g.add_face(a, b, c, d)
      rescue StandardError
        begin
          g.add_face(a, b, c)
        rescue StandardError
          nil
        end
        begin
          g.add_face(a, c, d)
        rescue StandardError
          nil
        end
      end

      def self.cap(g, section, expected, reverse)
        outer = reverse ? section[0].reverse : section[0]
        face = g.add_face(outer)
        face.reverse! if face && face.normal.dot(expected) < 0
        section[1..-1].each do |hole|
          f = g.add_face(hole)
          f.erase! if f && f.valid?
        end
      rescue StandardError
        nil
      end

      # Làm mượt: cạnh mặt cắt bên trong đoạn quét (đường cong) và cạnh dọc tại đỉnh mượt của profile (ống tròn...)
      def self.soften(g, pts, loops, closed)
        m = pts.size
        index = {}
        pts.each_with_index do |sec, k|
          sec.each_with_index { |l, li| l.each_with_index { |p, j| index[key(p)] = [k, li, j] } }
        end
        smooth = loops.map { |l| Geo.smooth_flags(l, 30) }
        g.grep(Sketchup::Edge).each do |e|
          a = index[key(e.start.position)]
          b = index[key(e.end.position)]
          next unless a && b
          soft =
            if a[0] == b[0]
              closed || (a[0] > 0 && a[0] < m - 1)          # cạnh mặt cắt bên trong
            elsif a[1] == b[1] && a[2] == b[2]
              smooth[a[1]][a[2]]                             # cạnh dọc tại đỉnh mượt
            else
              false
            end
          next unless soft
          e.soft = true
          e.smooth = true
        end
      end

      def self.key(p)
        [p.x, p.y, p.z].map { |v| (v.to_f * 1000).round }
      end

      # ---------------------------------------------------------------- đường dẫn từ vùng chọn

      def self.chains_from_selection(selection)
        edges = selection.grep(Sketchup::Edge)
        if edges.empty?
          edges = selection.grep(Sketchup::Face).flat_map { |f| f.outer_loop.edges }.uniq
        end
        segs = edges.map { |e| [e.start.position.to_a.map(&:to_f), e.end.position.to_a.map(&:to_f)] }
        Geo.chains(segs)
      end

      # ---------------------------------------------------------------- sửa member

      def self.member?(e)
        (e.is_a?(Sketchup::Group) || e.is_a?(Sketchup::ComponentInstance)) && !e.get_attribute(DICT, 'run').nil?
      end

      # Dựng lại member theo đường dẫn đã lưu với profile/căn chỉnh mới
      def self.rebuild(model, member, state)
        run_data = JSON.parse(member.get_attribute(DICT, 'run'))
        run = {
          :pts => run_data['pts'], :closed => run_data['closed'],
          :prev => run_data['prev'], :next => run_data['next'], :frames => run_data['frames']
        }
        ents = member.parent.entities
        tr = member.transformation
        layer = member.layer
        material = member.material
        loops_mm = Library.loops_for(state)
        loops = prepared_loops(loops_mm, state)
        return nil if loops.empty?
        g = build_member(ents, run, loops, Library.name_for(state), loops_mm, state)
        return nil unless g
        g.transformation = tr
        g.layer = layer
        g.material = material
        member.erase!
        g
      end

      def self.settings_of(member)
        s = JSON.parse(member.get_attribute(DICT, 'settings').to_s)
        s.is_a?(Hash) ? s : nil
      rescue StandardError
        nil
      end

      # Mọi member (kể cả trong group/component) đang dùng profile id
      def self.members_using(model, id)
        collect_members(model.entities).select { |m| (s = settings_of(m)) && s['profile'] == id }
      end

      # Dựng lại từng member theo thông số riêng của nó (+ ghi đè một số khóa nếu có)
      def self.update_members(model, members, override = {})
        members.map do |m|
          s = settings_of(m)
          next nil unless s
          rebuild(model, m, s.merge(override))
        end.compact
      end

      # ---------------------------------------------------------------- thống kê vật tư

      def self.collect_members(entities, out = [], visited = {})
        entities.each do |e|
          if member?(e)
            out << e
          elsif e.is_a?(Sketchup::Group) || e.is_a?(Sketchup::ComponentInstance)
            d = e.respond_to?(:definition) ? e.definition : nil
            next if d.nil? || visited[d.entityID]
            visited[d.entityID] = true
            collect_members(d.entities, out, visited)
          end
        end
        out
      end

      # [[profile, số lượng, tổng dài mm, [các chiều dài]]]
      def self.stats(model)
        rows = Hash.new { |h, k| h[k] = [] }
        collect_members(model.entities).each do |m|
          rows[m.get_attribute(DICT, 'profile_name').to_s] << m.get_attribute(DICT, 'length_mm').to_f
        end
        rows.map { |name, lens| [name, lens.size, lens.sum.round(1), lens.sort.reverse] }.sort_by(&:first)
      end
    end
  end
end
