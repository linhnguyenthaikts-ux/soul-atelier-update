# encoding: UTF-8
# SOUL Profile – "Hút profile": click vào thân 1 thanh có sẵn (group/component bất kỳ) → cắt ngang bằng toán học
# (không đụng vào mô hình) → lấy đường viền mặt cắt làm mẫu.
module SoulAtelier
  module Profile
    module Sampler
      MM = 25.4
      PAR = Math.cos(1.0 * Math::PI / 180)   # coi là song song nếu lệch < 1°

      # faces: [{ :loops => [[[x,y,z],...], ...], :normal => [x,y,z] }] (tọa độ thế giới, inch)
      # edges: [[a, b], ...] để đoán trục thanh
      # Trả về [loops_mm (2D), thông tin] hoặc raise với thông báo dễ hiểu
      def self.sample(faces, edges, click_pt, click_normal, click_face_edges)
        axis = guess_axis(edges, click_normal, click_face_edges)
        raise 'Không xác định được hướng thanh.' unless axis
        origin = click_pt
        # click vào mặt đầu thanh → cắt ở giữa thanh
        if Geo.dot(Geo.norm(click_normal), axis).abs > PAR
          ts = edges.flatten(1).map { |p| Geo.dot(p, axis) }
          mid = (ts.min + ts.max) / 2.0
          origin = Geo.add(click_pt, Geo.mul(axis, mid - Geo.dot(click_pt, axis)))
        end
        segs = cut(faces, origin, axis)
        raise 'Mặt cắt không có nét nào – hãy click vào thân thanh.' if segs.empty?
        chains = Geo.chains(segs)
        open = chains.reject { |c| c[:closed] }
        raise "Mặt cắt không khép kín (#{open.size} chỗ hở). Cấu kiện có thể bị hở mặt hoặc thiếu mặt." unless open.empty?
        loops3 = chains.map { |c| simplify(c[:pts]) }.select { |l| l.size >= 3 }
        raise 'Mặt cắt quá nhỏ hoặc bị lỗi.' if loops3.empty?
        loops = to_2d(loops3, origin, axis)
        check_single_piece(loops)
        [loops, { :axis => axis, :origin => origin }]
      end

      # Trục thanh: hướng có tổng chiều dài cạnh song song lớn nhất, chọn giữa
      # (a) cạnh dài nhất của mặt được click và (b) pháp tuyến mặt đó (khi click vào mặt đầu)
      def self.guess_axis(edges, click_normal, click_face_edges)
        cands = []
        longest = click_face_edges.max_by { |a, b| Geo.len(Geo.sub(b, a)) }
        cands << Geo.norm(Geo.sub(longest[1], longest[0])) if longest
        cands << Geo.norm(click_normal)
        cands = cands.select { |c| Geo.len(c) > 0.5 }
        best = cands.max_by do |c|
          edges.sum do |a, b|
            v = Geo.sub(b, a)
            l = Geo.len(v)
            l > 0 && (Geo.dot(v, c) / l).abs > PAR ? l : 0
          end
        end
        return nil unless best
        # hướng xác định: thành phần lớn nhất dương
        i = (0..2).max_by { |k| best[k].abs }
        best[i] < 0 ? Geo.mul(best, -1) : best
      end

      # Giao từng mặt với mặt phẳng (origin, n) → các đoạn thẳng
      def self.cut(faces, origin, n)
        segs = []
        faces.each do |f|
          fn = Geo.norm(f[:normal])
          next if Geo.len(fn) < 0.5 || Geo.dot(fn, n).abs > 0.999999 # mặt song song mặt cắt
          dir = Geo.norm(Geo.cross(fn, n))                          # hướng giao tuyến
          hits = []
          f[:loops].each do |lp|
            lp.each_with_index do |a, i|
              b = lp[(i + 1) % lp.size]
              # tính theo thứ tự chuẩn để 2 mặt chung cạnh cho cùng 1 điểm
              p, q = (a <=> b) <= 0 ? [a, b] : [b, a]
              dp = Geo.dot(Geo.sub(p, origin), n)
              dq = Geo.dot(Geo.sub(q, origin), n)
              next if (dp >= 0) == (dq >= 0)
              t = dp / (dp - dq)
              hits << Geo.add(p, Geo.mul(Geo.sub(q, p), t))
            end
          end
          hits.sort_by! { |h| Geo.dot(h, dir) }
          hits.each_slice(2) do |a, b|
            next unless b
            segs << [a, b] if Geo.len(Geo.sub(b, a)) > 1e-6
          end
        end
        segs
      end

      # Bỏ đỉnh thẳng hàng (giữ đỉnh của cung tròn)
      def self.simplify(pts)
        out = pts.dup
        changed = true
        while changed && out.size > 3
          changed = false
          out.each_index do |i|
            a = out[i - 1]
            b = out[i]
            c = out[(i + 1) % out.size]
            u = Geo.sub(b, a)
            v = Geo.sub(c, b)
            next unless Geo.len(Geo.cross(u, v)) < 1e-9 * [Geo.len(u) * Geo.len(v), 1e-12].max && Geo.dot(u, v) > 0
            out.delete_at(i)
            changed = true
            break
          end
        end
        out
      end

      # Hệ trục 2D giống lúc dựng member: Y = hướng lên (Z chiếu), X = trục × Y
      def self.to_2d(loops3, origin, axis)
        xa, up = Geo.frame(axis)
        loops = loops3.map do |l|
          l.map { |p| d = Geo.sub(p, origin); [Geo.dot(d, xa) * MM, Geo.dot(d, up) * MM] }
        end
        x0 = loops.flatten(1).map(&:first).min
        y0 = loops.flatten(1).map(&:last).min
        loops.map { |l| l.map { |x, y| [(x - x0).round(3), (y - y0).round(3)] } }
      end

      def self.inside?(pt, loop)
        x, y = pt
        c = false
        loop.each_with_index do |a, i|
          b = loop[i - 1]
          c = !c if (a[1] > y) != (b[1] > y) && x < (b[0] - a[0]) * (y - a[1]) / (b[1] - a[1]) + a[0]
        end
        c
      end

      def self.check_single_piece(loops)
        outer = loops.max_by { |l| Geo.area2(l).abs }
        others = loops.reject { |l| l.equal?(outer) }
        return if others.all? { |l| inside?(l[0], outer) }
        raise 'Mặt cắt gồm nhiều khối rời nhau. Hãy click vào 1 thanh đơn (hoặc mở group ra chọn riêng thanh đó).'
      end

      # ------------------------------------------------------------ SketchUp

      # Gom mặt & cạnh (tọa độ thế giới) trong entities, kể cả group/component lồng bên trong
      def self.collect(entities, tr, faces, edges, depth = 0)
        entities.each do |e|
          case e
          when Sketchup::Face
            loops = e.loops.map { |lp| lp.vertices.map { |v| v.position.transform(tr).to_a.map(&:to_f) } }
            n = loops[0].size >= 3 ? newell(loops[0]) : nil
            faces << { :loops => loops, :normal => n } if n
          when Sketchup::Edge
            edges << [e.start.position.transform(tr).to_a.map(&:to_f), e.end.position.transform(tr).to_a.map(&:to_f)]
          when Sketchup::Group, Sketchup::ComponentInstance
            next if depth > 8
            ents = e.respond_to?(:definition) ? e.definition.entities : e.entities
            collect(ents, tr * e.transformation, faces, edges, depth + 1)
          end
        end
      end

      def self.newell(pts)
        n = [0.0, 0.0, 0.0]
        pts.each_with_index do |a, i|
          b = pts[(i + 1) % pts.size]
          n[0] += (a[1] - b[1]) * (a[2] + b[2])
          n[1] += (a[2] - b[2]) * (a[0] + b[0])
          n[2] += (a[0] - b[0]) * (a[1] + b[1])
        end
        Geo.len(n) < 1e-12 ? nil : Geo.norm(n)
      end

      class Tool
        def initialize(&done)
          @done = done
        end

        def activate
          @ip = Sketchup::InputPoint.new
          Sketchup.status_text = 'Hút profile: click vào THÂN thanh (mặt dọc) của group/component cần lấy mặt cắt. Esc để hủy.'
        end

        def onMouseMove(_f, x, y, view)
          @ip.pick(view, x, y)
          view.tooltip = @ip.face ? 'Click để hút mặt cắt tại đây' : ''
          view.invalidate
        end

        def draw(view)
          @ip.draw(view) if @ip && @ip.display?
        end

        def onCancel(_r, _view)
          Sketchup.active_model.select_tool(nil)
        end

        def onLButtonDown(_f, x, y, view)
          @ip.pick(view, x, y)
          face = @ip.face
          return UI.beep unless face
          tr = @ip.transformation
          faces = []
          edges = []
          Sampler.collect(face.parent.entities, tr, faces, edges)
          click_edges = face.edges.map { |e| [e.start.position.transform(tr).to_a, e.end.position.transform(tr).to_a] }
          normal = Sampler.newell(face.outer_loop.vertices.map { |v| v.position.transform(tr).to_a })
          owner = face.parent.is_a?(Sketchup::ComponentDefinition) ? face.parent.name.to_s : ''
          owner = '' if owner =~ /\AGroup#/i
          Sketchup.active_model.select_tool(nil)
          begin
            loops, _info = Sampler.sample(faces, edges, @ip.position.to_a, normal, click_edges)
            @done.call(loops, owner)
          rescue StandardError => e
            UI.messagebox("Không hút được profile:\n#{e.message}")
          end
        end
      end
    end
  end
end
