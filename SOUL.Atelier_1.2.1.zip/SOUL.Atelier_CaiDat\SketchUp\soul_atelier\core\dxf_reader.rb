# encoding: UTF-8
# Bộ đọc DXF 2D tối giản (không cần SketchUp Pro, không cần thư viện ngoài).
# Đọc: LINE, LWPOLYLINE (có cung – bulge), POLYLINE/VERTEX, ARC, CIRCLE, ELLIPSE, SPLINE,
#      INSERT (block lồng nhau, xoay, co giãn, lật gương), DIMENSION (đường kích thước).
# Bỏ qua: chữ, hatch, ảnh... (được đếm lại để báo).
#
# Kết quả: { :blocks => { tên => { :base => [x,y], :items => [...] } }, :items => [...], :skipped => {loại => số} }
# Mỗi item:
#   [:poly,   layer, [[x,y],...], closed]      đường gấp khúc
#   [:arc,    layer, cx, cy, r, a0, a1]        cung tròn, góc radian, ngược chiều kim đồng hồ (a1 > a0)
#   [:insert, layer, block_name, affine]       affine = [a,b,c,d,e,f]: x' = a·x + c·y + e ; y' = b·x + d·y + f
module SoulAtelier
  module DxfReader
    TWO_PI = Math::PI * 2

    def self.read(path)
      data = File.binread(path)
      data = data.force_encoding('UTF-8')
      data = data.encode('UTF-8', 'binary', :invalid => :replace, :undef => :replace) unless data.valid_encoding?
      lines = data.split(/\r?\n/)
      pairs = []
      i = 0
      while i + 1 < lines.size
        pairs << [lines[i].strip.to_i, lines[i + 1].strip]
        i += 2
      end
      parse(pairs)
    end

    def self.parse(pairs)
      result = { :blocks => {}, :items => [], :skipped => Hash.new(0) }
      idx = 0
      while idx < pairs.size
        code, val = pairs[idx]
        if code == 0 && val == 'SECTION' && pairs[idx + 1]
          name = pairs[idx + 1][1]
          idx += 2
          case name
          when 'BLOCKS'   then idx = parse_blocks(pairs, idx, result)
          when 'ENTITIES' then idx = parse_entities(pairs, idx, result[:items], result, 'ENDSEC')
          else idx = skip_to(pairs, idx, 'ENDSEC')
          end
        else
          idx += 1
        end
      end
      result
    end

    def self.skip_to(pairs, idx, marker)
      idx += 1 until idx >= pairs.size || (pairs[idx][0] == 0 && pairs[idx][1] == marker)
      idx + 1
    end

    # Đọc 1 thực thể: trả về [loại, danh sách mã, chỉ số kế tiếp]
    def self.read_entity(pairs, idx)
      type = pairs[idx][1]
      codes = []
      idx += 1
      while idx < pairs.size && pairs[idx][0] != 0
        codes << pairs[idx]
        idx += 1
      end
      [type, codes, idx]
    end

    def self.parse_blocks(pairs, idx, result)
      while idx < pairs.size
        code, val = pairs[idx]
        return idx + 1 if code == 0 && val == 'ENDSEC'
        if code == 0 && val == 'BLOCK'
          _, header, idx = read_entity(pairs, idx)
          name = first(header, 2) || first(header, 3) || ''
          base = [num(header, 10), num(header, 20)]
          items = []
          idx = parse_entities(pairs, idx, items, result, 'ENDBLK')
          result[:blocks][name] = { :base => base, :items => items } unless name.start_with?('*Model_Space', '*Paper_Space')
        else
          idx += 1
        end
      end
      idx
    end

    def self.parse_entities(pairs, idx, items, result, end_marker)
      while idx < pairs.size
        code, val = pairs[idx]
        if code == 0 && val == end_marker
          _, _, nxt = read_entity(pairs, idx)
          return nxt
        end
        if code != 0
          idx += 1
          next
        end
        type, codes, idx = read_entity(pairs, idx)
        if type == 'POLYLINE'
          verts = []
          while idx < pairs.size && pairs[idx][0] == 0 && pairs[idx][1] == 'VERTEX'
            _, vcodes, idx = read_entity(pairs, idx)
            verts << [num(vcodes, 10), num(vcodes, 20), num(vcodes, 42)]
          end
          if idx < pairs.size && pairs[idx][1] == 'SEQEND'
            _, _, idx = read_entity(pairs, idx)
          end
          closed = (first(codes, 70).to_i & 1) == 1
          add_bulge_poly(items, layer(codes), verts, closed, extrusion_z(codes))
          next
        end
        convert(type, codes, items, result)
      end
      idx
    end

    # ------------------------------------------------------------------ chuyển thực thể

    def self.convert(type, c, items, result)
      ly = layer(c)
      ez = extrusion_z(c)
      case type
      when 'LINE'
        items << [:poly, ly, [[num(c, 10), num(c, 20)], [num(c, 11), num(c, 21)]], false]
      when 'LWPOLYLINE'
        verts = []
        c.each do |code, v|
          case code
          when 10 then verts << [v.to_f, 0.0, 0.0]
          when 20 then verts.last[1] = v.to_f if verts.last
          when 42 then verts.last[2] = v.to_f if verts.last
          end
        end
        closed = (first(c, 70).to_i & 1) == 1
        add_bulge_poly(items, ly, verts, closed, ez)
      when 'ARC'
        cx, cy, r = num(c, 10), num(c, 20), num(c, 40)
        a0 = num(c, 50) * Math::PI / 180
        a1 = num(c, 51) * Math::PI / 180
        add_arc(items, ly, cx, cy, r, a0, a1, ez)
      when 'CIRCLE'
        add_arc(items, ly, num(c, 10), num(c, 20), num(c, 40), 0.0, TWO_PI, ez)
      when 'ELLIPSE'
        items << [:poly, ly, ellipse_points(c), false]
      when 'SPLINE'
        pts = spline_points(c)
        items << [:poly, ly, pts, false] if pts.size >= 2
      when 'INSERT'
        name = first(c, 2).to_s
        sx = first(c, 41) ? num(c, 41) : 1.0
        sy = first(c, 42) ? num(c, 42) : 1.0
        rot = num(c, 50) * Math::PI / 180
        m = compose(translate(num(c, 10), num(c, 20)), compose(rotate(rot), scale(sx, sy)))
        m = compose(scale(-1, 1), m) if ez < 0
        items << [:insert, ly, name, m]
      when 'DIMENSION'
        name = first(c, 2).to_s
        items << [:insert, ly, name, identity] unless name.empty?
      else
        result[:skipped][type] += 1 unless %w[ATTRIB ATTDEF SEQEND VIEWPORT].include?(type)
      end
    end

    # Đường gấp khúc có cung (bulge): tách thành đoạn thẳng + cung
    def self.add_bulge_poly(items, ly, verts, closed, ez)
      return if verts.size < 2
      verts = verts.map { |x, y, b| [ez < 0 ? -x : x, y, ez < 0 ? -b : b] }
      n = verts.size
      seg_count = closed ? n : n - 1
      run = [[verts[0][0], verts[0][1]]]
      seg_count.times do |i|
        a = verts[i]
        b = verts[(i + 1) % n]
        if a[2].abs < 1e-9
          run << [b[0], b[1]]
        else
          items << [:poly, ly, run, false] if run.size >= 2
          arc = bulge_arc(a[0], a[1], b[0], b[1], a[2])
          items << [:arc, ly] + arc if arc
          run = [[b[0], b[1]]]
        end
      end
      if run.size >= 2
        whole = closed && verts.all? { |v| v[2].abs < 1e-9 }
        pts = whole ? run[0..-2] : run
        items << [:poly, ly, pts, whole]
      end
    end

    # Cung từ 2 điểm + bulge (tan(góc/4)); bulge âm = thuận chiều kim đồng hồ
    def self.bulge_arc(x1, y1, x2, y2, bulge)
      chord = Math.hypot(x2 - x1, y2 - y1)
      return nil if chord < 1e-9
      theta = 4 * Math.atan(bulge.abs)
      r = chord / (2 * Math.sin(theta / 2))
      mx = (x1 + x2) / 2.0
      my = (y1 + y2) / 2.0
      d = Math.sqrt([r * r - chord * chord / 4, 0].max)
      ux = (x2 - x1) / chord
      uy = (y2 - y1) / chord
      sign = (bulge > 0) == (theta < Math::PI) ? 1 : -1
      cx = mx - uy * d * sign
      cy = my + ux * d * sign
      a1 = Math.atan2(y1 - cy, x1 - cx)
      a2 = Math.atan2(y2 - cy, x2 - cx)
      if bulge > 0
        a2 += TWO_PI while a2 <= a1
        [cx, cy, r, a1, a2]
      else
        a1 += TWO_PI while a1 <= a2
        [cx, cy, r, a2, a1]
      end
    end

    def self.add_arc(items, ly, cx, cy, r, a0, a1, ez)
      return if r <= 0
      if ez < 0 # lật gương theo trục X (hệ tọa độ đối tượng hướng -Z)
        cx = -cx
        a0, a1 = Math::PI - a1, Math::PI - a0
      end
      a1 += TWO_PI while a1 <= a0
      items << [:arc, ly, cx, cy, r, a0, a1]
    end

    def self.ellipse_points(c)
      cx, cy = num(c, 10), num(c, 20)
      mx, my = num(c, 11), num(c, 21)
      ratio = first(c, 40) ? num(c, 40) : 1.0
      t0 = first(c, 41) ? num(c, 41) : 0.0
      t1 = first(c, 42) ? num(c, 42) : TWO_PI
      t1 += TWO_PI while t1 <= t0
      nx = -my * ratio
      ny = mx * ratio
      n = [[(48 * (t1 - t0) / TWO_PI).ceil, 8].max, 96].min
      sgn = extrusion_z(c) < 0 ? -1 : 1
      (0..n).map do |i|
        t = t0 + (t1 - t0) * i / n
        x = cx + mx * Math.cos(t) + nx * Math.sin(t)
        y = cy + my * Math.cos(t) + ny * Math.sin(t)
        [x * sgn, y]
      end
    end

    # B-spline (có trọng số) → điểm; nếu chỉ có điểm đi qua (fit points) thì nối các điểm đó
    def self.spline_points(c)
      deg = (first(c, 71) || 3).to_i
      knots = all(c, 40)
      weights = all(c, 41)
      cps = []
      fits = []
      c.each do |code, v|
        case code
        when 10 then cps << [v.to_f, 0.0]
        when 20 then cps.last[1] = v.to_f if cps.last
        when 11 then fits << [v.to_f, 0.0]
        when 21 then fits.last[1] = v.to_f if fits.last
        end
      end
      return fits if cps.size < deg + 1 || knots.size != cps.size + deg + 1
      weights = Array.new(cps.size, 1.0) if weights.size != cps.size
      t0 = knots[deg]
      t1 = knots[cps.size]
      n = [cps.size * 8, 200].min
      (0..n).map { |i| de_boor(deg, knots, cps, weights, t0 + (t1 - t0) * i / n) }
    end

    def self.de_boor(p, t, c, w, x)
      k = p
      k += 1 while k < c.size - 1 && x >= t[k + 1]
      d = (0..p).map { |j| cp = c[j + k - p]; ww = w[j + k - p]; [cp[0] * ww, cp[1] * ww, ww] }
      (1..p).each do |r|
        p.downto(r) do |j|
          den = t[j + 1 + k - r] - t[j + k - p]
          a = den.abs < 1e-12 ? 0.0 : (x - t[j + k - p]) / den
          d[j] = (0..2).map { |q| (1 - a) * d[j - 1][q] + a * d[j][q] }
        end
      end
      [d[p][0] / d[p][2], d[p][1] / d[p][2]]
    end

    # ------------------------------------------------------------------ biến đổi affine 2D

    def self.identity
      [1.0, 0.0, 0.0, 1.0, 0.0, 0.0]
    end

    def self.translate(x, y)
      [1.0, 0.0, 0.0, 1.0, x, y]
    end

    def self.rotate(a)
      [Math.cos(a), Math.sin(a), -Math.sin(a), Math.cos(a), 0.0, 0.0]
    end

    def self.scale(sx, sy)
      [sx, 0.0, 0.0, sy, 0.0, 0.0]
    end

    # compose(m, n): áp n trước rồi m
    def self.compose(m, n)
      [m[0] * n[0] + m[2] * n[1], m[1] * n[0] + m[3] * n[1],
       m[0] * n[2] + m[2] * n[3], m[1] * n[2] + m[3] * n[3],
       m[0] * n[4] + m[2] * n[5] + m[4], m[1] * n[4] + m[3] * n[5] + m[5]]
    end

    def self.apply(m, x, y)
      [m[0] * x + m[2] * y + m[4], m[1] * x + m[3] * y + m[5]]
    end

    # Phép biến đổi của 1 lần chèn block, tính cả điểm gốc của block
    def self.insert_matrix(dxf, name, m)
      blk = dxf[:blocks][name]
      return m unless blk
      compose(m, translate(-blk[:base][0], -blk[:base][1]))
    end

    # Trải phẳng toàn bộ thành đoạn thẳng [layer, x1, y1, x2, y2] (dùng để kiểm tra và đo khung bao)
    def self.flatten(dxf, items = dxf[:items], m = identity, inherited = nil, depth = 0, out = [])
      return out if depth > 16
      items.each do |it|
        ly = it[1] == '0' && inherited ? inherited : it[1]
        case it[0]
        when :poly
          pts = it[2].map { |x, y| apply(m, x, y) }
          pts += [pts[0]] if it[3]
          pts.each_cons(2) { |a, b| out << [ly, a[0], a[1], b[0], b[1]] }
        when :arc
          arc_points(*it[2..6]).map { |x, y| apply(m, x, y) }.each_cons(2) { |a, b| out << [ly, a[0], a[1], b[0], b[1]] }
        when :insert
          blk = dxf[:blocks][it[2]]
          flatten(dxf, blk[:items], compose(m, insert_matrix(dxf, it[2], it[3])), ly, depth + 1, out) if blk
        end
      end
      out
    end

    def self.arc_points(cx, cy, r, a0, a1)
      n = [[(24 * (a1 - a0) / TWO_PI).ceil, 2].max, 72].min
      (0..n).map { |i| t = a0 + (a1 - a0) * i / n; [cx + r * Math.cos(t), cy + r * Math.sin(t)] }
    end

    # ------------------------------------------------------------------ tiện ích đọc mã

    def self.first(codes, code)
      pair = codes.find { |c, _| c == code }
      pair && pair[1]
    end

    def self.all(codes, code)
      codes.select { |c, _| c == code }.map { |_, v| v.to_f }
    end

    def self.num(codes, code)
      first(codes, code).to_f
    end

    def self.layer(codes)
      first(codes, 8) || '0'
    end

    def self.extrusion_z(codes)
      z = first(codes, 230)
      z ? z.to_f : 1.0
    end
  end
end
