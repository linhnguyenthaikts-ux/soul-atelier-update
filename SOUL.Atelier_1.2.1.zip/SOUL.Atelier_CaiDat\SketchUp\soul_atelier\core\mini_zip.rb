# encoding: UTF-8
# Giải nén file .zip tối giản (chỉ dùng thư viện Zlib có sẵn trong SketchUp)
require 'zlib'

module SoulAtelier
  module MiniZip
    SIG_EOCD = "PK\x05\x06".b.freeze
    SIG_CD   = "PK\x01\x02".b.freeze

    # Trả về mảng [[tên_file, nội_dung], ...] (bỏ thư mục)
    def self.read(data)
      data = data.dup.force_encoding('BINARY')
      eocd = data.rindex(SIG_EOCD)
      raise 'File cập nhật không phải file zip hợp lệ.' unless eocd

      total  = data[eocd + 10, 2].unpack('v')[0]
      cd_off = data[eocd + 16, 4].unpack('V')[0]
      pos = cd_off
      out = []
      total.times do
        raise 'File zip bị lỗi.' unless data[pos, 4] == SIG_CD
        method = data[pos + 10, 2].unpack('v')[0]
        csize  = data[pos + 20, 4].unpack('V')[0]
        nlen, xlen, clen = data[pos + 28, 6].unpack('vvv')
        local  = data[pos + 42, 4].unpack('V')[0]
        name   = data[pos + 46, nlen].dup
        pos += 46 + nlen + xlen + clen

        lnlen, lxlen = data[local + 26, 4].unpack('vv')
        start = local + 30 + lnlen + lxlen
        raw = data[start, csize]

        content =
          case method
          when 0 then raw
          when 8
            zi = Zlib::Inflate.new(-Zlib::MAX_WBITS)
            s = zi.inflate(raw)
            zi.finish
            zi.close
            s
          end
        next if content.nil?

        name = name.force_encoding('UTF-8').tr('\\', '/')
        out << [name, content] unless name.end_with?('/')
      end
      out
    end
  end
end
