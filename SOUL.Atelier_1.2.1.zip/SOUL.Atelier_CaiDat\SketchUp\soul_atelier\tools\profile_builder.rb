# encoding: UTF-8
# Tool: SOUL Profile – tựa Profile Builder
#  - Thư viện mặt cắt: hộp, thép hộp, ống, L, U, I/H, phào... (nhập kích thước mm) + profile tự lưu từ mặt vẽ sẵn.
#  - Tạo member theo cạnh đang chọn hoặc vẽ đường dẫn; góc gãy tự cắt vát (miter), đường cong liền 1 thanh.
#  - Hút profile từ thanh có sẵn; sửa hình mẫu → cập nhật mọi member đang dùng.
#  - Căn điểm bám (lưới 3×3), xoay, lật, lệch; đổi profile / căn chỉnh cho member có sẵn; thống kê & xuất CSV.
%w[geometry library builder path_tool sampler dialog].each do |f|
  Sketchup.require(File.join(SoulAtelier::ROOT_DIR, 'profile', f))
end

SoulAtelier.register_tool('profile_builder', 'SOUL Profile',
  :tooltip => 'SOUL Profile – quét mặt cắt theo đường dẫn',
  :status  => 'Tạo thanh thép, gỗ, phào, ống... theo cạnh đang chọn hoặc đường vẽ; tự cắt vát góc, thống kê vật tư.',
  :icon    => 'profile') { SoulAtelier::Profile::Dialog.show }

SoulAtelier.register_tool('profile_stats', 'SOUL Profile – Xuất thống kê CSV',
  :toolbar => false) { SoulAtelier::Profile::Dialog.export_csv }
