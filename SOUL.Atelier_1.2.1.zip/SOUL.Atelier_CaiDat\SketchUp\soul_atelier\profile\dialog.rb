# encoding: UTF-8
# SOUL Profile – bảng điều khiển (HtmlDialog)
require 'json'

module SoulAtelier
  module Profile
    module Dialog
      DEFAULT_STATE = {
        'profile' => 'box', 'params' => { 'w' => 40, 'h' => 80, 't' => 1.4 },
        'anchor' => 7, 'rotation' => 0, 'mirror' => false, 'offx' => 0, 'offy' => 0, 'corner' => 30
      }.freeze

      def self.state
        s = JSON.parse(Prefs['profile_state'].to_s) rescue nil
        s.is_a?(Hash) ? DEFAULT_STATE.merge(s) : DEFAULT_STATE.dup
      end

      def self.state=(s)
        Prefs['profile_state'] = JSON.generate(s)
      end

      def self.show
        if @dlg && @dlg.visible?
          @dlg.bring_to_front
          return
        end
        @dlg = UI::HtmlDialog.new(
          :dialog_title => 'SOUL Profile', :preferences_key => 'SOULatelier_Profile',
          :width => 580, :height => 860, :min_width => 480, :min_height => 520,
          :style => UI::HtmlDialog::STYLE_DIALOG
        )
        @dlg.set_html(html)
        bind(@dlg)
        @dlg.show
      end

      def self.send_js(fn, data)
        @dlg.execute_script("SP.#{fn}(#{JSON.generate(data)})") if @dlg
      end

      def self.parse(arg)
        arg.is_a?(String) ? JSON.parse(arg) : arg
      end

      def self.catalog
        Library.catalog.map do |c|
          defaults = (c['params'] || []).map { |p| [p['key'], p['value']] }.to_h
          thumb = c['kind'] == 'user' ? c['loops'] : Geo.preset(c['id'], defaults)
          c.merge('thumb' => Geo.normalize_loops(thumb || []))
        end
      end

      def self.bind(dlg)
        dlg.add_action_callback('ready') do |_c, _a|
          send_js('init', 'catalog' => catalog, 'state' => state)
        end

        dlg.add_action_callback('preview') do |_c, arg|
          s = parse(arg)
          self.state = s
          loops = Library.loops_for(s)
          prepared = Geo.prepare(loops, :anchor => s['anchor'].to_i, :offset => [s['offx'].to_f, s['offy'].to_f],
                                        :rotation_deg => s['rotation'].to_f, :mirror => s['mirror'] ? true : false)
          send_js('preview', 'loops' => prepared, 'name' => Library.name_for(s))
        end

        dlg.add_action_callback('build_sel') { |_c, arg| build_from_selection(parse(arg)) }
        dlg.add_action_callback('draw') { |_c, arg| draw_path(parse(arg)) }
        dlg.add_action_callback('edit_sel') { |_c, arg| edit_selection(parse(arg)) }
        dlg.add_action_callback('pick_sel') { |_c, _a| pick_selection }
        dlg.add_action_callback('save_face') { |_c, _a| save_face }
        dlg.add_action_callback('sample') { |_c, _a| start_sample }
        dlg.add_action_callback('edit_shape') { |_c, arg| edit_shape(arg.to_s) }
        dlg.add_action_callback('align_sel') { |_c, arg| align_selection(parse(arg)) }
        dlg.add_action_callback('select_same') { |_c, arg| select_same(parse(arg)) }
        dlg.add_action_callback('delete') { |_c, arg| delete_profile(arg.to_s) }
        dlg.add_action_callback('stats') { |_c, _a| send_js('stats', Builder.stats(Sketchup.active_model)) }
        dlg.add_action_callback('csv') { |_c, _a| export_csv }
      end

      def self.notify(msg, ok = true)
        if @dlg && @dlg.visible?
          send_js('msg', 'text' => msg, 'ok' => ok)
        else
          UI.messagebox(msg)
        end
      end

      # ------------------------------------------------------------ hành động

      def self.build_from_selection(s)
        model = Sketchup.active_model
        chains = Builder.chains_from_selection(model.selection)
        return notify('Hãy chọn các cạnh (Line/Arc) hoặc mặt làm đường dẫn rồi bấm lại.', false) if chains.empty?
        build(model, chains, s)
      end

      def self.draw_path(s)
        model = Sketchup.active_model
        model.select_tool(PathTool.new { |chains| build(model, chains, s) })
        notify('Click các điểm của đường dẫn trong mô hình. Enter để dựng, Esc để hủy.')
      end

      def self.build(model, chains, s)
        self.state = s
        model.start_operation('SOUL Profile – Tạo member', true)
        groups = Builder.build(model, model.active_entities, chains, s)
        model.commit_operation
        model.selection.clear
        model.selection.add(groups) unless groups.empty?
        if groups.empty?
          notify('Không dựng được member nào. Kiểm tra lại profile và đường dẫn.', false)
        else
          total = groups.sum { |g| g.get_attribute(Builder::DICT, 'length_mm').to_f }
          notify("Đã tạo #{groups.size} member • tổng dài #{(total / 1000).round(2)} m")
        end
      rescue StandardError => e
        model.abort_operation
        notify("Lỗi: #{e.message}", false)
      end

      def self.edit_selection(s)
        model = Sketchup.active_model
        members = model.selection.select { |e| Builder.member?(e) }
        return notify('Hãy chọn member do SOUL Profile tạo ra (group có tên dạng "... – L=...").', false) if members.empty?
        self.state = s
        model.start_operation('SOUL Profile – Đổi profile', true)
        done = members.map { |m| Builder.rebuild(model, m, s) }.compact
        model.commit_operation
        model.selection.clear
        model.selection.add(done) unless done.empty?
        notify("Đã cập nhật #{done.size}/#{members.size} member.")
      rescue StandardError => e
        model.abort_operation
        notify("Lỗi: #{e.message}", false)
      end

      def self.pick_selection
        m = Sketchup.active_model.selection.find { |e| Builder.member?(e) }
        return notify('Hãy chọn 1 member do SOUL Profile tạo ra.', false) unless m
        s = JSON.parse(m.get_attribute(Builder::DICT, 'settings').to_s) rescue nil
        return notify('Member này không còn lưu thông số.', false) unless s.is_a?(Hash)
        send_js('init', 'catalog' => catalog, 'state' => DEFAULT_STATE.merge(s))
        notify('Đã lấy thông số từ member đang chọn.')
      end

      # ------------------------------------------------------------ thư viện: lưu / hút / sửa hình

      # Lưu mẫu; nếu trùng tên → hỏi ghi đè; mẫu đã có member dùng → hỏi cập nhật theo hình mới
      def self.store(name, loops, overwrite_ok = false)
        id = Library.id_for(name)
        if Library.exists?(id) && !overwrite_ok
          return nil unless UI.messagebox("Đã có profile \"#{name}\". Ghi đè bằng hình mới?", MB_YESNO) == IDYES
        end
        Library.save_user(name, loops)
        s = state.merge('profile' => id, 'params' => {})
        self.state = s
        send_js('init', 'catalog' => catalog, 'state' => s)
        model = Sketchup.active_model
        users = Builder.members_using(model, id)
        if !users.empty? &&
           UI.messagebox("Có #{users.size} member đang dùng \"#{name}\".\nCập nhật tất cả theo hình mới?\n" \
                         '(mỗi member giữ nguyên đường dẫn và căn chỉnh của nó)', MB_YESNO) == IDYES
          model.start_operation('SOUL Profile – Cập nhật member theo mẫu', true)
          done = Builder.update_members(model, users)
          model.commit_operation
          notify("Đã lưu \"#{name}\" và cập nhật #{done.size}/#{users.size} member.")
        else
          notify("Đã lưu profile \"#{name}\" vào thư viện.")
        end
        id
      rescue StandardError => e
        model.abort_operation if model
        notify("Không lưu được: #{e.message}", false)
        nil
      end

      def self.ask_name(default)
        r = UI.inputbox(['Tên profile:'], [default], 'SOUL Profile – Lưu mẫu')
        return nil unless r
        n = r[0].to_s.strip
        n.empty? ? nil : n
      end

      # Chọn 1 mặt; hoặc chọn group "sửa hình mẫu" / group chứa mặt cắt
      def self.save_face
        model = Sketchup.active_model
        sel = model.selection
        edit = sel.find { |e| e.is_a?(Sketchup::Group) && e.get_attribute(Builder::DICT, 'edit_id') }
        faces = sel.grep(Sketchup::Face)
        faces = (edit || sel.grep(Sketchup::Group).first).entities.grep(Sketchup::Face) if faces.empty? && (edit || sel.grep(Sketchup::Group).first)
        return notify('Hãy chọn 1 mặt (Face) vẽ hình mặt cắt, hoặc group "SOUL Profile – sửa…", rồi bấm lại.', false) if faces.empty?
        face = faces.max_by { |f| f.area }
        loops = Library.from_face(face)
        if edit
          id = edit.get_attribute(Builder::DICT, 'edit_id')
          name = edit.get_attribute(Builder::DICT, 'edit_name') || id.sub('user:', '')
          name = ask_name(name)
          return unless name
          ok = store(name, loops, Library.id_for(name) == id)
          if ok && edit.valid?
            model.start_operation('Xóa hình sửa mẫu', true, false, true)
            edit.erase!
            model.commit_operation
          end
        else
          name = ask_name('Profile ' + Time.now.strftime('%Y%m%d-%H%M'))
          store(name, loops) if name
        end
      end

      def self.start_sample
        model = Sketchup.active_model
        model.select_tool(Sampler::Tool.new do |loops, owner|
          w, h = Geo.bbox2(loops).values_at(2, 3)
          default = (owner.to_s.empty? ? 'Profile hút' : owner) + " #{Library.fmt(w)}x#{Library.fmt(h)}"
          name = ask_name(default)
          store(name, loops) if name
        end)
        notify('Click vào THÂN thanh (mặt dọc) cần lấy mặt cắt. Esc để hủy.')
      end

      # Dựng hình mẫu tự lưu ra mô hình (mặt đứng XZ tại gốc tọa độ) để sửa bằng công cụ SketchUp
      def self.edit_shape(id)
        return notify('Chọn 1 profile tự lưu (mục "Profile của anh") để sửa hình.', false) unless id.start_with?('user:')
        u = Library.user_profiles.find { |p| p['id'] == id }
        return notify('Không tìm thấy profile.', false) unless u
        model = Sketchup.active_model
        model.start_operation('SOUL Profile – Sửa hình mẫu', true)
        grp = model.active_entities.add_group
        grp.name = "SOUL Profile – sửa: #{u['name']}"
        grp.set_attribute(Builder::DICT, 'edit_id', id)
        grp.set_attribute(Builder::DICT, 'edit_name', u['name'])
        loops = Geo.normalize_loops(u['loops'])
        pts = ->(l) { l.map { |x, y| Geom::Point3d.new(x.to_f / Builder::MM, 0, y.to_f / Builder::MM) } }
        f = grp.entities.add_face(pts.(loops[0]))
        f.reverse! if f.normal.y > 0
        loops[1..-1].each do |h|
          hf = grp.entities.add_face(pts.(h))
          hf.erase! if hf && hf.valid?
        end
        model.commit_operation
        model.selection.clear
        model.selection.add(grp)
        model.active_view.zoom(grp)
        notify("Đã dựng hình mẫu tại gốc tọa độ (nhìn từ Front). Mở group sửa hình, xong chọn group và bấm \"Lưu profile từ mặt đang chọn\".")
      rescue StandardError => e
        model.abort_operation
        notify("Lỗi: #{e.message}", false)
      end

      # ------------------------------------------------------------ sửa member

      ALIGN_KEYS = %w[anchor rotation mirror offx offy].freeze

      # Chỉ đổi căn chỉnh, mỗi member giữ profile của nó
      def self.align_selection(s)
        model = Sketchup.active_model
        members = model.selection.select { |e| Builder.member?(e) }
        return notify('Hãy chọn member do SOUL Profile tạo ra.', false) if members.empty?
        model.start_operation('SOUL Profile – Đổi căn chỉnh', true)
        done = Builder.update_members(model, members, s.select { |k, _| ALIGN_KEYS.include?(k) })
        model.commit_operation
        model.selection.clear
        model.selection.add(done) unless done.empty?
        notify("Đã đổi căn chỉnh #{done.size}/#{members.size} member (giữ nguyên profile).")
      rescue StandardError => e
        model.abort_operation
        notify("Lỗi: #{e.message}", false)
      end

      # Chọn mọi member cùng profile (theo member đang chọn, hoặc profile đang chọn trong bảng)
      def self.select_same(s)
        model = Sketchup.active_model
        ref = model.selection.find { |e| Builder.member?(e) }
        name = ref ? ref.get_attribute(Builder::DICT, 'profile_name') : Library.name_for(s)
        list = model.active_entities.select { |e| Builder.member?(e) && e.get_attribute(Builder::DICT, 'profile_name') == name }
        model.selection.clear
        model.selection.add(list) unless list.empty?
        notify(list.empty? ? "Không có member \"#{name}\" ở cấp đang mở." : "Đã chọn #{list.size} member \"#{name}\".", !list.empty?)
      end

      def self.delete_profile(id)
        return notify('Chỉ xóa được profile do anh tự lưu.', false) unless id.start_with?('user:')
        return unless UI.messagebox('Xóa profile này khỏi thư viện?', MB_YESNO) == IDYES
        Library.delete_user(id)
        s = state.merge('profile' => 'box')
        self.state = s
        send_js('init', 'catalog' => catalog, 'state' => s)
      end

      def self.export_csv
        rows = Builder.stats(Sketchup.active_model)
        return notify('Mô hình chưa có member nào.', false) if rows.empty?
        path = UI.savepanel('Lưu bảng thống kê', '', 'Thong_ke_profile.csv')
        return unless path
        path += '.csv' unless path.downcase.end_with?('.csv')
        q = ->(v) { '"' + v.to_s.gsub('"', '""') + '"' }
        lines = [%w[Profile Số_lượng Tổng_dài_mm Tổng_dài_m Chiều_dài_từng_thanh_mm].map { |h| q.(h.tr('_', ' ')) }.join(',')]
        rows.each do |name, count, total, lens|
          lines << [q.(name), count, total, (total / 1000.0).round(3), q.(lens.map(&:round).join('; '))].join(',')
        end
        File.open(path, 'wb') { |f| f.write("﻿" + lines.join("\r\n")) }
        notify("Đã xuất: #{File.basename(path)}")
      rescue StandardError => e
        notify("Không xuất được: #{e.message}", false)
      end

      def self.html
        File.read(File.join(__dir__, 'dialog.html'), :mode => 'rb').force_encoding('UTF-8')
      end
    end
  end
end
