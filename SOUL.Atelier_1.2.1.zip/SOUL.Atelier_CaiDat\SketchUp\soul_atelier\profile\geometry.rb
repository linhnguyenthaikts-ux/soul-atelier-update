# encoding: UTF-8
# SOUL Profile – phần hình học thuần (không phụ thuộc SketchUp), tọa độ dạng mảng [x, y, z].
#  - Chuẩn hóa profile 2D (vòng ngoài ngược chiều kim đồng hồ, lỗ thuận chiều), điểm neo, xoay, lật.
#  - Nối các cạnh đang chọn thành chuỗi đường dẫn; chia chuỗi thành các "đoạn quét" tại góc gắt.
#  - Tính mặt cắt tại từng đỉnh: góc gắt cắt vát theo mặt phẳng phân giác (miter).
module SoulAtelier
  module Profile
    module Geo
      Z = [0.0, 0.0, 1.0].freeze
      EPS = 1e-9

      # ---------------------------------------------------------------- vector
      def self.add(a, b) [a[0] + b[0], a[1] + b[1], a[2] + b[2]] end
      def self.sub(a, b) [a[0] - b[0], a[1] - b[1], a[2] - b[2]] end
      def self.mul(a, s) [a[0] * s, a[1] * s, a[2] * s] end
      def self.dot(a, b) a[0] * b[0] + a[1] * b[1] + a[2] * b[2] end
      def self.cross(a, b) [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]] end
      def self.len(a) Math.sqrt(dot(a, a)) end

      def self.norm(a)
        l = len(a)
        l < EPS ? [0.0, 0.0, 0.0] : mul(a, 1.0 / l)
      end

      # ---------------------------------------------------------------- profile 2D

      def self.area2(loop)
        s = 0.0
        loop.each_with_index do |p, i|
          q = loop[(i + 1) % loop.size]
          s += p[0] * q[1] - q[0] * p[1]
        end
        s / 2.0
      end

      # Vòng có diện tích lớn nhất là vòng ngoài (ngược chiều kim đồng hồ), các vòng khác là lỗ (thuận chiều)
      def self.normalize_loops(loops)
        loops = loops.map { |l| dedupe2(l) }.select { |l| l.size >= 3 }
        return [] if loops.empty?
        outer = loops.max_by { |l| area2(l).abs }
        holes = loops.reject { |l| l.equal?(outer) }
        outer = outer.reverse if area2(outer) < 0
        holes = holes.map { |h| area2(h) > 0 ? h.reverse : h }
        [outer] + holes
      end

      def self.dedupe2(loop)
        out = []
        loop.each { |p| out << p if out.empty? || (out.last[0] - p[0]).abs > 1e-6 || (out.last[1] - p[1]).abs > 1e-6 }
        out.pop if out.size > 1 && (out.first[0] - out.last[0]).abs < 1e-6 && (out.first[1] - out.last[1]).abs < 1e-6
        out
      end

      def self.bbox2(loops)
        xs = loops.flatten(1).map { |p| p[0] }
        ys = loops.flatten(1).map { |p| p[1] }
        [xs.min, ys.min, xs.max, ys.max]
      end

      # Điểm neo 0..8 theo lưới 3×3: hàng trên → dưới, cột trái → phải (4 = tâm)
      def self.anchor_point(loops, anchor)
        x0, y0, x1, y1 = bbox2(loops)
        col = anchor % 3
        row = anchor / 3
        [x0 + (x1 - x0) * col / 2.0, y1 - (y1 - y0) * row / 2.0]
      end

      # Chuẩn bị profile để quét: dời về điểm neo, lệch, xoay, lật. Đơn vị giữ nguyên.
      def self.prepare(loops, anchor: 7, offset: [0, 0], rotation_deg: 0, mirror: false)
        loops = normalize_loops(loops)
        return [] if loops.empty?
        ax, ay = anchor_point(loops, anchor)
        a = rotation_deg.to_f * Math::PI / 180
        c = Math.cos(a)
        s = Math.sin(a)
        out = loops.map do |l|
          l.map do |x, y|
            x -= ax
            y -= ay
            x = -x if mirror
            x += offset[0]
            y += offset[1]
            [x * c - y * s, x * s + y * c]
          end
        end
        mirror ? normalize_loops(out) : out
      end

      # Đỉnh "mượt" của profile (góc giữa 2 cạnh kề < ngưỡng) → cạnh dọc tại đó sẽ được làm mượt
      def self.smooth_flags(loop, threshold_deg = 30)
        n = loop.size
        (0...n).map do |i|
          p0 = loop[(i - 1) % n]
          p1 = loop[i]
          p2 = loop[(i + 1) % n]
          v1 = [p1[0] - p0[0], p1[1] - p0[1]]
          v2 = [p2[0] - p1[0], p2[1] - p1[1]]
          l1 = Math.hypot(*v1)
          l2 = Math.hypot(*v2)
          next false if l1 < EPS || l2 < EPS
          cosang = (v1[0] * v2[0] + v1[1] * v2[1]) / (l1 * l2)
          Math.acos([[cosang, 1.0].min, -1.0].max) * 180 / Math::PI < threshold_deg
        end
      end

      # ---------------------------------------------------------------- đường dẫn

      def self.key(p)
        p.map { |v| (v * 1000).round }.join(',')
      end

      # edges: [[p1, p2], ...] → chuỗi { :pts => [...], :closed => bool }
      def self.chains(edges)
        adj = Hash.new { |h, k| h[k] = [] }
        pos = {}
        edges.each_with_index do |(a, b), i|
          ka = key(a)
          kb = key(b)
          next if ka == kb
          adj[ka] << [i, kb]
          adj[kb] << [i, ka]
          pos[ka] = a
          pos[kb] = b
        end
        used = {}
        result = []
        walk = lambda do |start|
          pts = [pos[start]]
          cur = start
          loop do
            nxt = adj[cur].find { |i, _| !used[i] }
            break unless nxt
            used[nxt[0]] = true
            cur = nxt[1]
            pts << pos[cur]
          end
          pts
        end
        # Bắt đầu từ đầu mút (bậc 1) hoặc điểm rẽ nhánh trước, vòng kín sau
        starts = adj.keys.sort_by { |k| adj[k].size == 2 ? 1 : 0 }
        starts.each do |k|
          while adj[k].any? { |i, _| !used[i] }
            pts = walk.call(k)
            next if pts.size < 2
            closed = pts.size > 3 && key(pts.first) == key(pts.last)
            pts.pop if closed
            result << { :pts => pts, :closed => closed }
          end
        end
        result
      end

      def self.turn_deg(d1, d2)
        Math.acos([[dot(d1, d2), 1.0].min, -1.0].max) * 180 / Math::PI
      end

      # Chia chuỗi thành các đoạn quét: tách tại góc gắt (≥ ngưỡng). Mỗi đoạn biết hướng trước/sau để cắt vát.
      def self.runs(chain, threshold_deg = 30)
        pts = chain[:pts]
        closed = chain[:closed]
        n = pts.size
        return [] if n < 2
        segs = closed ? n : n - 1
        dirs = (0...segs).map { |i| norm(sub(pts[(i + 1) % n], pts[i])) }
        all_frames = chain_frames(dirs)
        sharp = Array.new(n, false)
        (0...n).each do |i|
          next if !closed && (i.zero? || i == n - 1)
          din = dirs[(i - 1) % segs]
          dout = dirs[i % segs]
          sharp[i] = turn_deg(din, dout) >= threshold_deg
        end

        if closed && sharp.none?
          return [{ :pts => pts.dup, :closed => true, :prev => nil, :next => nil, :frames => all_frames }]
        end

        breaks = (0...n).select { |i| sharp[i] }
        breaks = [0] + breaks + [n - 1] unless closed
        breaks.uniq!
        out = []
        if closed
          breaks.each_with_index do |b, j|
            e = breaks[(j + 1) % breaks.size]
            idx = []
            i = b
            loop do
              idx << i
              break if i == e && idx.size > 1
              i = (i + 1) % n
            end
            out << { :pts => idx.map { |k| pts[k] }, :closed => false,
                     :prev => dirs[(b - 1) % segs], :next => dirs[e % segs],
                     :frames => idx[0..-2].map { |k| all_frames[k % segs] } }
          end
        else
          breaks.each_cons(2) do |b, e|
            out << { :pts => pts[b..e], :closed => false,
                     :prev => b.zero? ? nil : dirs[b - 1], :next => e == n - 1 ? nil : dirs[e],
                     :frames => all_frames[b...e] }
          end
        end
        out
      end

      # ---------------------------------------------------------------- khung & mặt cắt

      # Khung của 1 đoạn hướng d: Y hướng lên (theo trục Z), X sang phải khi nhìn theo d.
      # Đoạn thẳng đứng: giữ X của đoạn trước (hoặc trục X) cho liên tục.
      def self.frame(d, prev_x = nil)
        if dot(d, Z).abs > 0.999
          x = prev_x || [1.0, 0.0, 0.0]
          x = norm(sub(x, mul(d, dot(d, x))))
          x = norm(cross(d, [0.0, 1.0, 0.0])) if len(x) < EPS
          y = cross(x, d)
        else
          y = norm(sub(Z, mul(d, dot(d, Z))))
          x = cross(d, y)
        end
        [x, y]
      end

      # Khung cho mọi đoạn của cả chuỗi. Đoạn thẳng đứng lấy trục X theo đoạn không-thẳng-đứng gần nhất
      # (= pháp tuyến mặt phẳng chứa đường dẫn) để cột – dầm nối khít như thanh được uốn.
      def self.chain_frames(dirs)
        vertical = dirs.map { |d| dot(d, Z).abs > 0.999 }
        frames = dirs.each_with_index.map { |d, i| vertical[i] ? nil : frame(d) }
        dirs.each_index do |i|
          next unless vertical[i]
          j = (i - 1).downto(0).find { |k| !vertical[k] } || (i + 1...dirs.size).find { |k| !vertical[k] }
          frames[i] = frame(dirs[i], j ? frames[j][0] : nil)
        end
        frames
      end

      # Giao đường thẳng (điểm a, hướng d) với mặt phẳng (điểm o, pháp tuyến n)
      def self.intersect(a, d, o, n)
        den = dot(d, n)
        return a if den.abs < EPS
        add(a, mul(d, dot(sub(o, a), n) / den))
      end

      # Mặt cắt tại mọi đỉnh của 1 đoạn quét.
      # Trả về [sections, length]: sections[k][loop][j] = điểm 3D. Đoạn kín: không lặp lại mặt cắt đầu.
      def self.sections(run, loops)
        pts = run[:pts]
        closed = run[:closed]
        n = pts.size
        segs = closed ? n : n - 1
        dirs = (0...segs).map { |i| norm(sub(pts[(i + 1) % n], pts[i])) }
        frames = run[:frames] && run[:frames].size == dirs.size ? run[:frames] : chain_frames(dirs)
        on_seg = lambda do |i, p, v|
          x, y = frames[i]
          add(v, add(mul(x, p[0]), mul(y, p[1])))
        end

        count = closed ? n : n
        secs = (0...count).map do |k|
          v = pts[k]
          if closed
            din = dirs[(k - 1) % segs]
            dout = dirs[k % segs]
            plane_n = norm(add(din, dout))
            plane_n = dout if len(plane_n) < EPS
            loops.map do |l|
              l.map do |p|
                a = intersect(on_seg.call((k - 1) % segs, p, v), din, v, plane_n)
                b = intersect(on_seg.call(k % segs, p, v), dout, v, plane_n)
                mul(add(a, b), 0.5)
              end
            end
          elsif k.zero?
            d = dirs[0]
            plane_n = run[:prev] ? norm(add(run[:prev], d)) : d
            plane_n = d if len(plane_n) < EPS
            loops.map { |l| l.map { |p| intersect(on_seg.call(0, p, v), d, v, plane_n) } }
          elsif k == n - 1
            d = dirs[segs - 1]
            plane_n = run[:next] ? norm(add(d, run[:next])) : d
            plane_n = d if len(plane_n) < EPS
            loops.map { |l| l.map { |p| intersect(on_seg.call(segs - 1, p, v), d, v, plane_n) } }
          else
            din = dirs[k - 1]
            dout = dirs[k]
            plane_n = norm(add(din, dout))
            plane_n = dout if len(plane_n) < EPS
            loops.map do |l|
              l.map do |p|
                a = intersect(on_seg.call(k - 1, p, v), din, v, plane_n)
                b = intersect(on_seg.call(k, p, v), dout, v, plane_n)
                mul(add(a, b), 0.5)
              end
            end
          end
        end
        length = (0...segs).sum { |i| len(sub(pts[(i + 1) % n], pts[i])) }
        [secs, length, dirs]
      end

      # ---------------------------------------------------------------- mẫu profile có tham số (mm)

      def self.circle(cx, cy, r, n = 24)
        (0...n).map { |i| t = 2 * Math::PI * i / n; [cx + r * Math.cos(t), cy + r * Math.sin(t)] }
      end

      def self.preset(type, p)
        w = p['w'].to_f
        h = p['h'].to_f
        t = p['t'].to_f
        d = p['d'].to_f
        tf = p['tf'].to_f
        case type
        when 'rect'
          [[[0, 0], [w, 0], [w, h], [0, h]]]
        when 'box'
          [[[0, 0], [w, 0], [w, h], [0, h]], [[t, t], [w - t, t], [w - t, h - t], [t, h - t]]]
        when 'round'
          [circle(d / 2, d / 2, d / 2)]
        when 'tube'
          [circle(d / 2, d / 2, d / 2), circle(d / 2, d / 2, d / 2 - t)]
        when 'angle'
          [[[0, 0], [w, 0], [w, t], [t, t], [t, h], [0, h]]]
        when 'channel'
          [[[0, 0], [w, 0], [w, h], [w - t, h], [w - t, t], [t, t], [t, h], [0, h]]]
        when 'ibeam'
          tw = t
          [[[0, 0], [w, 0], [w, tf], [(w + tw) / 2, tf], [(w + tw) / 2, h - tf], [w, h - tf], [w, h],
            [0, h], [0, h - tf], [(w - tw) / 2, h - tf], [(w - tw) / 2, tf], [0, tf]]]
        when 'molding'
          [[[0, 0], [w, 0], [w, h * 0.25], [w * 0.75, h * 0.25], [w * 0.75, h * 0.5],
            [w * 0.5, h * 0.5], [w * 0.5, h], [0, h]]]
        when 'quarter'
          r = d / 2
          arc = (0..12).map { |i| a = Math::PI / 2 * i / 12; [r * Math.cos(a), r * Math.sin(a)] }
          [[[0, 0]] + arc]
        else
          []
        end
      end
    end
  end
end
