# encoding: UTF-8
# Tool: Copy 2D sang Revit  +  Copy 5 mặt sang Revit
#
# Xuất bản vẽ 2D (PDF vector, đã khử nét khuất) vào %AppData%\SOULatelier\su_bridge, kèm clip.json gồm:
#  - thông tin camera của từng mặt (để quy đổi tỉ lệ),
#  - khung bao thật của đối tượng (để hiệu chỉnh tỉ lệ chính xác khi copy 5 mặt),
#  - (nếu giữ group) cây group + cạnh của từng group chiếu lên mặt phẳng nhìn,
#    để Revit gán từng nét vào đúng group và dựng Detail Group cùng tên.
require 'json'
require 'fileutils'

module SoulAtelier
  module Copy2D
    BRIDGE_DIR    = File.join(SoulAtelier::DATA_DIR, 'su_bridge').freeze
    DRAWING_SCALE = 50.0      # xuất PDF ở tỉ lệ 1:50 (Revit tự quy đổi về kích thước thật)
    MM            = 25.4      # 1 inch = 25.4 mm
    EDGE_LIMIT    = 200_000   # quá số cạnh này thì bỏ qua việc giữ group

    # key, tên, hướng nhìn (camera nhìn theo), hướng lên
    FACES = [
      ['top',   'Mặt trên',  [0, 0, -1], [0, 1, 0]],
      ['front', 'Mặt trước', [0, 1, 0],  [0, 0, 1]],
      ['back',  'Mặt sau',   [0, -1, 0], [0, 0, 1]],
      ['left',  'Mặt trái',  [1, 0, 0],  [0, 0, 1]],
      ['right', 'Mặt phải',  [-1, 0, 0], [0, 0, 1]]
    ].freeze

    # ------------------------------------------------------------------ Tool 1: góc nhìn hiện tại

    def self.run
      model = Sketchup.active_model
      return UI.messagebox('Chưa mở mô hình SketchUp.') unless model
      view = model.active_view
      cam = view.camera
      was_perspective = cam.perspective?
      if was_perspective
        answer = UI.messagebox(
          "Góc nhìn đang ở chế độ phối cảnh (Perspective).\n\n" \
          "Bản vẽ 2D cần chế độ Parallel Projection để đúng tỉ lệ.\n" \
          "Chuyển tạm sang Parallel Projection để xuất?", MB_YESNO)
        return unless answer == IDYES
        cam.perspective = false
      end

      keep = Prefs['keep_groups'].to_s != 'false'
      selection = model.selection.to_a
      prepare_dir

      tree = nil
      if keep
        roots = selection.empty? ? model.active_entities.to_a : selection
        tree = collect(roots, model.edit_transform, true)
        unless tree
          keep = false
          notify('Mô hình quá nhiều cạnh – bản này không giữ group.')
        end
      end

      result = nil
      model.start_operation('SOUL.Atelier – Copy 2D', true)
      begin
        hide_unselected(model, selection) unless selection.empty?
        result = export_face(model, view, 'view', 'Góc nhìn', 'clip.pdf', tree, keep, false)
      rescue StandardError => e
        UI.messagebox("Không xuất được bản vẽ 2D:\n#{e.message}")
      ensure
        model.abort_operation
        cam.perspective = true if was_perspective
      end
      return unless result

      info = base_info(model, keep, tree, 'view')
      info['view'] = result['view']        # tương thích bản Revit cũ
      info['views'] = [result]
      info['selection_only'] = !selection.empty?
      write_json(info)
      done_message('Đã copy góc nhìn 2D.')
    end

    # ------------------------------------------------------------------ Tool 2: 5 mặt của đối tượng chọn

    def self.run_faces
      model = Sketchup.active_model
      return UI.messagebox('Chưa mở mô hình SketchUp.') unless model
      selection = model.selection.to_a
      if selection.empty?
        return UI.messagebox('Hãy chọn đối tượng (ví dụ group tủ) trước khi copy 5 mặt.')
      end

      opts = ask_face_options
      return unless opts
      faces = FACES.select { |f| opts[f[0]] }
      return UI.messagebox('Chưa chọn mặt nào.') if faces.empty?
      keep = opts['keep']

      view = model.active_view
      saved = camera_copy(view.camera)
      ro = model.rendering_options
      saved_sections = ro['DisplaySectionCuts']
      prepare_dir

      tree = collect(selection, model.edit_transform, keep)
      if tree.nil?
        keep = false
        tree = collect(selection, model.edit_transform, false)
        notify('Đối tượng quá nhiều cạnh – bản này không giữ group.')
      end

      results = []
      model.start_operation('SOUL.Atelier – Copy 5 mặt', true)
      begin
        hide_unselected(model, selection)
        ro['DisplaySectionCuts'] = false
        bb = Geom::BoundingBox.new
        selection.each { |e| bb.add(e.bounds) if e.respond_to?(:bounds) }
        center = bb.center
        dist = [bb.diagonal.to_f, 100.0].max * 3
        faces.each do |key, label, dir, up|
          d = Geom::Vector3d.new(*dir)
          eye = center.offset(d.reverse, dist)
          view.camera = Sketchup::Camera.new(eye, center, Geom::Vector3d.new(*up), false)
          view.zoom(selection)
          view.refresh if view.respond_to?(:refresh)
          r = export_face(model, view, key, label, "clip_#{key}.pdf", tree, keep, true)
          results << r if r
        end
      rescue StandardError => e
        UI.messagebox("Không xuất được bản vẽ 2D:\n#{e.message}")
      ensure
        model.abort_operation
        ro['DisplaySectionCuts'] = saved_sections
        view.camera = saved
      end
      return if results.empty?

      info = base_info(model, keep, tree, 'faces')
      info['views'] = results
      info['selection_only'] = true
      write_json(info)
      done_message("Đã copy #{results.size} mặt.")
    end

    # Hộp chọn mặt + giữ group (nhớ lựa chọn lần trước)
    def self.ask_face_options
      prompts = FACES.map { |f| f[1] } + ['Giữ group']
      defaults = FACES.map { |f| Prefs["face_#{f[0]}"].to_s == 'false' ? 'Không' : 'Có' } +
                 [Prefs['keep_groups'].to_s == 'false' ? 'Không' : 'Có']
      lists = Array.new(prompts.size, 'Có|Không')
      res = UI.inputbox(prompts, defaults, lists, 'Copy 5 mặt sang Revit')
      return nil unless res
      opts = {}
      FACES.each_with_index do |f, i|
        opts[f[0]] = res[i] == 'Có'
        Prefs["face_#{f[0]}"] = opts[f[0]].to_s
      end
      opts['keep'] = res.last == 'Có'
      Prefs['keep_groups'] = opts['keep'].to_s
      opts
    end

    # Tùy chọn cho tool "Copy 2D sang Revit"
    def self.options
      cur = Prefs['keep_groups'].to_s == 'false' ? 'Không' : 'Có'
      res = UI.inputbox(['Giữ group'], [cur], ['Có|Không'], 'Tùy chọn Copy 2D')
      Prefs['keep_groups'] = (res[0] == 'Có').to_s if res
    end

    # ------------------------------------------------------------------ Xuất 1 mặt

    def self.export_face(model, view, key, label, file, tree, keep, fit)
      info = view_info(view)
      path = File.join(BRIDGE_DIR, file)
      ok = model.export(path, pdf_options)
      unless ok && File.exist?(path)
        UI.messagebox("SketchUp không xuất được bản vẽ 2D (#{label}).\n" \
                      'Lưu ý: tính năng này cần SketchUp Pro (có xuất PDF 2D).')
        return nil
      end
      face = { 'key' => key, 'label' => label, 'pdf' => file, 'fit' => fit, 'view' => info }
      if tree
        sets, bbox, frames = project(tree, info, keep, !fit)
        face['bbox'] = bbox
        if keep
          face['edges'] = sets
          face['frames'] = frames
        end
      end
      face
    end

    def self.pdf_options
      {
        :full_scale              => true,
        :drawing_units           => Length::Millimeter,
        :model_units             => Length::Millimeter,
        :length_in_drawing       => 1.0,
        :length_in_model         => DRAWING_SCALE,
        :output_profile_lines    => true,
        :output_section_lines    => true,
        :match_screen_profiles   => true,
        :match_screen_section    => true,
        :edge_extensions         => false,
        :match_screen_extensions => false,
        :map_fonts               => true
      }
    end

    # ------------------------------------------------------------------ Cây group & cạnh

    # Trả về { :nodes => [...], :edges => [[gid, p1, p2], ...] } (tọa độ thế giới), hoặc nil nếu quá nhiều cạnh
    def self.collect(roots, transform, keep)
      nodes = []
      edges = []
      trs = {}
      next_id = [0]
      walk = lambda do |ents, tr, gid|
        ents.each do |e|
          next if e.respond_to?(:hidden?) && e.hidden?
          next if e.respond_to?(:layer) && e.layer && !e.layer.visible?
          if e.is_a?(Sketchup::Edge)
            edges << [gid, e.start.position.transform(tr), e.end.position.transform(tr)]
            raise StopIteration if edges.size > EDGE_LIMIT
          elsif e.is_a?(Sketchup::Group) || e.is_a?(Sketchup::ComponentInstance)
            child = gid
            if keep
              next_id[0] += 1
              child = next_id[0]
              nodes << { 'id' => child, 'parent' => gid, 'name' => entity_name(e), 'def' => definition_key(e) }
              trs[child] = tr * e.transformation
            end
            sub = e.is_a?(Sketchup::Group) ? e.entities : e.definition.entities
            walk.call(sub, tr * e.transformation, child)
          end
        end
      end
      walk.call(roots, transform, 0)
      { :nodes => nodes, :edges => edges, :trs => trs }
    rescue StopIteration
      nil
    end

    # Các bản sao cùng Component (hoặc Group chưa Make Unique) có chung định nghĩa → cùng Group Type bên Revit
    def self.definition_key(e)
      e.definition.guid.to_s
    rescue StandardError
      "e#{e.entityID}"
    end

    def self.entity_name(e)
      n = e.name.to_s.strip
      n = e.definition.name.to_s.strip if n.empty? && e.respond_to?(:definition)
      n = e.is_a?(Sketchup::Group) ? 'Group' : 'Component' if n.empty?
      n
    end

    # Chiếu cạnh lên mặt phẳng nhìn, tọa độ mm tính từ góc dưới-trái khung nhìn.
    # clip = true: chỉ giữ cạnh nằm (một phần) trong khung nhìn (copy theo viewport).
    def self.project(tree, info, keep, clip)
      ll = info['lower_left_mm']
      xa = info['xaxis']
      ya = info['yaxis']
      w = info['width_mm']
      h = info['height_mm']
      to_uv = lambda do |p|
        d = [p.x.to_f * MM - ll[0], p.y.to_f * MM - ll[1], p.z.to_f * MM - ll[2]]
        [d[0] * xa[0] + d[1] * xa[1] + d[2] * xa[2], d[0] * ya[0] + d[1] * ya[1] + d[2] * ya[2]]
      end
      sets = {}
      used = {}
      umin = vmin = Float::INFINITY
      umax = vmax = -Float::INFINITY
      tree[:edges].each do |gid, a, b|
        ua, va = to_uv.call(a)
        ub, vb = to_uv.call(b)
        next if clip && !segment_in_box?(ua, va, ub, vb, w, h)
        umin = [umin, ua, ub].min
        umax = [umax, ua, ub].max
        vmin = [vmin, va, vb].min
        vmax = [vmax, va, vb].max
        next unless keep
        next if (ua - ub).abs < 0.05 && (va - vb).abs < 0.05 # cạnh nhìn thẳng → thành 1 điểm
        (sets[gid] ||= []).push(ua.round(2), va.round(2), ub.round(2), vb.round(2))
        used[gid] = true
      end
      bbox = umin.finite? ? [umin, vmin, umax, vmax].map { |v| v.round(2) } : nil

      # Khung tọa độ của từng group trên mặt phẳng nhìn: gốc (mm) + 3 trục (đã chiếu, giữ tỉ lệ co giãn)
      frames = []
      if keep
        (tree[:trs] || {}).each do |id, t|
          m = t.to_a
          ou, ov = to_uv.call(Geom::Point3d.new(m[12], m[13], m[14]))
          axes = [[m[0], m[1], m[2]], [m[4], m[5], m[6]], [m[8], m[9], m[10]]].map do |ax|
            [ax[0] * xa[0] + ax[1] * xa[1] + ax[2] * xa[2], ax[0] * ya[0] + ax[1] * ya[1] + ax[2] * ya[2]]
          end
          frames << { 'id' => id, 'f' => ([ou, ov] + axes.flatten).map { |v| v.round(5) } }
        end
      end
      [sets.map { |gid, xy| { 'id' => gid, 'xy' => xy } }, bbox, frames]
    end

    # Đoạn thẳng có cắt khung [0,w]×[0,h] không (Liang–Barsky)
    def self.segment_in_box?(x1, y1, x2, y2, w, h)
      return true if w.nil? || h.nil?
      t0 = 0.0
      t1 = 1.0
      dx = x2 - x1
      dy = y2 - y1
      [[-dx, x1], [dx, w - x1], [-dy, y1], [dy, h - y1]].each do |p, q|
        if p.abs < 1e-12
          return false if q < 0
        else
          r = q / p
          if p < 0
            t0 = r if r > t0
          else
            t1 = r if r < t1
          end
          return false if t0 > t1
        end
      end
      true
    end

    # ------------------------------------------------------------------ Thông tin chung

    def self.base_info(model, keep, tree, mode)
      {
        'format'         => 2,
        'mode'           => mode,
        'plugin'         => SoulAtelier::VERSION,
        'sketchup'       => Sketchup.version.to_s,
        'created'        => Time.now.strftime('%Y-%m-%dT%H:%M:%S'),
        'model'          => model.title.to_s,
        'drawing_scale'  => DRAWING_SCALE,
        'section_active' => section_active?(model),
        'keep_groups'    => keep,
        'groups'         => keep && tree ? tree[:nodes] : []
      }
    end

    def self.view_info(view)
      cam = view.camera
      vw = view.vpwidth.to_f
      vh = view.vpheight.to_f
      h_in = cam.height.to_f
      w_in = h_in * vw / vh
      t  = cam.target
      xa = cam.xaxis
      ya = cam.yaxis
      dir = cam.direction
      ll = [
        t.x.to_f - xa.x * w_in / 2 - ya.x * h_in / 2,
        t.y.to_f - xa.y * w_in / 2 - ya.y * h_in / 2,
        t.z.to_f - xa.z * w_in / 2 - ya.z * h_in / 2
      ].map { |v| v * MM }
      {
        'height_mm'     => h_in * MM,
        'width_mm'      => w_in * MM,
        'vp_width'      => vw,
        'vp_height'     => vh,
        'lower_left_mm' => ll,
        'xaxis'         => [xa.x, xa.y, xa.z].map(&:to_f),
        'yaxis'         => [ya.x, ya.y, ya.z].map(&:to_f),
        'direction'     => [dir.x, dir.y, dir.z].map(&:to_f)
      }
    end

    def self.section_active?(model)
      !model.active_entities.active_section_plane.nil? || !model.entities.active_section_plane.nil?
    rescue StandardError
      false
    end

    def self.camera_copy(c)
      copy = Sketchup::Camera.new(c.eye, c.target, c.up, c.perspective?)
      if c.perspective?
        copy.fov = c.fov
      else
        copy.height = c.height
      end
      copy
    end

    # Ẩn tạm các đối tượng không được chọn (trong ngữ cảnh đang mở)
    def self.hide_unselected(model, selection)
      keep = {}
      selection.each { |e| keep[e.entityID] = true }
      model.active_entities.each do |e|
        next if keep[e.entityID]
        next unless e.respond_to?(:hidden=)
        e.hidden = true unless e.hidden?
      end
    end

    def self.prepare_dir
      FileUtils.mkdir_p(BRIDGE_DIR)
      Dir.glob(File.join(BRIDGE_DIR, 'clip*.{pdf,json}')).each { |f| File.delete(f) rescue nil }
    end

    def self.write_json(info)
      File.open(File.join(BRIDGE_DIR, 'clip.json'), 'w:UTF-8') { |f| f.write(JSON.generate(info)) }
    end

    def self.done_message(text)
      Sketchup.status_text = "SOUL.Atelier: #{text} Sang Revit bấm \"Dán 2D SketchUp\"."
      notify("#{text} Sang Revit bấm \"Dán 2D SketchUp\".")
    end

    def self.notify(text)
      ext = Sketchup.extensions['SOUL.Atelier'] rescue nil
      UI::Notification.new(ext, text).show if defined?(UI::Notification) && ext
    rescue StandardError
      nil
    end
  end
end

SoulAtelier.register_tool('copy_2d', 'Copy 2D sang Revit',
  :tooltip => 'Copy 2D sang Revit (góc nhìn hiện tại)',
  :status  => 'Xuất góc nhìn hiện tại thành bản vẽ 2D để dán vào Revit (nút "Dán 2D SketchUp").',
  :icon    => 'copy2d') { SoulAtelier::Copy2D.run }

SoulAtelier.register_tool('copy_faces', 'Copy 5 mặt sang Revit',
  :tooltip => 'Copy 5 mặt (trên, trước, sau, trái, phải) của đối tượng đang chọn sang Revit',
  :status  => 'Chọn đối tượng (vd group tủ) → xuất các mặt 2D để dán vào Revit, có thể giữ group.',
  :icon    => 'copy5') { SoulAtelier::Copy2D.run_faces }

SoulAtelier.register_tool('copy_options', 'Tùy chọn Copy 2D...',
  :toolbar => false,
  :status  => 'Bật/tắt giữ group khi copy 2D sang Revit.') { SoulAtelier::Copy2D.options }
