# encoding: UTF-8
# SOUL.Atelier – SketchUp Bridge
# Tạo bởi Nguyễn Thái Linh
require 'sketchup.rb'
require 'extensions.rb'

module SoulAtelier
  module SuBridge
    unless file_loaded?(__FILE__)
      ex = SketchupExtension.new('SOUL.Atelier', 'soul_atelier/main')
      ex.description = 'Bộ công cụ SOUL.Atelier: Copy 2D / 5 mặt sang Revit, Paste từ Revit, SOUL Profile, SOUL Cầu thang, SOUL Lan can. Tạo bởi Nguyễn Thái Linh.'
      ex.version     = '1.7.4'
      ex.creator     = 'Nguyễn Thái Linh'
      ex.copyright   = '© SOUL.Atelier'
      Sketchup.register_extension(ex, true)
      file_loaded(__FILE__)
    end
  end
end
