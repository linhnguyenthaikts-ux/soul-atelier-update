# encoding: UTF-8
# SOUL.Atelier – Tool Lan can (kính / sắt) – nạp từ tools/stair_railing.rb
# Đơn vị nhập trong hộp thoại: mm. Nội bộ SketchUp: inch.
require 'sketchup.rb'
require 'json'

module SoulAtelier
  module Railing
    PLUGIN_DIR = File.dirname(__FILE__)
    DICT = 'SOUL_RAILING'.freeze
    PREF = 'SOUL_Railing'.freeze
    Z = Geom::Vector3d.new(0, 0, 1)

    DEFAULTS = {
      'type' => 'glass', 'H' => 1100, 'offset' => 0, 'stair_side' => 'left',
      # --- Kính
      'g_mount' => 'spigot', 'g_thick' => 12, 'g_maxw' => 1200, 'g_joint' => 10,
      'g_bottom' => 50, 'g_spigot_d' => 55, 'g_spigot_h' => 150,
      'g_ch_w' => 60, 'g_ch_h' => 100,
      'g_post_spacing' => 1200, 'g_post_d' => 50, 'g_clear' => 15, 'g_top_gap' => 50,
      'g_rail' => 'round', 'g_rail_d' => 50, 'g_rail_w' => 40, 'g_rail_h' => 60,
      'g_rail_mat' => 'inox', 'g_tint' => 'clear',
      # Kính gắn hông cầu thang
      'g_side' => 'right', 'g_standoff' => 30, 'g_below' => 250, 'g_clip' => true,
      'g_bolt_z1' => 70, 'g_bolt_z2' => 180, 'g_bolt_edge' => 150, 'g_bolt_d' => 30,
      'g_newel' => 'start', 'g_newel_size' => 50,
      # --- Sắt
      'i_finish' => 'black', 'i_post' => 40, 'i_post_spacing' => 1500,
      'i_rail_w' => 40, 'i_rail_h' => 80,
      'i_infill' => 'vertical', 'i_bal' => 14, 'i_gap' => 100,
      'i_hbar_n' => 6, 'i_hbar_w' => 20, 'i_hbar_h' => 10, 'i_panel_t' => 3,
      'i_bottom_rail' => true, 'i_br_w' => 40, 'i_br_h' => 20, 'i_bottom' => 100
    }.freeze

    MATS = {
      'glass'  => ['SOUL_Kinh',         [160, 205, 215], 0.35],
      'glass_grey' => ['SOUL_Kinh_Xam',   [80, 92, 92],    0.55],
      'inox'   => ['SOUL_Inox',         [192, 194, 198], 1.0],
      'black'  => ['SOUL_Sat_SonDen',   [35, 35, 35],    1.0],
      'white'  => ['SOUL_Sat_SonTrang', [235, 235, 232], 1.0],
      'bronze' => ['SOUL_Dong',         [140, 105, 70],  1.0],
      'alu'    => ['SOUL_Nhom',         [150, 152, 155], 1.0]
    }.freeze

    MOUNT_NAMES  = { 'spigot' => 'kẹp chân', 'channel' => 'ray U', 'post' => 'trụ inox', 'side' => 'gắn hông' }.freeze
    INFILL_NAMES = { 'vertical' => 'song đứng', 'horizontal' => 'song ngang', 'panel' => 'tấm' }.freeze

    # ------------------------------------------------------------------
    # Tiện ích hình học
    # ------------------------------------------------------------------
    def self.mm(v)
      v.to_f.mm.to_f
    end

    def self.vs(v, s)
      Geom::Vector3d.new(v.x * s, v.y * s, v.z * s)
    end

    def self.mat(key)
      name, rgb, alpha = MATS[key] || MATS['black']
      mats = Sketchup.active_model.materials
      m = mats[name]
      unless m
        m = mats.add(name)
        m.color = Sketchup::Color.new(*rgb)
        m.alpha = alpha
      end
      m
    end

    def self.sub(ents, name)
      g = ents.add_group
      g.name = name
      g
    end

    def self.seg_data(a, b)
      v = b - a
      len = v.length.to_f
      raise 'Có đoạn đường dẫn dài bằng 0.' if len < 1e-6
      hd = Geom::Vector3d.new(v.x, v.y, 0)
      raise 'Đường dẫn có đoạn thẳng đứng – không dựng lan can được.' if hd.length.to_f < 1e-6
      hd.normalize!
      { len: len, dir: v.normalize, hdir: hd, u: (hd * Z).normalize,
        hfac: Math.sqrt(v.x.to_f**2 + v.y.to_f**2) / len }
    end

    # Bỏ điểm trùng và điểm thẳng hàng (cạnh bị chia nhỏ)
    def self.simplify(pts, closed)
      tol = 0.5.mm
      res = []
      pts.each { |p| res << p unless res.last && res.last.distance(p) < tol }
      res.pop if closed && res.size > 1 && res.first.distance(res.last) < tol
      loop do
        n = res.size
        break if n < 3
        idx = (closed ? (0...n) : (1...n - 1)).find do |i|
          v1 = res[i] - res[(i - 1) % n]
          v2 = res[(i + 1) % n] - res[i]
          v1.parallel?(v2) && v1.samedirection?(v2)
        end
        break unless idx
        res.delete_at(idx)
      end
      res
    end

    # Lệch đường dẫn theo phương ngang (d > 0: sang phải theo chiều vẽ)
    def self.offset_path(pts, closed, d)
      return pts.map(&:clone) if d.abs < 1e-9
      n = pts.size
      m = closed ? n : n - 1
      normals = (0...m).map do |i|
        a = pts[i]
        b = pts[(i + 1) % n]
        h = Geom::Vector3d.new(b.x - a.x, b.y - a.y, 0)
        h.length.to_f > 1e-9 ? (h.normalize * Z).normalize : nil
      end
      pts.each_with_index.map do |p, i|
        np = (i > 0 || closed) ? normals[(i - 1) % m] : nil
        nx = i < m ? normals[i] : nil
        v =
          if np && nx
            bis = np + nx
            if bis.length.to_f < 1e-6
              vs(np, d)
            else
              bis.normalize!
              vs(bis, d / bis.dot(np))
            end
          else
            vs(np || nx, d)
          end
        p + v
      end
    end

    def self.stations(len, spacing)
      k = [((len - 0.5.mm) / spacing).ceil, 1].max
      (0..k).map { |j| len * j / k.to_f }
    end

    # Khối hộp: tâm đáy base, trục xa/ya ngang, cao lz theo Z
    def self.box(ents, base, xa, ya, lx, ly, lz, mat)
      g = ents.add_group
      o = base + vs(xa, -lx / 2.0) + vs(ya, -ly / 2.0)
      f = g.entities.add_face(o, o + vs(xa, lx), o + vs(xa, lx) + vs(ya, ly), o + vs(ya, ly))
      f.reverse! if f.normal.dot(Z) < 0
      f.pushpull(lz)
      g.material = mat
      g
    end

    def self.cyl(ents, base, r, hgt, mat, axis = Z, segs = 24)
      g = ents.add_group
      e = g.entities.add_circle(base, axis, r, segs)
      f = g.entities.add_face(e)
      f.reverse! if f.normal.dot(axis) < 0
      f.pushpull(hgt)
      g.material = mat
      g
    end

    # Tấm phẳng đứng theo đoạn a→(dir), từ s0 đến s1, cao zb→zt, dày t (canh giữa đường dẫn).
    # zclip: cắt phần nằm dưới cao độ này (kính gắn hông cắt theo sàn). Trả về diện tích (inch²).
    def self.panel(ents, a, sd, s0, s1, zb, zt, t, mat, zclip = nil)
      off = vs(sd[:u], -t / 2.0)
      q0 = a + vs(sd[:dir], s0) + vs(Z, zb) + off
      q1 = a + vs(sd[:dir], s1) + vs(Z, zb) + off
      poly = [q0, q1, q1 + vs(Z, zt - zb), q0 + vs(Z, zt - zb)]
      poly = clip_z(poly, zclip) if zclip
      return 0.0 if poly.size < 3
      area = poly_area(poly)
      return 0.0 if area < 1.0
      g = ents.add_group
      f = g.entities.add_face(poly)
      f.reverse! if f.normal.dot(sd[:u]) < 0
      f.pushpull(t)
      g.material = mat
      area
    end

    def self.clip_z(poly, zc)
      out = []
      poly.each_with_index do |pt, i|
        nx = poly[(i + 1) % poly.size]
        pin = pt.z.to_f >= zc - 1e-6
        nin = nx.z.to_f >= zc - 1e-6
        out << pt if pin
        next if pin == nin
        k = (zc - pt.z.to_f) / (nx.z.to_f - pt.z.to_f)
        out << Geom.linear_combination(1.0 - k, pt, k, nx)
      end
      res = []
      out.each { |pt| res << pt unless res.last && res.last.distance(pt).to_f < 0.01 }
      res.pop if res.size > 1 && res.first.distance(res.last).to_f < 0.01
      res
    end

    def self.poly_area(poly)
      o = poly[0]
      sum = Geom::Vector3d.new(0, 0, 0)
      (1...poly.size - 1).each { |i| sum += (poly[i] - o) * (poly[i + 1] - o) }
      sum.length.to_f / 2.0
    end

    # Quét tiết diện (tròn / chữ nhật) theo đường dẫn nâng cao dz – có vát góc
    def self.sweep(ents, pts, closed, dz, shape, w, h, mat)
      g = ents.add_group
      ge = g.entities
      path = pts.map { |pt| pt + vs(Z, dz) }
      if closed
        mid = Geom.linear_combination(0.5, path[0], 0.5, path[1])
        path = [mid] + path[1..-1] + [path[0], mid]
      end
      c = path[0]
      d0 = (path[1] - path[0]).normalize
      face =
        if shape == :round
          ge.add_face(ge.add_circle(c, d0, w / 2.0, 24))
        else
          u = (d0 * Z).normalize
          v = (u * d0).normalize
          hw = w / 2.0
          hh = h / 2.0
          ge.add_face(c + vs(u, -hw) + vs(v, -hh), c + vs(u, hw) + vs(v, -hh),
                      c + vs(u, hw) + vs(v, hh), c + vs(u, -hw) + vs(v, hh))
        end
      edges = ge.add_edges(path)
      face.followme(edges)
      ge.grep(Sketchup::Edge).each { |e| e.erase! if e.valid? && e.faces.empty? }
      g.material = mat
      g
    end

    def self.add_glass(q, w, h, area)
      return if area <= 0
      q[:glass_n] += 1
      q[:glass_area] += area
      q[:gw_max] = [q[:gw_max], w].max
      q[:gh_max] = [q[:gh_max], h].max
    end

    # ------------------------------------------------------------------
    # Dựng lan can
    # ------------------------------------------------------------------
    def self.build(ents, pts0, closed, p)
      raise 'Chiều cao lan can phải > 0.' if p['H'].to_f <= 0
      pts = offset_path(pts0, closed, mm(p['offset']))
      n = pts.size
      m = closed ? n : n - 1
      segs = (0...m).map { |i| [pts[i], pts[(i + 1) % n]] }
      segs.each { |a, b| seg_data(a, b) } # kiểm tra trước khi dựng

      root = ents.add_group
      q = Hash.new(0)
      q[:len] = segs.sum { |a, b| a.distance(b).to_f }
      if p['type'] == 'iron'
        root.name = "SOUL Lan can sắt (#{INFILL_NAMES[p['i_infill']]}) H#{p['H'].to_i}"
        build_iron(root.entities, pts, closed, segs, p, q)
      else
        root.name = "SOUL Lan can kính (#{MOUNT_NAMES[p['g_mount']]}) H#{p['H'].to_i}"
        build_glass(root.entities, pts, closed, segs, p, q)
      end
      root.set_attribute(DICT, 'params', p.to_json)
      root.set_attribute(DICT, 'path', pts0.flat_map { |pt| [pt.x.to_f, pt.y.to_f, pt.z.to_f] })
      root.set_attribute(DICT, 'closed', closed)
      root.layer = Sketchup.active_model.layers.add('SOUL_Lan can')
      [root, q]
    end

    def self.build_glass(ents, pts, closed, segs, p, q)
      h = mm(p['H'])
      t = mm(p['g_thick'])
      joint = mm(p['g_joint'])
      rail = p['g_rail']
      rail_size = { 'round' => mm(p['g_rail_d']), 'rect' => mm(p['g_rail_h']) }[rail] || 0.0
      glass = mat(p['g_tint'] == 'grey' ? 'glass_grey' : 'glass')
      steel = mat('inox')
      rail_mat = mat(p['g_rail_mat'])
      gg = sub(ents, 'Kính')
      m = segs.size
      rail_pts = pts

      if p['g_mount'] == 'side'
        rail_pts = build_glass_side(ents, gg, pts, closed, segs, p, q, h - rail_size, glass, steel, rail_mat)
      elsif p['g_mount'] == 'post'
        pd = mm(p['g_post_d'])
        clear = mm(p['g_clear'])
        spacing = mm(p['g_post_spacing'])
        raise 'Khoảng cách trụ phải > 0.' if spacing <= 0
        zb = mm(p['g_bottom'])
        zt = h - rail_size - mm(p['g_top_gap'])
        post_top = h - rail_size
        gp = sub(ents, 'Trụ')
        segs.each_with_index do |(a, b), i|
          sd = seg_data(a, b)
          st = stations(sd[:len], spacing)
          st[0...-1].each { |s| cyl(gp.entities, a + vs(sd[:dir], s), pd / 2.0, post_top, steel); q[:posts] += 1 }
          if !closed && i == m - 1
            cyl(gp.entities, b, pd / 2.0, post_top, steel)
            q[:posts] += 1
          end
          st.each_cons(2) do |s0, s1|
            a0 = s0 + pd / 2.0 + clear
            a1 = s1 - pd / 2.0 - clear
            next if a1 <= a0 || zt <= zb
            add_glass(q, a1 - a0, zt - zb, panel(gg.entities, a, sd, a0, a1, zb, zt, t, glass))
          end
        end
      else
        spigot = p['g_mount'] == 'spigot'
        zb = spigot ? mm(p['g_bottom']) : mm(20)
        zt = h - rail_size
        maxw = mm(p['g_maxw'])
        raise 'Khổ kính tối đa phải > 0.' if maxw <= 0
        gs = sub(ents, spigot ? 'Chân kẹp' : 'Ray U')
        unless spigot
          chh = mm(p['g_ch_h'])
          sweep(gs.entities, pts, closed, chh / 2.0, :rect, mm(p['g_ch_w']), chh, mat('alu'))
          q[:channel] = q[:len]
        end
        segs.each_with_index do |(a, b), i|
          sd = seg_data(a, b)
          ia = (closed || i > 0) ? t / 2.0 + joint : 0.0
          ib = (closed || i < m - 1) ? t / 2.0 + joint : 0.0
          usable = sd[:len] - ia - ib
          next if usable <= 0 || zt <= zb
          k = [((usable + joint) / (maxw + joint) - 1e-6).ceil, 1].max
          w = (usable - (k - 1) * joint) / k
          k.times do |j|
            s0 = ia + j * (w + joint)
            s1 = s0 + w
            add_glass(q, w, zt - zb, panel(gg.entities, a, sd, s0, s1, zb, zt, t, glass))
            next unless spigot
            locs = w < mm(250) ? [s0 + w / 2.0] : [s0 + [w * 0.2, mm(100)].max, s1 - [w * 0.2, mm(100)].max]
            locs.each do |s|
              cyl(gs.entities, a + vs(sd[:dir], s), mm(p['g_spigot_d']) / 2.0, mm(p['g_spigot_h']), steel)
              q[:spigots] += 1
            end
          end
        end
      end

      return if rail == 'none'
      gr = sub(ents, 'Tay vịn')
      if rail == 'round'
        sweep(gr.entities, rail_pts, closed, h - rail_size / 2.0, :round, rail_size, rail_size, rail_mat)
      else
        sweep(gr.entities, rail_pts, closed, h - rail_size / 2.0, :rect, mm(p['g_rail_w']), rail_size, rail_mat)
      end
      q[:rail] = q[:len]
    end

    # Kính gắn hông cầu thang: đường dẫn = mép mũi bậc / mặt hông cốn thang.
    # Kính lệch ra ngoài (standoff), thòng xuống dưới mũi bậc, bắt ốc pát vào hông cốn.
    # Trả về đường tim kính để chạy tay vịn.
    def self.build_glass_side(ents, gg, pts, closed, segs, p, q, zt, glass, steel, rail_mat)
      t = mm(p['g_thick'])
      joint = mm(p['g_joint'])
      sgn = p['g_side'] == 'left' ? -1.0 : 1.0
      so = mm(p['g_standoff'])
      so = [so, mm(p['g_min_standoff'])].max if p['g_min_standoff'].to_f > 0
      gpts = offset_path(pts, closed, sgn * (so + t / 2.0))
      n = gpts.size
      m = segs.size
      gsd = (0...m).map { |i| seg_data(gpts[i], gpts[(i + 1) % n]) }
      zb = -mm(p['g_below'])
      raise 'Phần kính thòng xuống phải > 0.' if zb >= 0
      zclip = p['g_clip'] == true ? pts.map { |pt| pt.z.to_f }.min : nil
      maxw = mm(p['g_maxw'])
      raise 'Khổ kính tối đa phải > 0.' if maxw <= 0
      newel = closed ? 'none' : p['g_newel']
      ns = mm(p['g_newel_size'])
      nclear = mm(p['g_clear'])
      bd = mm(p['g_bolt_d'])
      bz = [mm(p['g_bolt_z1']), mm(p['g_bolt_z2'])].uniq.select { |z| z > 0 && -z > zb + mm(20) }
      raise 'Cao độ ốc pát phải nằm trong phần kính thòng xuống.' if bz.empty?

      # Khe tại đỉnh gấp: gấp theo độ dốc (cùng hướng mặt bằng) chỉ cần khe ghép; rẽ góc mặt bằng thì chừa thêm t/2
      inset = lambda do |i0, i1|
        gsd[i0][:hdir].samedirection?(gsd[i1][:hdir]) ? joint / 2.0 : t / 2.0 + joint
      end

      gb = sub(ents, 'Ốc pát kính')
      gsd.each_with_index do |sd, i|
        a = gpts[i]
        ia = (closed || i > 0) ? inset.call((i - 1) % m, i) : 0.0
        ib = (closed || i < m - 1) ? inset.call(i, (i + 1) % m) : 0.0
        ia = ns / 2.0 + nclear if !closed && i.zero? && %w[start both].include?(newel)
        ib = ns / 2.0 + nclear if !closed && i == m - 1 && %w[end both].include?(newel)
        usable = sd[:len] - ia - ib
        next if usable <= 0
        k = [((usable + joint) / (maxw + joint) - 1e-6).ceil, 1].max
        w = (usable - (k - 1) * joint) / k
        k.times do |j|
          s0 = ia + j * (w + joint)
          s1 = s0 + w
          area = panel(gg.entities, a, sd, s0, s1, zb, zt, t, glass, zclip)
          next if area <= 0
          add_glass(q, w, zt - zb, area)
          e = [mm(p['g_bolt_edge']), w / 4.0].min
          cols = [s0 + e, s1 - e]
          cols.insert(1, (s0 + s1) / 2.0) if w > mm(1100)
          axis = vs(sd[:u], sgn)
          cols.each do |s|
            bz.each do |z|
              c = a + vs(sd[:dir], s) + vs(Z, -z)
              next if zclip && c.z.to_f < zclip + mm(40)
              cyl(gb.entities, c + vs(axis, -(so + t / 2.0)), bd / 2.0, so + t + mm(12), steel, axis)
              q[:bolts] += 1
            end
          end
        end
      end

      unless newel == 'none'
        gn = sub(ents, 'Trụ đầu')
        hh = mm(p['H'])
        if %w[start both].include?(newel)
          box(gn.entities, gpts.first, gsd.first[:hdir], gsd.first[:u], ns, ns, hh, rail_mat)
          q[:newels] += 1
        end
        if %w[end both].include?(newel)
          box(gn.entities, gpts.last, gsd.last[:hdir], gsd.last[:u], ns, ns, hh, rail_mat)
          q[:newels] += 1
        end
      end
      gpts
    end

    def self.build_iron(ents, pts, closed, segs, p, q)
      h = mm(p['H'])
      fin = mat(p['i_finish'])
      pw = mm(p['i_post'])
      spacing = mm(p['i_post_spacing'])
      raise 'Khoảng cách trụ phải > 0.' if spacing <= 0
      rh = mm(p['i_rail_h'])
      zt = h - rh
      infill = p['i_infill']
      bottom_rail = p['i_bottom_rail'] == true
      zbot = mm(p['i_bottom'])
      brh = mm(p['i_br_h'])
      zb = bottom_rail ? zbot + brh : (infill == 'vertical' ? 0.0 : zbot)
      raise 'Chiều cao lan can quá thấp so với tay vịn / thanh dưới.' if zt <= zb

      gr = sub(ents, 'Tay vịn')
      sweep(gr.entities, pts, closed, h - rh / 2.0, :rect, mm(p['i_rail_w']), rh, fin)
      q[:rail] = q[:len]
      if bottom_rail
        sweep(gr.entities, pts, closed, zbot + brh / 2.0, :rect, mm(p['i_br_w']), brh, fin)
        q[:brail] = q[:len]
      end

      gp = sub(ents, 'Trụ')
      gi = sub(ents, infill == 'panel' ? 'Tấm' : 'Song')
      m = segs.size
      segs.each_with_index do |(a, b), i|
        sd = seg_data(a, b)
        st = stations(sd[:len], spacing)
        st[0...-1].each { |s| box(gp.entities, a + vs(sd[:dir], s), sd[:hdir], sd[:u], pw, pw, zt, fin); q[:posts] += 1 }
        if !closed && i == m - 1
          box(gp.entities, b, sd[:hdir], sd[:u], pw, pw, zt, fin)
          q[:posts] += 1
        end
        st.each_cons(2) do |s0, s1|
          c0 = s0 + pw / 2.0
          c1 = s1 - pw / 2.0
          lc = c1 - c0
          next if lc <= 0
          case infill
          when 'vertical'
            bw = mm(p['i_bal'])
            g = mm(p['i_gap'])
            nb = [((lc - g) / (bw + g) - 1e-6).ceil, 0].max
            gap = (lc - nb * bw) / (nb + 1)
            q[:gapmax] = [q[:gapmax], gap].max
            nb.times do |j|
              s = c0 + gap + bw / 2.0 + j * (bw + gap)
              box(gi.entities, a + vs(sd[:dir], s) + vs(Z, zb), sd[:hdir], sd[:u], bw, bw, zt - zb, fin)
              q[:bal] += 1
            end
          when 'panel'
            q[:panel_area] += panel(gi.entities, a, sd, c0, c1, zb, zt, mm(p['i_panel_t']), fin)
            q[:panel_n] += 1
          end
        end
      end

      return unless infill == 'horizontal'
      nbar = [p['i_hbar_n'].to_i, 1].max
      hbh = mm(p['i_hbar_h'])
      (1..nbar).each do |j|
        z = zb + (zt - zb) * j / (nbar + 1.0)
        sweep(gi.entities, pts, closed, z, :rect, mm(p['i_hbar_w']), hbh, fin)
      end
      q[:hbars] = nbar
      q[:hgap] = (zt - zb) / (nbar + 1.0) - hbh
    end

    # ------------------------------------------------------------------
    # Báo cáo khối lượng
    # ------------------------------------------------------------------
    def self.report(q, p)
      m  = ->(x) { format('%.2f', x * 0.0254) }
      m2 = ->(x) { format('%.2f', x * 0.00064516) }
      mv = ->(x) { (x * 25.4).round }
      l = ["Chiều dài lan can (theo tim): <b>#{m.(q[:len])} m</b>"]
      l << "Trụ: <b>#{q[:posts]}</b> cái" if q[:posts] > 0
      l << "Chân kẹp kính: <b>#{q[:spigots]}</b> cái" if q[:spigots] > 0
      l << "Ray U: <b>#{m.(q[:channel])} m</b>" if q[:channel] > 0
      l << "Ốc pát kính (bắt hông): <b>#{q[:bolts]}</b> bộ" if q[:bolts] > 0
      l << "Trụ đầu cầu thang: <b>#{q[:newels]}</b> cái" if q[:newels] > 0
      if q[:glass_n] > 0
        l << "Kính #{p['g_thick']} mm: <b>#{q[:glass_n]} tấm – #{m2.(q[:glass_area])} m²</b> " \
             "(tấm lớn nhất ~#{mv.(q[:gw_max])} × #{mv.(q[:gh_max])} mm)"
      end
      l << "Tay vịn: <b>#{m.(q[:rail])} m</b>" if q[:rail] > 0
      l << "Thanh dưới: <b>#{m.(q[:brail])} m</b>" if q[:brail] > 0
      l << "Song đứng: <b>#{q[:bal]}</b> cây – khe hở thực tế lớn nhất <b>#{mv.(q[:gapmax])} mm</b>" if q[:bal] > 0
      if q[:hbars] > 0
        l << "Song ngang: <b>#{q[:hbars]} thanh × #{m.(q[:len])} m</b> – khe giữa 2 thanh <b>#{mv.(q[:hgap])} mm</b>"
        l << '<span class="warn">Song ngang dễ tạo chỗ leo trèo – cân nhắc khi nhà có trẻ nhỏ.</span>'
      end
      l << "Tấm: <b>#{q[:panel_n]} tấm – #{m2.(q[:panel_area])} m²</b>" if q[:panel_n] > 0
      l << '<i>Khối lượng ước lượng từ mô hình, chưa tính hao hụt – đo thực tế trước khi đặt gia công.</i>'
      l
    end

    # ------------------------------------------------------------------
    # Đường dẫn
    # ------------------------------------------------------------------
    def self.path_from_selection(sel)
      edges = sel.grep(Sketchup::Edge)
      return nil if edges.empty?
      adj = Hash.new { |hh, k| hh[k] = [] }
      edges.each { |e| e.vertices.each { |v| adj[v] << e } }
      raise 'Các cạnh chọn bị rẽ nhánh – chỉ chọn 1 đường liền mạch.' if adj.values.any? { |a| a.size > 2 }
      ends = adj.keys.select { |v| adj[v].size == 1 }
      raise 'Các cạnh chọn không liền nhau – chỉ chọn 1 đường liền mạch.' if ends.size > 2
      closed = ends.empty?
      v = closed ? adj.keys.first : ends.first
      pts = [v.position]
      used = {}
      loop do
        e = adj[v].find { |x| !used[x] }
        break unless e
        used[e] = true
        v = e.other_vertex(v)
        pts << v.position
      end
      raise 'Các cạnh chọn không liền nhau – chỉ chọn 1 đường liền mạch.' if used.size != edges.size
      pts.pop if closed
      pts = simplify(pts, closed)
      closed = false if pts.size < 3
      [pts, closed]
    end

    def self.stored_path(g)
      arr = g.get_attribute(DICT, 'path') || []
      pts = arr.each_slice(3).map { |x, y, z| Geom::Point3d.new(x, y, z) }
      [pts, g.get_attribute(DICT, 'closed') == true]
    end

    def self.railing?(e)
      e.is_a?(Sketchup::Group) && e.valid? && !e.get_attribute(DICT, 'params').nil?
    end

    # ------------------------------------------------------------------
    # Thực thi
    # ------------------------------------------------------------------
    def self.run_op(name)
      model = Sketchup.active_model
      model.start_operation(name, true)
      g, q, p = yield
      model.commit_operation
      model.selection.clear
      model.selection.add(g)
      @edit = g
      send_result(report(q, p))
      send_info
    rescue StandardError => e
      model.abort_operation
      UI.messagebox("Lỗi khi dựng lan can:\n#{e.message}")
      puts e.full_message
    end

    # Lan can dựng theo đường mép cầu thang SOUL (giữ liên kết để tự dựng lại khi sửa cầu thang)
    def self.link_build(ents, st, side, p)
      pts = SoulAtelier::Stair.rail_points(st, side)
      raise 'Cầu thang chưa có dữ liệu đường mép – dựng lại cầu thang.' if pts.size < 2
      p2 = p.merge('g_min_standoff' => SoulAtelier::Stair.side_clear(st, side))
      g, q = build(ents, pts, false, p2)
      g.set_attribute(DICT, 'stair_uid', st.get_attribute('SOUL_STAIR', 'uid'))
      g.set_attribute(DICT, 'stair_side', side)
      g.name = "#{g.name} – cầu thang (#{side == 'left' ? 'trái' : 'phải'})"
      [g, q]
    end

    def self.rebuild_linked(st)
      uid = st.get_attribute('SOUL_STAIR', 'uid')
      ents = st.parent.entities
      ents.grep(Sketchup::Group).select { |g| g.valid? && g.get_attribute(DICT, 'stair_uid') == uid }.each do |old|
        p = DEFAULTS.merge(JSON.parse(old.get_attribute(DICT, 'params')))
        side = old.get_attribute(DICT, 'stair_side') || 'left'
        old.erase!
        link_build(ents, st, side, p)
      end
    end

    def self.on_create(p, force_pick)
      p = DEFAULTS.merge(p)
      Sketchup.write_default(PREF, 'params', p.to_json)
      model = Sketchup.active_model
      sel = model.selection
      if !force_pick && sel.size == 1 && defined?(SoulAtelier::Stair) && SoulAtelier::Stair.stair?(sel.first)
        st = sel.first
        side = p['stair_side'] == 'right' ? 'right' : 'left'
        run_op('SOUL – Lan can theo cầu thang') do
          link_build(st.parent.entities, st, side, p) + [p]
        end
        return
      end
      res = nil
      unless force_pick
        begin
          res = path_from_selection(model.selection)
        rescue RuntimeError => e
          UI.messagebox(e.message)
          return
        end
      end

      if res
        pts, closed = res
        run_op('SOUL – Dựng lan can') { build(model.active_entities, pts, closed, p) + [p] }
      elsif !force_pick && @edit && @edit.valid?
        old = @edit
        pts, closed = stored_path(old)
        pts = pts.map { |pt| pt.transform(old.transformation) }
        ents = old.parent.entities
        uid = old.get_attribute(DICT, 'stair_uid')
        side = old.get_attribute(DICT, 'stair_side')
        st = uid && ents.grep(Sketchup::Group).find { |e| e.valid? && e.get_attribute('SOUL_STAIR', 'uid') == uid }
        run_op('SOUL – Sửa lan can') do
          old.erase!
          if st
            link_build(ents, st, side, p) + [p]
          else
            build(ents, pts, closed, p) + [p]
          end
        end
      else
        model.select_tool(PickTool.new do |pk, cl|
          run_op('SOUL – Dựng lan can') { build(model.active_entities, pk, cl, p) + [p] }
        end)
      end
    end

    # ------------------------------------------------------------------
    # Hộp thoại
    # ------------------------------------------------------------------
    def self.saved_params
      s = Sketchup.read_default(PREF, 'params')
      s ? DEFAULTS.merge(JSON.parse(s)) : DEFAULTS.dup
    rescue StandardError
      DEFAULTS.dup
    end

    def self.info_text
      sel = Sketchup.active_model.selection
      edges = sel.grep(Sketchup::Edge)
      if sel.size == 1 && defined?(SoulAtelier::Stair) && SoulAtelier::Stair.stair?(sel.first)
        'Đang chọn CẦU THANG SOUL → chọn phía (trái/phải theo hướng đi lên) rồi bấm TẠO. ' \
          'Lan can sẽ tự dựng lại khi sửa cầu thang.'
      elsif edges.any?
        len = edges.sum { |e| e.length.to_f } * 0.0254
        "Đang chọn #{edges.size} cạnh (#{format('%.2f', len)} m) → bấm TẠO để dựng lan can MỚI theo các cạnh này."
      elsif @edit && @edit.valid?
        "Đang sửa: #{@edit.name} → chỉnh thông số rồi bấm TẠO để CẬP NHẬT."
      else
        'Chưa chọn cạnh → bấm TẠO rồi click các điểm trên mô hình (Enter để kết thúc).'
      end
    end

    def self.visible?
      @dlg && @dlg.visible?
    end

    def self.send_init(params = nil)
      return unless visible?
      @dlg.execute_script("init(#{params ? params.to_json : 'null'}, #{info_text.to_json})")
    end

    # Gọi khi vùng chọn thay đổi: chọn 1 lan can SOUL → nạp thông số của nó
    def self.send_info
      return unless visible?
      sel = Sketchup.active_model.selection
      if sel.size == 1 && railing?(sel.first) && sel.first != @edit
        @edit = sel.first
        send_init(DEFAULTS.merge(JSON.parse(@edit.get_attribute(DICT, 'params'))))
      else
        @edit = nil if sel.grep(Sketchup::Edge).any?
        send_init
      end
    end

    def self.send_result(lines)
      @dlg.execute_script("showResult(#{lines.to_json})") if visible?
    end

    class SelObs < Sketchup::SelectionObserver
      def onSelectionBulkChange(_sel)
        Railing.send_info
      end

      def onSelectionCleared(_sel)
        Railing.send_info
      end
    end

    def self.show_dialog(edit_group = nil)
      @edit = edit_group if edit_group
      if visible?
        params = @edit && @edit.valid? ? DEFAULTS.merge(JSON.parse(@edit.get_attribute(DICT, 'params'))) : nil
        send_init(params)
        @dlg.bring_to_front
        return
      end
      @dlg = UI::HtmlDialog.new(
        dialog_title: 'SOUL.atelier – Dựng lan can', preferences_key: 'SOUL_Railing_dlg',
        width: 430, height: 780, min_width: 380, min_height: 500,
        style: UI::HtmlDialog::STYLE_DIALOG
      )
      @dlg.set_file(File.join(PLUGIN_DIR, 'railing.html'))
      @dlg.add_action_callback('ready') do |_c|
        params = @edit && @edit.valid? ? DEFAULTS.merge(JSON.parse(@edit.get_attribute(DICT, 'params'))) : saved_params
        send_init(params)
      end
      @dlg.add_action_callback('refresh') { |_c| send_info }
      @dlg.add_action_callback('create') { |_c, json| on_create(JSON.parse(json), false) }
      @dlg.add_action_callback('pick') { |_c, json| on_create(JSON.parse(json), true) }
      @dlg.add_action_callback('reset') { |_c| send_init(DEFAULTS) }
      @obs ||= SelObs.new
      model = Sketchup.active_model
      model.selection.add_observer(@obs)
      @dlg.set_on_closed { model.selection.remove_observer(@obs) rescue nil }
      @dlg.show
    end

    # ------------------------------------------------------------------
    # Công cụ click điểm
    # ------------------------------------------------------------------
    class PickTool
      def initialize(label = 'Lan can SOUL', &done)
        @label = label
        @done = done
        @pts = []
        @ip = Sketchup::InputPoint.new
        @last_ip = Sketchup::InputPoint.new
      end

      def activate
        status
      end

      def resume(view)
        status
        view.invalidate
      end

      def deactivate(view)
        view.invalidate
      end

      def status
        Sketchup.status_text = "#{@label}: click các điểm đường dẫn. Enter/Double-click: kết thúc • " \
                               'Click lại điểm đầu: khép kín • Backspace: bỏ điểm • Esc: huỷ • Gõ số: nhập chiều dài'
        Sketchup.vcb_label = 'Chiều dài'
      end

      def enableVCB?
        true
      end

      def onMouseMove(_flags, x, y, view)
        @pts.empty? ? @ip.pick(view, x, y) : @ip.pick(view, x, y, @last_ip)
        view.tooltip = @ip.tooltip if @ip.valid?
        view.invalidate
      end

      def onLButtonDown(_flags, _x, _y, view)
        return unless @ip.valid?
        pt = @ip.position
        if @pts.size >= 3 && pt.distance(@pts.first) < 1.mm
          finish(true)
          return
        end
        add(pt, @ip)
        view.invalidate
      end

      def onLButtonDoubleClick(_flags, _x, _y, _view)
        finish(false)
      end

      def onReturn(_view)
        finish(false)
      end

      def onKeyDown(key, _repeat, _flags, view)
        return unless [8, 127].include?(key) && @pts.any?
        @pts.pop
        @last_ip = @pts.empty? ? Sketchup::InputPoint.new : Sketchup::InputPoint.new(@pts.last)
        view.invalidate
      end

      def onUserText(text, view)
        len = (text.to_l rescue nil)
        return UI.beep if len.nil? || @pts.empty? || !@ip.valid?
        v = @ip.position - @pts.last
        return UI.beep if v.length.to_f < 1e-6
        pt = @pts.last.offset(v, len)
        add(pt, Sketchup::InputPoint.new(pt))
        view.invalidate
      end

      def onCancel(_reason, view)
        if @pts.empty?
          Sketchup.active_model.select_tool(nil)
        else
          @pts.clear
          @last_ip = Sketchup::InputPoint.new
          view.invalidate
        end
      end

      def add(pt, ip)
        return if @pts.last && @pts.last.distance(pt) < 1.mm
        @pts << pt
        @last_ip = Sketchup::InputPoint.new(pt)
        @last_ip.copy!(ip) if ip.equal?(@ip)
      end

      def draw(view)
        @ip.draw(view) if @ip.valid? && @ip.display?
        return if @pts.empty?
        view.line_width = 2
        view.drawing_color = Sketchup::Color.new(220, 60, 40)
        view.draw(GL_LINE_STRIP, @pts) if @pts.size > 1
        view.draw(GL_LINES, [@pts.last, @ip.position]) if @ip.valid?
        view.draw_points(@pts, 7, 2, Sketchup::Color.new(220, 60, 40))
      end

      def getExtents
        bb = Geom::BoundingBox.new
        @pts.each { |pt| bb.add(pt) }
        bb.add(@ip.position) if @ip.valid?
        bb
      end

      def finish(closed)
        model = Sketchup.active_model
        pts = Railing.simplify(@pts.dup, closed)
        if pts.size < 2
          UI.beep
          return
        end
        closed = false if pts.size < 3
        if model.active_path
          inv = model.edit_transform.inverse
          pts = pts.map { |pt| pt.transform(inv) }
        end
        model.select_tool(nil)
        @done.call(pts, closed)
      end
    end

    # Chạy khi đã kích hoạt bản quyền SOUL.Atelier
    def self.guard(&blk)
      SoulAtelier::License.allowed? ? blk.call : SoulAtelier::License.require_activation
    end

    # ------------------------------------------------------------------
    # Menu chuột phải (nút toolbar/menu đăng ký ở tools/stair_railing.rb)
    # ------------------------------------------------------------------
    unless file_loaded?(__FILE__)
      UI.add_context_menu_handler do |menu|
        sel = Sketchup.active_model.selection
        if sel.size == 1 && Railing.railing?(sel.first)
          menu.add_item('SOUL – Sửa lan can') { Railing.guard { Railing.show_dialog(sel.first) } }
        elsif sel.grep(Sketchup::Edge).any?
          menu.add_item('SOUL – Dựng lan can theo cạnh chọn') { Railing.guard { Railing.show_dialog } }
        end
      end
      file_loaded(__FILE__)
    end

  end
end
