# encoding: UTF-8
# SOUL.Atelier – Tool Cầu thang theo đường vẽ mặt bằng – nạp từ tools/stair_railing.rb
# Thang 1 vế / chữ L / chữ U · chiếu nghỉ hoặc rẽ quạt · bản BTCT + bậc xây hoặc console treo
require 'json'

module SoulAtelier
  module Stair
    R = SoulAtelier::Railing
    DICT = 'SOUL_STAIR'.freeze
    PREF = 'SOUL_Stair'.freeze
    PLUGIN_DIR = File.dirname(__FILE__)
    Z = Geom::Vector3d.new(0, 0, 1)
    HALF_PI = Math::PI / 2.0

    DEFAULTS = {
      'H' => 3600, 'N' => 20, 'b' => 250, 'W' => 900,
      'loc' => 'center', 'wall' => 'right',
      'corner' => 'landing', 'kw' => 3, 'corner_list' => '',
      'struct' => 'slab', 't_slab' => 120, 't_land' => 120, 'c_thick' => 100,
      'ts' => 20, 'tr' => 20, 'mortar' => 20,
      'nose' => 30, 'nose_t' => 20, 'nose_side' => 30, 'stone' => 'black',
      'led' => false, 'led_h' => 20, 'led_d' => 25,
      'ff_bot' => 50, 'ff_top' => 50
    }.freeze

    STONES = {
      'black' => ['SOUL_Da_Den',  [38, 38, 40]],
      'white' => ['SOUL_Da_Trang', [228, 225, 218]],
      'grey'  => ['SOUL_Da_Xam',  [125, 125, 122]]
    }.freeze

    # ------------------------------------------------------------------
    # Tiện ích
    # ------------------------------------------------------------------
    def self.mm(v)
      R.mm(v)
    end

    def self.vs(v, s)
      R.vs(v, s)
    end

    def self.to_mm(x)
      x * 25.4
    end

    def self.pz(pt, z)
      Geom::Point3d.new(pt.x, pt.y, z)
    end

    def self.dxy(a, b)
      Math.hypot(a.x.to_f - b.x.to_f, a.y.to_f - b.y.to_f)
    end

    def self.mtl(name, rgb, alpha = 1.0)
      mats = Sketchup.active_model.materials
      m = mats[name]
      return m if m
      m = mats.add(name)
      m.color = Sketchup::Color.new(*rgb)
      m.alpha = alpha
      m
    end

    def self.area_xy(poly)
      s = 0.0
      poly.each_with_index do |a, i|
        b = poly[(i + 1) % poly.size]
        s += a.x.to_f * b.y.to_f - b.x.to_f * a.y.to_f
      end
      s / 2.0
    end

    def self.intersect2d(l1, l2)
      p1, d1 = l1
      p2, d2 = l2
      den = d1.x * d2.y - d1.y * d2.x
      return nil if den.abs < 1e-9
      t = ((p2.x - p1.x) * d2.y - (p2.y - p1.y) * d2.x) / den
      Geom::Point3d.new(p1.x + d1.x * t, p1.y + d1.y * t, 0)
    end

    # Lệch từng cạnh đa giác ra ngoài một khoảng riêng (âm = vào trong)
    def self.offset_poly(poly, dists)
      n = poly.size
      ccw = area_xy(poly) > 0
      lines = (0...n).map do |i|
        a = poly[i]
        b = poly[(i + 1) % n]
        e = Geom::Vector3d.new(b.x - a.x, b.y - a.y, 0).normalize
        nout = ccw ? (e * Z) : (Z * e)
        [a + vs(nout, dists[i]), e]
      end
      (0...n).map do |i|
        q = intersect2d(lines[(i - 1) % n], lines[i]) || lines[i][0]
        pz(q, poly[i].z)
      end
    end

    # Pháp tuyến hướng VÀO TRONG của cạnh i
    def self.inward(poly, i)
      a = poly[i]
      b = poly[(i + 1) % poly.size]
      e = Geom::Vector3d.new(b.x - a.x, b.y - a.y, 0).normalize
      area_xy(poly) > 0 ? (Z * e) : (e * Z)
    end

    # Khối đặc từ đa giác đỉnh (top) và đáy (bot) cùng số điểm (đáy có thể nghiêng)
    def self.solid(ents, top, bot, mat)
      n = top.size
      bot = bot.each_with_index.map { |b, i| b.z.to_f > top[i].z.to_f - 0.01 ? top[i].clone : b }
      return false if bot.each_with_index.all? { |b, i| b.distance(top[i]).to_f < 0.01 }
      faces = []
      faces << mkface(ents, top)
      faces << mkface(ents, bot)
      n.times do |i|
        j = (i + 1) % n
        faces << mkface(ents, [top[i], top[j], bot[j], bot[i]])
      end
      all = top + bot
      c = Geom::Point3d.new(all.sum { |q| q.x.to_f } / all.size, all.sum { |q| q.y.to_f } / all.size,
                            all.sum { |q| q.z.to_f } / all.size)
      faces.compact.each do |f|
        next unless f.valid?
        f.reverse! if (f.bounds.center - c).dot(f.normal) < 0
        f.material = mat
      end
      true
    end

    def self.mkface(ents, pts)
      res = []
      pts.each { |q| res << q unless res.last && res.last.distance(q).to_f < 0.01 }
      res.pop while res.size > 1 && res.first.distance(res.last).to_f < 0.01
      return nil if res.size < 3
      ents.add_face(res)
    rescue ArgumentError
      nil
    end

    def self.prism(poly, zb, zt, mat)
      [poly.map { |q| pz(q, zt) }, poly.map { |q| pz(q, zb) }, mat]
    end

    # Đặt khối dưới dạng component: khối giống hệt nhau (theo hệ trục cục bộ) dùng chung 1 definition
    def self.place(ctx, ents, name, solids, origin, xaxis)
      x = Geom::Vector3d.new(xaxis.x, xaxis.y, 0).normalize
      y = (Z * x).normalize
      zmin = solids.flat_map { |top, bot, _m| top + bot }.map { |q| q.z.to_f }.min
      t = Geom::Transformation.axes(pz(origin, zmin), x, y, Z)
      ti = t.inverse
      loc = solids.map { |top, bot, m| [top.map { |q| q.transform(ti) }, bot.map { |q| q.transform(ti) }, m] }
      sig = name + loc.map do |top, bot, m|
        m.name + (top + bot).map { |q| [q.x, q.y, q.z].map { |v| (v.to_f * 25.4).round(1) } }.join(',')
      end.join('|')
      d = ctx[:defs][sig]
      unless d
        all = loc.flat_map { |top, bot, _m| top + bot }
        dims = [:x, :y, :z].map { |k| (to_mm(all.map { |q| q.send(k).to_f }.max - all.map { |q| q.send(k).to_f }.min)).round }
        d = Sketchup.active_model.definitions.add("#{name} #{dims.join('x')}")
        loc.each { |top, bot, m| solid(d.entities, top, bot, m) }
        ctx[:defs][sig] = d
      end
      ents.add_instance(d, t)
      ctx[:count][d] += 1
    end

    def self.group_solid(ents, name, solids)
      g = ents.add_group
      g.name = name
      solids.each { |top, bot, m| solid(g.entities, top, bot, m) }
      g
    end

    # ------------------------------------------------------------------
    # Mặt bằng: chia bậc, chiếu nghỉ, rẽ quạt
    # ------------------------------------------------------------------
    def self.ray_pt(ei, u0, d1, w, f)
      if f <= Math::PI / 4
        ei + vs(u0, w) + vs(d1, w * Math.tan(f))
      else
        ei + vs(u0, w * Math.cos(f) / Math.sin(f)) + vs(d1, w)
      end
    end

    # Quãng đường trên đường tim vế qua ô rẽ quạt (đơn vị: nửa bề rộng)
    def self.walk_dist(f)
      f <= Math::PI / 4 ? Math.tan(f) : 2.0 - Math.cos(f) / Math.sin(f)
    end

    def self.corner_modes(p, count)
      toks = p['corner_list'].to_s.upcase.split(/[\s,;]+/).reject(&:empty?)
      (0...count).map do |c|
        tok = toks[c]
        mode = tok ? (tok.start_with?('Q') ? 'winder' : 'landing') : p['corner']
        kw = tok && tok =~ /Q(\d+)/ ? Regexp.last_match(1).to_i : p['kw'].to_i
        [mode, [[kw, 2].max, 8].min]
      end
    end

    def self.plan(pts0, p)
      z0 = pts0.first.z.to_f
      pts = pts0.map { |q| Geom::Point3d.new(q.x, q.y, z0) }
      w = mm(p['W'])
      raise 'Bề rộng vế phải > 0.' if w <= 0
      half = w / 2.0
      pts = R.simplify(pts, false)
      raise 'Đường vẽ cầu thang cần ít nhất 2 điểm.' if pts.size < 2
      pts = R.offset_path(pts, false, half) if p['loc'] == 'left'
      pts = R.offset_path(pts, false, -half) if p['loc'] == 'right'

      n_r = p['N'].to_i
      raise 'Số bậc phải ≥ 2.' if n_r < 2
      hgt = mm(p['H'])
      raise 'Cao tầng phải > 0.' if hgt <= 0
      h = hgt / n_r
      b = mm(p['b'])
      raise 'Chiều sâu bậc phải > 0.' if b <= 0

      m = pts.size - 1
      dirs = (0...m).map do |j|
        v = pts[j + 1] - pts[j]
        raise 'Đường vẽ có đoạn dài bằng 0.' if v.length.to_f < 1e-6
        v.normalize
      end
      lens = (0...m).map { |j| pts[j].distance(pts[j + 1]).to_f }
      turns = (0...m - 1).map do |c|
        raise "Góc rẽ thứ #{c + 1} không vuông – bản này chỉ hỗ trợ rẽ 90°." if dirs[c].dot(dirs[c + 1]).abs > 0.035
        (dirs[c] * dirs[c + 1]).z > 0 ? 1 : -1
      end
      modes = corner_modes(p, m - 1)
      avail = (0...m).map { |j| lens[j] - (j > 0 ? half : 0) - (j < m - 1 ? half : 0) }
      (0...m - 1).each do |j|
        raise "Đoạn vẽ thứ #{j + 1} ngắn hơn bề rộng vế – kiểm tra lại đường vẽ." if avail[j] < -1.mm
      end

      cnt = Array.new(m, 0)
      # Đoạn ngắn hơn ~0.9 chiều sâu bậc (VD khe giữa 2 vế thang chữ U) → thành phần chiếu nghỉ, không chia bậc
      (0...m - 1).each { |j| cnt[j] = avail[j] < 0.9 * b ? 0 : (avail[j] / b).round }
      (1...m - 1).each do |j|
        cnt[j] = 1 if cnt[j].zero? && avail[j] > 1.mm && modes[j - 1][0] == 'winder' && modes[j][0] == 'winder'
      end
      corner_lv = 0
      c = 0
      while c < m - 1
        if modes[c][0] == 'winder'
          corner_lv += modes[c][1]
          c += 1
        else
          corner_lv += 1
          c += 1 while c + 1 < m - 1 && modes[c + 1][0] == 'landing' && cnt[c + 1].zero?
          c += 1
        end
      end
      rem = (n_r - 1) - cnt[0...m - 1].sum - corner_lv
      if rem < 0
        raise "Số bậc quá ít so với đường vẽ: các vế dưới + chỗ rẽ đã dùng #{(n_r - 1) - rem} mặt bậc, " \
              "nhưng #{n_r} bậc chỉ có #{n_r - 1} mặt bậc. Tăng số bậc hoặc rút ngắn đường vẽ."
      end
      cnt[m - 1] = rem
      going = (0...m).map { |j| j == m - 1 ? b : (cnt[j] > 0 ? avail[j] / cnt[j] : 0.0) }

      pieces = []
      flights = []
      winders = []
      notes = []
      lv = 0
      land_lv = nil
      (0...m).each do |j|
        d = dirs[j]
        lft = (Z * d).normalize
        s0 = pts[j] + vs(d, j > 0 ? half : 0)
        if cnt[j] > 0
          g = going[j]
          fl = { j: j, s: s0, d: d, g: g, cnt: cnt[j], i0: lv + 1 }
          flights << fl
          cnt[j].times do |k|
            lv += 1
            a = s0 + vs(d, k * g)
            e = a + vs(d, g)
            pfl = a + vs(lft, half)
            pfr = a + vs(lft, -half)
            pbr = e + vs(lft, -half)
            pbl = e + vs(lft, half)
            pieces << { kind: :tread, level: lv, poly: [pfl, pfr, pbr, pbl], labels: %w[front right back left],
                        dir: d, front_lr: [pfl, pfr], back_lr: [pbl, pbr], flight: fl, origin: a, xaxis: d }
          end
          land_lv = nil
        elsif j > 0 && j < m - 1 && avail[j] > 1.mm
          prev_land = modes[j - 1][0] == 'landing'
          next_land = modes[j][0] == 'landing'
          if prev_land && land_lv
            lvl = land_lv
          else
            lv += 1
            lvl = land_lv = lv
          end
          e = s0 + vs(d, avail[j])
          sl = s0 + vs(lft, half)
          sr = s0 + vs(lft, -half)
          el = e + vs(lft, half)
          er = e + vs(lft, -half)
          pieces << { kind: :landing, level: lvl, poly: [sl, sr, er, el],
                      labels: [prev_land ? 'joint' : 'front', 'right', next_land ? 'joint' : 'back', 'left'],
                      dir: d, front_lr: [sl, sr], back_lr: [el, er],
                      side_pts: { 'left' => [sl, el], 'right' => [sr, er] }, origin: sl, xaxis: d }
        end
        next if j == m - 1

        c = j
        v = pts[j + 1]
        d1 = d
        d2 = dirs[j + 1]
        sg = turns[c]
        ei = v + vs(d1, -half) + vs(d2, half)
        eo = v + vs(d1, -half) + vs(d2, -half)
        xo = v + vs(d1, half) + vs(d2, -half)
        xi = v + vs(d1, half) + vs(d2, half)
        outer = sg > 0 ? 'right' : 'left'
        inner = sg > 0 ? 'left' : 'right'
        lr = ->(ip, op) { sg > 0 ? [ip, op] : [op, ip] }
        if modes[c][0] == 'landing'
          entry_joint = !land_lv.nil?
          lvl = land_lv || (lv += 1)
          land_lv = lvl
          nx = j + 1
          exit_joint = nx < m - 1 && cnt[nx].zero? && (avail[nx] > 1.mm || modes[nx][0] == 'landing')
          pieces << { kind: :landing, level: lvl, poly: [ei, eo, xo, xi],
                      labels: [entry_joint ? 'joint' : 'front', outer, outer, exit_joint ? 'joint' : 'back'],
                      dir: d1, front_lr: lr.(ei, eo), back_lr: lr.(ei, xi),
                      side_pts: { outer => [eo, xo, xi], inner => [ei] },
                      origin: ei, xaxis: vs(d2, -1), corner: c, d1: d1, d2: d2, ei: ei, eo: eo, xi: xi }
        else
          k = modes[c][1]
          u0 = vs(d2, -1)
          first_lv = lv + 1
          walks = []
          k.times do |q|
            fa = HALF_PI * q / k
            fb = HALF_PI * (q + 1) / k
            pa = ray_pt(ei, u0, d1, w, fa)
            pb = ray_pt(ei, u0, d1, w, fb)
            poly = [ei, pa]
            outs = [pa]
            if fa < Math::PI / 4 - 1e-6 && fb > Math::PI / 4 + 1e-6
              poly << xo
              outs << xo
            end
            poly << pb
            labels = ['front'] + [outer] * (poly.size - 2) + ['back']
            lv += 1
            walks << (walk_dist(fb) - walk_dist(fa)) * half
            pieces << { kind: :winder, level: lv, poly: poly, labels: labels, dir: d1,
                        front_lr: lr.(ei, pa), back_lr: lr.(ei, pb),
                        side_pts: { outer => outs, inner => [ei] }, origin: ei, xaxis: u0, corner: c }
          end
          winders << { c: c, poly: [ei, eo, xo, xi], first_lv: first_lv, d1: d1, d2: d2, ei: ei, eo: eo, xi: xi,
                       k: k, walks: walks }
          land_lv = nil
        end
      end

      last_drawn = lens[m - 1] - (m > 1 ? half : 0)
      { pieces: pieces, flights: flights, winders: winders, z0: z0, h: h, n: n_r, hgt: hgt, b: b, w: w,
        last_drawn: last_drawn, last_actual: cnt[m - 1] * b, m: m, notes: notes }
    end

    # Đường mép thang (mũi bậc) cho lan can – theo phía trái/phải hướng đi lên
    def self.rail_path(pl, side)
      idx = side == 'left' ? 0 : 1
      pcs = pl[:pieces]
      return [] if pcs.empty?
      z0 = pl[:z0]
      h = pl[:h]
      b = pl[:b]
      path = []
      push = lambda do |q|
        path << q unless path.any? && dxy(path.last, q) < 1.mm
      end
      f = pcs.first
      push.(pz(f[:front_lr][idx] + vs(f[:dir], -b), z0))
      prev = nil
      pcs.each do |pc|
        z = z0 + pc[:level] * h
        if pc[:kind] == :tread
          fp = pc[:front_lr][idx]
          g = pc[:flight][:g]
          if prev == :landing && path.size >= 2 && dxy(path[-1], fp) < 1.mm &&
             (path[-2].z - path[-1].z).abs < 0.04 && dxy(path[-2], path[-1]) > g + 1.mm
            # Mép chiếu nghỉ đủ dài: tay vịn đón dốc vế trên cách mép 1 bậc
            path[-1] = pz(fp + vs(pc[:dir], -g), path[-1].z)
          elsif dxy(path[-1], fp) < 1.mm && z > path[-1].z + 0.04
            # Góc trong: tay vịn nâng lên ngay sát góc (vị trí nên đặt trụ góc)
            ramp = [mm(60), g / 3.0].min
            push.(pz(fp + vs(pc[:dir], ramp), z + ramp * h / g))
            prev = pc[:kind]
            next
          end
          push.(pz(fp, z))
        else
          pc[:side_pts][side].each { |q| push.(pz(q, z)) }
        end
        prev = pc[:kind]
      end
      push.(pz(pcs.last[:back_lr][idx], z0 + pl[:n] * h))
      path
    end

    # ------------------------------------------------------------------
    # Dựng hình
    # ------------------------------------------------------------------
    def self.dists(labels, map, open)
      labels.map do |l|
        case l
        when 'front' then map[:front]
        when 'back' then map[:back]
        when 'left', 'right' then open[l] ? map[:side] : 0.0
        else 0.0
        end
      end
    end

    def self.open_sides(p)
      w = p['wall']
      { 'left' => !%w[left both].include?(w), 'right' => !%w[right both].include?(w) }
    end

    def self.build(ents, pts0, p, uid = nil)
      pl = plan(pts0, p)
      model = Sketchup.active_model
      z0 = pl[:z0]
      h = pl[:h]
      console = p['struct'] == 'console'
      open = open_sides(p)
      raise 'Thang console phải có ít nhất 1 bên tường để neo bậc.' if console && open.values.all?

      ts = mm(p['ts'])
      tr = console ? 0.0 : mm(p['tr'])
      mortar = mm(p['mortar'])
      nose = mm(p['nose'])
      nose_t = mm(p['nose_t'])
      nose_side = mm(p['nose_side'])
      led = !console && p['led'] == true
      led_h = mm(p['led_h'])
      led_d = mm(p['led_d'])
      t_slab = mm(p['t_slab'])
      t_land = mm(p['t_land'])
      skey, srgb = STONES[p['stone']] || STONES['black']
      stone = mtl(skey, srgb)
      conc = mtl('SOUL_Be_tong', [172, 172, 166])
      brick = mtl('SOUL_Gach_xay', [182, 108, 78])
      ledm = mtl('SOUL_LED', [255, 236, 190])

      root = ents.add_group
      root.name = "SOUL Cầu thang H#{p['H'].to_i} – #{pl[:n]} bậc#{console ? ' (console)' : ''}"
      re = root.entities
      sub = ->(name) { g = re.add_group; g.name = name; g.entities }
      g_tread = sub.('Đá mặt bậc')
      g_riser = console ? nil : sub.('Đá cổ bậc')
      g_led = led ? sub.('LED mũi bậc') : nil
      g_body = console ? nil : sub.('Bậc xây')
      g_conc = sub.(console ? 'Chiếu nghỉ' : 'Bản thang & chiếu nghỉ')
      ctx = { defs: {}, count: Hash.new(0) }
      q = Hash.new(0)

      # Mặt phẳng đỉnh bản thang của từng vế
      pl[:flights].each do |fl|
        k = h / fl[:g]
        zr = z0 + (fl[:i0] - 1) * h - ts - mortar
        fl[:plane] = ->(pt) { zr + ((pt - fl[:s]).dot(fl[:d]) - (tr + mortar)) * k }
        fl[:tv] = t_slab * Math.sqrt(1 + k * k)
      end
      win_top = {}
      pl[:winders].each { |wd| win_top[wd[:c]] = z0 + wd[:first_lv] * h - ts - mortar }

      pl[:pieces].each do |pc|
        zt = z0 + pc[:level] * h
        zp = zt - h
        base = pc[:poly]
        labels = pc[:labels]
        fi = labels.index('front')
        stair_step = pc[:kind] != :landing

        if console
          blk = offset_poly(base, dists(labels, { front: nose, back: 0.0, side: nose_side }, open))
          if stair_step
            place(ctx, g_tread, 'SOUL_Bac console', [prism(blk, zt - mm(p['c_thick']), zt, stone)], pc[:origin], pc[:xaxis])
          else
            group_solid(g_conc, 'Chiếu nghỉ', [prism(blk, zt - t_land, zt, stone)])
          end
          q[:tread_area] += area_xy(blk).abs
          next
        end

        # Đá mặt bậc (+ dải mũi dày)
        tp = offset_poly(base, dists(labels, { front: nose, back: tr, side: nose_side }, open))
        sols = [prism(tp, zt - ts, zt, stone)]
        if fi && nose_t > ts + 0.01 && nose > 0.01
          nin = inward(base, fi)
          a1 = tp[fi]
          a2 = tp[(fi + 1) % tp.size]
          sols << prism([a1, a2, a2 + vs(nin, nose), a1 + vs(nin, nose)], zt - nose_t, zt - ts, stone)
        end
        place(ctx, g_tread, stair_step ? 'SOUL_Da mat bac' : 'SOUL_Da chieu nghi', sols, pc[:origin], pc[:xaxis])
        q[:tread_area] += area_xy(tp).abs

        # Đá cổ bậc + LED
        if fi
          f0 = base[fi]
          f1 = base[(fi + 1) % base.size]
          nin = inward(base, fi)
          xr = f1 - f0
          ztop = zt - ts - (led ? led_h : 0)
          place(ctx, g_riser, 'SOUL_Da co bac', [prism([f0, f1, f1 + vs(nin, tr), f0 + vs(nin, tr)], zp, ztop, stone)], f0, xr)
          q[:riser_area] += xr.length.to_f * (ztop - zp)
          if led
            dd = [led_d, mm(10)].max
            place(ctx, g_led, 'SOUL_LED mui bac',
                  [prism([f0 + vs(nin, dd - mm(8)), f1 + vs(nin, dd - mm(8)), f1 + vs(nin, dd), f0 + vs(nin, dd)],
                         zt - ts - led_h, zt - ts, ledm)], f0, xr)
            q[:led_len] += xr.length.to_f
          end
        end

        top_r = zt - ts - mortar
        if stair_step
          # Bậc xây (thô)
          bp = offset_poly(base, dists(labels, { front: -(tr + mortar), back: tr + mortar, side: 0.0 }, open))
          support = pc[:kind] == :tread ? pc[:flight][:plane] : ->(_pt) { win_top[pc[:corner]] }
          top = bp.map { |v| pz(v, top_r) }
          bot = bp.map { |v| pz(v, [support.(v), top_r].min) }
          place(ctx, g_body, 'SOUL_Bac xay', [[top, bot, brick]], pc[:origin], pc[:xaxis]) if bot.each_with_index.any? { |v, i| v.z.to_f < top[i].z.to_f - 0.01 }
        else
          group_solid(g_conc, 'Chiếu nghỉ', [prism(base, top_r - t_land, top_r, conc)])
          q[:conc] += area_xy(base).abs * t_land
        end
      end

      unless console
        # Bản thang nghiêng
        pl[:flights].each do |fl|
          lft = (Z * fl[:d]).normalize
          hw = pl[:w] / 2.0
          len = fl[:cnt] * fl[:g]
          s = fl[:s]
          e = s + vs(fl[:d], len)
          rect = [s + vs(lft, hw), s + vs(lft, -hw), e + vs(lft, -hw), e + vs(lft, hw)]
          top = rect.map { |v| pz(v, fl[:plane].(v)) }
          bot = top.map { |v| pz(v, v.z.to_f - fl[:tv]) }
          group_solid(g_conc, "Bản thang vế #{fl[:j] + 1}", [[top, bot, conc]])
          q[:conc] += pl[:w] * len * fl[:tv]
        end
        # Bản ngang dưới bậc rẽ quạt
        pl[:winders].each do |wd|
          tz = win_top[wd[:c]]
          group_solid(g_conc, "Bản rẽ quạt góc #{wd[:c] + 1}", [prism(wd[:poly], tz - t_land, tz, conc)])
          q[:conc] += pl[:w]**2 * t_land
        end
        # Gối / giật cấp nối bản thang với chiếu nghỉ, bản rẽ quạt
        regions = pl[:pieces].select { |pc| pc[:kind] == :landing && pc[:corner] }.map do |pc|
          tz = z0 + pc[:level] * h - ts - mortar
          { c: pc[:corner], top: tz, entry: pc[:labels][0] == 'front', exit: pc[:labels][3] == 'back',
            d1: pc[:d1], d2: pc[:d2], ei: pc[:ei], eo: pc[:eo], xi: pc[:xi] }
        end
        regions += pl[:winders].map do |wd|
          { c: wd[:c], top: win_top[wd[:c]], entry: true, exit: true, d1: wd[:d1], d2: wd[:d2],
            ei: wd[:ei], eo: wd[:eo], xi: wd[:xi] }
        end
        regions.each do |rg|
          fin = pl[:flights].find { |fl| fl[:j] == rg[:c] }
          fout = pl[:flights].find { |fl| fl[:j] == rg[:c] + 1 }
          bot_r = rg[:top] - t_land
          if rg[:entry] && fin
            a = rg[:ei]
            bb = rg[:eo]
            ze = fin[:plane].(a)
            poly = [a, bb, bb + vs(rg[:d1], t_slab), a + vs(rg[:d1], t_slab)]
            group_solid(g_conc, 'Gối bản thang', [prism(poly, [ze - fin[:tv], bot_r].min, rg[:top], conc)])
          end
          next unless rg[:exit] && fout
          a = rg[:ei]
          bb = rg[:xi]
          zx = fout[:plane].(a)
          inn = vs(rg[:d2], -1)
          poly = [a, bb, bb + vs(inn, t_slab), a + vs(inn, t_slab)]
          group_solid(g_conc, 'Giật cấp bản thang', [prism(poly, [zx - fout[:tv], bot_r].min, [zx, rg[:top]].max, conc)])
        end
        # Đá cổ bậc cuối (lên sàn trên)
        last = pl[:pieces].last
        zl = z0 + last[:level] * h
        bi = last[:labels].index('back')
        if bi
          b0 = last[:poly][bi]
          b1 = last[:poly][(bi + 1) % last[:poly].size]
          out = vs(inward(last[:poly], bi), -1)
          pr = [b0, b1, b1 + vs(out, tr), b0 + vs(out, tr)]
          place(ctx, g_riser, 'SOUL_Da co bac', [prism(pr, zl, z0 + pl[:hgt] - (led ? led_h : 0), stone)], b0, b1 - b0)
          q[:riser_area] += (b1 - b0).length.to_f * (pl[:hgt] - (zl - z0))
        end
      end

      uid ||= "st#{Time.now.to_i}#{rand(100_000)}"
      root.set_attribute(DICT, 'uid', uid)
      root.set_attribute(DICT, 'params', p.to_json)
      root.set_attribute(DICT, 'path', pts0.flat_map { |v| [v.x.to_f, v.y.to_f, v.z.to_f] })
      %w[left right].each do |sd|
        root.set_attribute(DICT, "rail_#{sd}", rail_path(pl, sd).flat_map { |v| [v.x.to_f, v.y.to_f, v.z.to_f] })
        root.set_attribute(DICT, "clear_#{sd}", open[sd] ? p['nose_side'].to_f + 10 : 0.0)
      end
      root.layer = model.layers.add('SOUL_Cau thang')
      [root, report(pl, p, q, ctx, console)]
    end

    # ------------------------------------------------------------------
    # Báo cáo
    # ------------------------------------------------------------------
    def self.report(pl, p, q, ctx, console)
      h = pl[:h]
      hm = to_mm(h)
      l = []
      l << "Cao bậc <b>h = #{format('%.1f', hm)} mm</b> · #{pl[:n]} bậc (#{pl[:n] - 1} mặt bậc kể cả chiếu nghỉ / rẽ quạt)"
      pl[:flights].each do |fl|
        g = to_mm(fl[:g])
        v = 2 * hm + g
        warn = v < 600 || v > 640 ? ' <span class="warn">(ngoài khoảng kinh nghiệm 600–640)</span>' : ''
        l << "Vế #{fl[:j] + 1}: #{fl[:cnt]} bậc · sâu <b>#{format('%.0f', g)} mm</b> · 2h+b = #{format('%.0f', v)}#{warn}"
        if (g - p['b'].to_f).abs > 10
          l << "<span class=\"warn\">Vế #{fl[:j] + 1}: chiều sâu bậc bị chỉnh thành #{format('%.0f', g)} mm để khớp đường vẽ – kiểm tra lại chiều dài đoạn vẽ.</span>"
        end
      end
      pl[:winders].each do |wd|
        ws = wd[:walks].map { |x| format('%.0f', to_mm(x)) }.join(' / ')
        l << "Rẽ quạt góc #{wd[:c] + 1}: #{wd[:k]} bậc · sâu tại đường tim vế: #{ws} mm"
      end
      if pl[:m] > 1 && (pl[:last_actual] - pl[:last_drawn]).abs > 1.mm
        l << "Vế cuối thực tế dài <b>#{format('%.0f', to_mm(pl[:last_actual]))} mm</b> (đường vẽ #{format('%.0f', to_mm(pl[:last_drawn]))} mm) – tool chia theo số bậc."
      end
      ctx[:count].sort_by { |d, _| d.name }.each { |d, n| l << "#{d.name}: <b>#{n}</b>" }
      l << "Đá mặt bậc + chiếu nghỉ: <b>#{format('%.2f', q[:tread_area] * 0.00064516)} m²</b>"
      l << "Đá cổ bậc: <b>#{format('%.2f', q[:riser_area] * 0.00064516)} m²</b>" if q[:riser_area] > 0
      l << "LED mũi bậc: <b>#{format('%.2f', q[:led_len] * 0.0254)} m</b>" if q[:led_len] > 0
      l << "Bê tông bản thang + chiếu nghỉ: ~<b>#{format('%.2f', q[:conc] * 0.000016387064)} m³</b>" if q[:conc] > 0
      l << '<i>Khối lượng ước lượng từ mô hình – đo thực tế trước khi đặt cắt đá.</i>'
      [l, console ? console_table(pl, p) : rough_table(pl, p)]
    end

    def self.rough_table(pl, p)
      hm = to_mm(pl[:h])
      fin = p['ts'].to_f + p['mortar'].to_f
      rows = (1..pl[:n]).map do |i|
        zf = i * hm
        top = i < pl[:n] ? zf - fin : p['H'].to_f - p['ff_top'].to_f
        bot = i == 1 ? -p['ff_bot'].to_f : (i - 1) * hm - fin
        [i, zf, top, top - bot]
      end
      html = +'<table><tr><th>Bậc</th><th>Cốt hoàn thiện</th><th>Cốt thô</th><th>Cao bậc thô</th></tr>'
      rows.each do |i, zf, top, hh|
        odd = (hh - hm).abs > 0.5 ? ' class="hl"' : ''
        html << "<tr#{odd}><td>#{i}</td><td>+#{format('%.0f', zf)}</td><td>+#{format('%.0f', top)}</td><td>#{format('%.0f', hh)}</td></tr>"
      end
      html << '</table><div class="sm">Cốt tính từ mặt hoàn thiện sàn dưới (±0). Cốt thô = mặt bậc xây trước khi lát vữa + đá. ' \
              'Dòng tô màu là bậc thô khác các bậc còn lại.</div>'
      html
    end

    def self.console_table(pl, p)
      hm = to_mm(pl[:h])
      html = +'<table><tr><th>Bậc</th><th>Mặt bậc</th><th>Đáy bậc console</th></tr>'
      (1...pl[:n]).each do |i|
        html << "<tr><td>#{i}</td><td>+#{format('%.0f', i * hm)}</td><td>+#{format('%.0f', i * hm - p['c_thick'].to_f)}</td></tr>"
      end
      html << '</table><div class="sm">Dùng để định vị bản mã / lỗ neo console trên tường.</div>'
      html
    end

    # ------------------------------------------------------------------
    # Liên kết lan can
    # ------------------------------------------------------------------
    def self.stair?(e)
      e.is_a?(Sketchup::Group) && e.valid? && !e.get_attribute(DICT, 'uid').nil?
    end

    def self.rail_points(st, side)
      arr = st.get_attribute(DICT, "rail_#{side}") || []
      arr.each_slice(3).map { |x, y, z| Geom::Point3d.new(x, y, z).transform(st.transformation) }
    end

    def self.side_clear(st, side)
      st.get_attribute(DICT, "clear_#{side}").to_f
    end

    # ------------------------------------------------------------------
    # Thực thi + hộp thoại
    # ------------------------------------------------------------------
    def self.stored_path(g)
      (g.get_attribute(DICT, 'path') || []).each_slice(3).map { |x, y, z| Geom::Point3d.new(x, y, z) }
    end

    def self.collect_defs(ents, set = {})
      ents.each do |e|
        if e.is_a?(Sketchup::ComponentInstance)
          set[e.definition] = true
        elsif e.is_a?(Sketchup::Group)
          collect_defs(e.entities, set)
        end
      end
      set.keys
    end

    def self.run_op(name)
      model = Sketchup.active_model
      model.start_operation(name, true)
      g, rep, p = yield
      model.commit_operation
      model.selection.clear
      model.selection.add(g)
      @edit = g
      @dlg.execute_script("showResult(#{rep[0].to_json}, #{rep[1].to_json})") if visible?
      send_info
    rescue StandardError => e
      model.abort_operation
      UI.messagebox("Lỗi khi dựng cầu thang:\n#{e.message}")
      puts e.full_message
    end

    def self.on_create(p, force_pick)
      p = DEFAULTS.merge(p)
      Sketchup.write_default(PREF, 'params', p.to_json)
      model = Sketchup.active_model
      res = nil
      unless force_pick
        begin
          res = R.path_from_selection(model.selection)
        rescue RuntimeError => e
          UI.messagebox(e.message)
          return
        end
      end
      if res
        pts, closed = res
        return UI.messagebox('Đường vẽ cầu thang không được khép kín.') if closed
        run_op('SOUL – Dựng cầu thang') { build(model.active_entities, pts, p) + [p] }
      elsif !force_pick && @edit && @edit.valid?
        old = @edit
        pts = stored_path(old).map { |v| v.transform(old.transformation) }
        ents = old.parent.entities
        uid = old.get_attribute(DICT, 'uid')
        run_op('SOUL – Sửa cầu thang') do
          defs = collect_defs(old.entities)
          old.erase!
          r = build(ents, pts, p, uid)
          defs.each do |d|
            next unless d.valid? && d.instances.empty?
            model.definitions.remove(d) if model.definitions.respond_to?(:remove)
          end
          R.rebuild_linked(r[0])
          r + [p]
        end
      else
        model.select_tool(R::PickTool.new('Cầu thang SOUL') do |pk, _cl|
          run_op('SOUL – Dựng cầu thang') { build(model.active_entities, pk, p) + [p] }
        end)
      end
    end

    def self.saved_params
      s = Sketchup.read_default(PREF, 'params')
      s ? DEFAULTS.merge(JSON.parse(s)) : DEFAULTS.dup
    rescue StandardError
      DEFAULTS.dup
    end

    def self.visible?
      @dlg && @dlg.visible?
    end

    def self.info_text
      sel = Sketchup.active_model.selection
      edges = sel.grep(Sketchup::Edge)
      if edges.any?
        "Đang chọn #{edges.size} cạnh → bấm TẠO để dựng cầu thang MỚI theo đường này."
      elsif @edit && @edit.valid?
        "Đang sửa: #{@edit.name} → chỉnh thông số rồi bấm TẠO để CẬP NHẬT (lan can liên kết tự dựng lại)."
      else
        'Chưa chọn đường → bấm TẠO rồi click các điểm trên mặt bằng (Enter để kết thúc).'
      end
    end

    def self.params_of(g)
      DEFAULTS.merge(JSON.parse(g.get_attribute(DICT, 'params')))
    end

    def self.send_init(params = nil)
      return unless visible?
      @dlg.execute_script("init(#{params ? params.to_json : 'null'}, #{info_text.to_json})")
    end

    def self.send_info
      return unless visible?
      sel = Sketchup.active_model.selection
      if sel.size == 1 && stair?(sel.first) && sel.first != @edit
        @edit = sel.first
        send_init(params_of(@edit))
      else
        @edit = nil if sel.grep(Sketchup::Edge).any?
        send_init
      end
    end

    class SelObs < Sketchup::SelectionObserver
      def onSelectionBulkChange(_sel)
        Stair.send_info
      end

      def onSelectionCleared(_sel)
        Stair.send_info
      end
    end

    def self.show_dialog(edit_group = nil)
      @edit = edit_group if edit_group
      if visible?
        send_init(@edit && @edit.valid? ? params_of(@edit) : nil)
        @dlg.bring_to_front
        return
      end
      @dlg = UI::HtmlDialog.new(
        dialog_title: 'SOUL.atelier – Dựng cầu thang', preferences_key: 'SOUL_Stair_dlg',
        width: 460, height: 820, min_width: 400, min_height: 520, style: UI::HtmlDialog::STYLE_DIALOG
      )
      @dlg.set_file(File.join(PLUGIN_DIR, 'stair.html'))
      @dlg.add_action_callback('ready') { |_c| send_init(@edit && @edit.valid? ? params_of(@edit) : saved_params) }
      @dlg.add_action_callback('refresh') { |_c| send_info }
      @dlg.add_action_callback('create') { |_c, json| on_create(JSON.parse(json), false) }
      @dlg.add_action_callback('pick') { |_c, json| on_create(JSON.parse(json), true) }
      @dlg.add_action_callback('reset') { |_c| send_init(DEFAULTS) }
      @dlg.add_action_callback('railing') { |_c| R.show_dialog }
      @obs ||= SelObs.new
      model = Sketchup.active_model
      model.selection.add_observer(@obs)
      @dlg.set_on_closed { model.selection.remove_observer(@obs) rescue nil }
      @dlg.show
    end

    unless file_loaded?(__FILE__)
      UI.add_context_menu_handler do |menu|
        sel = Sketchup.active_model.selection
        if sel.size == 1 && Stair.stair?(sel.first)
          menu.add_item('SOUL – Sửa cầu thang') { R.guard { Stair.show_dialog(sel.first) } }
          menu.add_item('SOUL – Dựng lan can theo cầu thang') { R.guard { R.show_dialog } }
        end
      end
      file_loaded(__FILE__)
    end
  end
end
