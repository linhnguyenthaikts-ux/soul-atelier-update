# encoding: UTF-8
# Tool: SOUL Cầu thang + SOUL Lan can
#  - Cầu thang theo đường vẽ mặt bằng: 1 vế / chữ L / chữ U, chiếu nghỉ hoặc rẽ quạt,
#    bản thang BTCT + bậc xây hoặc console treo; đá mặt bậc, đá cổ bậc, mũi bậc, khe LED;
#    bậc giống nhau dùng chung component; bảng cao độ bậc thô.
#  - Lan can kính (kẹp chân, ray U, trụ inox, gắn hông cầu thang) và lan can sắt
#    (song đứng, song ngang, tấm); dựng theo cạnh chọn, click điểm hoặc theo cầu thang SOUL.
%w[railing stair].each do |f|
  Sketchup.require(File.join(SoulAtelier::ROOT_DIR, 'stair_railing', f))
end

SoulAtelier.register_tool('stair', 'SOUL Cầu thang',
  :tooltip => 'SOUL Cầu thang – dựng theo đường vẽ mặt bằng',
  :status  => 'Cầu thang 1 vế / L / U, chiếu nghỉ hoặc rẽ quạt, bản thang hoặc console; đá, mũi bậc, LED, bảng bậc thô.',
  :icon    => 'stair') { SoulAtelier::Stair.show_dialog }

SoulAtelier.register_tool('railing', 'SOUL Lan can',
  :tooltip => 'SOUL Lan can – kính / sắt',
  :status  => 'Lan can kính, lan can sắt theo cạnh chọn, click điểm hoặc theo cầu thang SOUL; bóc khối lượng sơ bộ.',
  :icon    => 'railing') { SoulAtelier::Railing.show_dialog }
